(function(){
    appViewer = function(){
        this.init();
    }
    appViewer.prototype = {
        key : null,
        settingkey : null,
        wisebookStorageList : {},
        settingStorageList  : {},
        
        init : function(){
            if(!appFlag){
                appStorage = null;
                $.extend(this, webStorage);
            }else{
                webStorage = null;
                $.extend(this, appBookStorage);
            }
        }
    };
    
    /*application*/
    var appBookStorage = {
       appBookid : null,
       lastPage : '1',
       setting : function( info, callback ){
           var sql = '',
               sqlData = [];

           this.appBookid = 1202;
           // this.appBookid = PARAMLIBRARY.createViewInfo.app_book_id;
           console.log("appBookStorage setting", this.appBookid);
           console.trace();
           this.viewAppEvent();

           sql = 'SELECT * FROM option WHERE app_book_id=?';

           h5applib.query(sql, [this.appBookid], function(dbData){
               console.log('--------------option DB SELECT----------------');
               if( dbData.res.rows.length == 0 ){
                   sql = 'INSERT INTO option (app_book_id, lastpage) VALUES (?, ?)';
                   sqlData = [h5appview.appBookid, '1'];
                   h5applib.query(sql, sqlData);
               }else{
                   var row = dbData.res.rows.item(0);
                   h5appview.lastPage = row.lastpage;
               }
           });

           this.wisebookStorageList = {
               pages    : {},
               bookmark : {}
           };
           sql = 'SELECT page, dataobj FROM viewer WHERE app_book_id=? AND module=? ORDER BY page ASC';
           h5applib.query(sql, [this.appBookid, "listdata"], function(dbData){
               console.log('----------------get All PageData--------------------------');
               var rowLength = dbData.res.rows.length;
               for(var i=0; i<rowLength; i++){
                   var row = dbData.res.rows.item(i);
                   console.log('DB :',row.page);
                   h5appview.wisebookStorageList.pages[row.page] = JSON.parse(row.dataobj);
               }

               for(var j=1; info.pages >=j; j++) {
                   if( typeof h5appview.wisebookStorageList.pages[j] != "undefined" ) continue;
                   h5appview.wisebookStorageList.pages[j] = {
                       canvasList      : [],
                       memoList        : [],
                       pictureList     : [],
                       movieList       : [],
                       blindList       : [],
                       linkList        : [],
                       stampList       : []
                   };
               }

               callback();
           });
           $(document).trigger(viewdefind.BOOKMARK_UPDATE);

           //sqlite join やり方
           // sql = 'SELECT V.module,  FROM viewer V LEFT OUTER JOIN option OP ON V.app_book_id = OP.app_book_id WHERE V.app_book_id=? ORDER BY page ASC';
           // h5applib.query(sql, sqlData, function(dbData){
           //  console.log('-------------- viewer or option join DB SELECT----------------', dbData);
           //  if( dbData.res.rows.length == 0 ){
           //      sql = 'INSERT INTO option (app_book_id, lastpage) VALUES (?, ?)';
           //      sqlData = [this.appBookid, '0'];
           //      h5applib.query(sql, sqlData);
           //  }else{

           //  }
           // });
       },

       viewAppEvent : function(){
           $(document).bind(viewdefind.BOOKMARK_UPDATE, function(){
               h5appview.updateBookmarkData();
           });
       },

       lastpageUpdate : function(pageNum){
           console.log("lastpageUpdate", pageNum);
           var sql = 'UPDATE option SET lastpage=? WHERE app_book_id=?',
               sqlData = [pageNum, this.appBookid];

           h5applib.query(sql, sqlData, function(dbData){
               console.log('----------------lastpage update ok---------------------', pageNum);
           });
       },

       updateBookmarkData : function(){
           console.log("updateBookmarkData");

           var sql = '',
               sqlData = [this.appBookid],
               tmpBookmark ={
                   siori   : [],
                   memo    : [],
                   stamp   : [],
                   canvas  : [],
                   picture : [],
                   movie   : [],
                   urllink : []
               };

           this.wisebookStorageList.bookmark = tmpBookmark;

           sql = 'SELECT * FROM viewer WHERE app_book_id=? ORDER BY page ASC';
           h5applib.query(sql, sqlData, function(dbData){
               console.log('--------------DB get viewer book data----------------');
               if( dbData.res.rows.length > 0 ){
                   var rowLength = dbData.res.rows.length;
                   console.log('total viewer data : ', rowLength);
                   for(var i=0; i<rowLength; i++){
                       var row = dbData.res.rows.item(i);
                       if( row.module == 'listdata' ){
                           var tmpDataObj = JSON.parse( row.dataobj );

                           if(tmpDataObj.memoList.length > 0){
                               h5appview.wisebookStorageList.bookmark.memo.push(row.page);
                           }

                           if(tmpDataObj.canvasList.length > 0){
                               h5appview.wisebookStorageList.bookmark.canvas.push(row.page);
                           }
                       }else if( row.module == 'siori' ){
                           h5appview.wisebookStorageList.bookmark.siori = $.map( row.dataobj.split(','), function(value){ return parseInt(value, 10); });
                       }
                   }
               }
           });
       },

       setBoomarkInfo : function(){
           console.log("setBoomarkInfo");
           var sql = 'SELECT * FROM viewer WHERE module="siori" AND app_book_id=?',
               sqlData = [this.appBookid],
               sioriData = h5appview.wisebookStorageList.bookmark.siori.join(',');

           h5applib.query(sql, sqlData, function(dbData){
               if(dbData.res.rows.length > 0){
                   console.log('----------------UPDATE VIEWER SIORI DATA--------------------------');
                   sql = 'UPDATE viewer SET dataobj=? WHERE module=? AND app_book_id=?';
                   sqlData = [sioriData, 'siori', h5appview.appBookid];
               }else{
                   console.log('----------------INSERT VIEWER SIORI DATA--------------------------');
                   sql = 'INSERT INTO viewer (app_book_id, module, dataobj) VALUES (?, ?, ?)';
                   sqlData = [h5appview.appBookid, 'siori', sioriData];
               }

               h5applib.query(sql, sqlData, function(dbData){
                   console.log( "setBoomarkInfo save ok" );
               });
           });
       },

       setStorageData : function(page){
           var sql= '',
               sqlData = [],
               dataobj = JSON.stringify( h5appview.wisebookStorageList.pages[page] );

           console.log("setStorageData", h5appview.wisebookStorageList.pages[page]);

           sql = 'SELECT * FROM viewer WHERE page=? AND module="listdata" AND app_book_id=?';
           sqlData = [page, this.appBookid];
           h5applib.query(sql, sqlData, function(dbData){
               if(dbData.res.rows.length > 0){
                   console.log('----------------UPDATE PAGE LIST DATA--------------------------');
                   //update
                   sql = 'UPDATE viewer SET dataobj=? WHERE page=? AND app_book_id=?';
                   sqlData = [dataobj, page, h5appview.appBookid];
               }else{
                   console.log('----------------INSERT PAGE LIST DATA--------------------------');
                   sql = 'INSERT INTO viewer (app_book_id, module, page, dataobj) VALUES (?, ?, ?, ?)';
                   sqlData = [h5appview.appBookid, 'listdata', page, dataobj];
               }
               h5applib.query(sql, sqlData, function(data){
                   $(document).trigger(viewdefind.BOOKMARK_UPDATE);
               });
           });
       },

       hideViewToBookshelf : function() {
           try{
               htmlview.destroy();
               libStore.viewerCloseAnimation();
           }catch(e){
               libStore.viewerCloseAnimation();
           }
       },

       hideViewToLibrary : function() {
           try{
               htmlview.destroy();
               libStore.viewerToLibrary();
           }catch(e){
               libStore.viewerToLibrary();
           }
       },

       hideView : function(){
           if(PARAMLIBRARY.isAppBookshelfFlag) {
               this.hideViewToBookshelf();
           }
           else {
               this.hideViewToLibrary();
           }
       },

       appAlert : function(alertObj, callback){
           if (appFlag) {
               $webApiRouter.interfaceJSAlertForViewer(alertObj, callback);
           }
           else {
               navigator.notification.alert(
                   alertObj.text,
                   function(){
                       if( typeof( callback ) == "function" ) callback();
                   },
                   alertObj.title,
                   alertObj.buttonname
               );
           }
       }
    };
    
    /*web*/
    var webStorage = {
        version : 1,
        setting : function(info,bookMetaData){
            if( 'bookshelfFlag' in viewInfo == true ){
                //配信
                this.key = "v2-bookshelf-" + idx + '-' + bookid;
            }else{
                //制作
                this.key = "v2-make-" + idx + '-' + bookid;
            }
            
            this.settingkey = this.key+'_setting';
            var wbStorageData = bookMetaData;
            if(wbStorageData == null){
                this.wisebookStorageList = {
                    pages : {},
                    bookmark : {
                        siori   : [],
                        memo    : [],
                        stamp   : [],
                        canvas  : [],
                        picture : [],
                        movie   : [],
                        urllink : [],
                        blind   : []
                    }
                };
                
                for(var i=1; info.pages >=i; i++){
                    this.wisebookStorageList.pages[i] = {
                        canvasList      : [], 
                        memoList        : [], 
                        pictureList     : [], 
                        movieList       : [],
                        blindList       : [], 
                        linkList        : [], 
                        stampList       : []
                    };
                };
                
                this.settingStorageList ={
                    blindflag : 0,
                    version : this.version
                };
            }else{
                this.wisebookStorageList = wbStorageData; //data storage
                if( info.pages != Object.keys(wbStorageData.pages).length ){    
                    for(var i=1; info.pages >=i; i++){
                        if( typeof this.wisebookStorageList.pages[i] != "undefined" ) continue;
                        this.wisebookStorageList.pages[i] = {
                            canvasList      : [], 
                            memoList        : [], 
                            pictureList     : [], 
                            movieList       : [],
                            blindList       : [], 
                            linkList        : [], 
                            stampList       : []
                        };
                    }
                }
                this.settingStorageList = $.jStorage.get( this.settingkey ); //setting storage
               // console.log(this.wisebookStorageList);
            }
        },
        setStorageData : function(page) {
            window.chrome.webview.postMessage({
                key: "flutterAddSyncIcon",
                data: "true"
            }); // WNT_20250205
            console.log(page);
            console.log(bookid);
            console.log(idx);
            this.setBoomarkInfo();
            // var ajaxUrl = 'https://manamo.bigal.work/wiseapi/l/v1/storeData.json';
            // var ajaxUrl = 'https://wb.manamo.jp/wiseapi/l/v1/storeData.json';
            var ajaxUrl = 'https://wenetwb8.bigal.work/wiseapi/l/v1/storeData.json';
            if (page) {
                window.chrome.webview.postMessage({'key':"listdata",'page':page,"data":this.wisebookStorageList.pages[page]});
                $.ajax({
                    type: "POST",
                    headers: {
                        'X-Wisebook-Authorization': headx,
                    },
                    url: ajaxUrl,

                    data: {
                        book_id: bookid,
                        idx: idx,
                        page: page,
                        data_obj: JSON.stringify(this.wisebookStorageList.pages[page])
                    },
                    complete: function () {
                        // self.hideBtnSyncing();
                        window.chrome.webview.postMessage({
                            key: "flutterRemoveSyncIcon",
                            data: 'true'
                        }); // WNT_20250205
                      },
                      // start WNT_20250205
                      success: function (data) {
                        if (data["result"] == "true" && data["syncro_at"]) {
                            window.chrome.webview.postMessage({
                            key: "flutterSyncAt",
                            data: data["syncro_at"],
                          });
                        }
                      },
                    error: function (request, status, error) {
                        console.log(error);
                    }
                });

            } else {
                window.chrome.webview.postMessage({ 'key': "siori", 'page': null, "data": this.wisebookStorageList.bookmark.siori.join(",") });
                $.ajax({
                    type: "POST",
                    headers: {
                        'X-Wisebook-Authorization': headx,
                    },
                    url: ajaxUrl,
                    data: {
                        book_id: bookid,
                        idx: idx,
                        bookmark: this.wisebookStorageList.bookmark.siori.join(",")
                    },
                    complete: function () {
                        // self.hideBtnSyncing();
                        window.chrome.webview.postMessage({
                            key: "flutterRemoveSyncIcon",
                            data: 'true'
                        }); // WNT_20250205
                      },
                      // start WNT_20250205
                      success: function (data) {
                        if (data["result"] == "true" && data["syncro_at"]) {
                            window.chrome.webview.postMessage({
                            key: "flutterSyncAt",
                            data: data["syncro_at"],
                          });
                        }
                      },
                    error: function (request, status, error) {
                        console.log(error);
                    }
                });
            }
        },

        setStorageDataPage : function(bookMetaData, info){
             if( 'bookshelfFlag' in viewInfo == true ){
                 //配信
                 this.key = "v2-bookshelf-" + 'm101507' + '-' + bookid;
             }else{
                 //制作
                 this.key = "v2-make-" + 'm101507' + '-' + bookid;
             }
             
             this.settingkey   = this.key+'_setting';
             var wbStorageData = bookMetaData;
             if(wbStorageData == null){
                 this.wisebookStorageList = {
                     pages : {},
                     bookmark : {
                         siori   : [],
                         memo    : [],
                         stamp   : [],
                         canvas  : [],
                         picture : [],
                         movie   : [],
                         urllink : [],
                         blind   : []
                     }
                 };
                 
                 for(var i=1; info.pages >=i; i++){
                     this.wisebookStorageList.pages[i] = {
                         canvasList      : [], 
                         memoList        : [], 
                         pictureList     : [], 
                         movieList       : [],
                         blindList       : [], 
                         linkList        : [], 
                         stampList       : []
                     };
                 };
                 
                 this.settingStorageList ={
                     blindflag : 0,
                     version : this.version
                 };
                 
                //  $.jStorage.set( this.key, this.wisebookStorageList );
                //  $.jStorage.set( this.settingkey, this.settingStorageList );
                 
             }else{
                console.log("khác null");
                 this.wisebookStorageList = wbStorageData; //data storage
                 if( info.pages != Object.keys(wbStorageData.pages).length ){    
                     for(var i=1; info.pages >=i; i++){
                         if( typeof this.wisebookStorageList.pages[i] != "undefined" ) continue;
                         this.wisebookStorageList.pages[i] = {
                             canvasList      : [], 
                             memoList        : [], 
                             pictureList     : [], 
                             movieList       : [],
                             blindList       : [], 
                             linkList        : [], 
                             stampList       : []
                         };
                     }
 
                 }
                 this.settingStorageList = $.jStorage.get( this.settingkey ); //setting storage
                 console.log(this.wisebookStorageList);
                 this.setStorageData(null);
             }
        },
        setBoomarkInfo : function(){
            var memoCntArr   = [];
            var canvasCntArr = [];
            var stampCntArr  = [];
            var blindCntArr  = [];
            $.each(this.wisebookStorageList.pages, function(key, valus){
                if(valus.memoList.length > 0)   memoCntArr.push(parseInt( key ));
                if(valus.canvasList.length > 0) canvasCntArr.push(parseInt( key ));
                if(valus.stampList.length > 0)  stampCntArr.push(parseInt( key ));
                if(valus.blindList.length > 0)  blindCntArr.push(parseInt( key ));
            });
            
            this.wisebookStorageList.bookmark.memo = memoCntArr;
            this.wisebookStorageList.bookmark.canvas = canvasCntArr;
            this.wisebookStorageList.bookmark.stamp  = stampCntArr;
            this.wisebookStorageList.bookmark.blind  = blindCntArr;
        },
        showBtnSyncing: function () {
            $("#icon-syncing").fadeIn("slow");
          },
          hideBtnSyncing: function () {
            $("#icon-syncing").fadeOut("slow");
          },
    }
})();
h5appview = new appViewer();
