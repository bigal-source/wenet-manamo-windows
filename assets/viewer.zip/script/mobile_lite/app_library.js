/*************************************************************************************
    ALL CONTROL LIBRARY
**************************************************************************************/
var wisebookDB, exec = null;

(function(){
    var fileTransfer;
    
    window.appFront = function(){
        $appFront = this;
        this.initialize();
    };
    
    appFront.prototype = {
        isKeyboard      : false,
        appDocPath      : '',
        appTmpPath      : '',
        nowConnetStatus : false,
        cancelObj       : null,
        timeMachineObj  : null,
        bsCateKey       : null,
        
        vaildPortal     : false,
        validCloud      : false,
        
        initialize : function(){
            if(appFlag){
                this.addScripte();
                document.addEventListener('deviceready', this.onDeviceReady, false);
                document.addEventListener("offline", this.onOffline, false);
                document.addEventListener("online", this.onOnline, false);
                
                document.addEventListener("backbutton", function(){
                    console.log('backbutton');
                    if( libStore.isHtmlView ){
                        if(androidDeviceCheck){
                            $mediaLib.low_close_media();
                        }
                        h5appview.hideView();
                        return false;
                    }
                    else {
                        if(!PARAMLIBRARY.isAppBookshelfFlag) {
                            $webApiRouter.closeViewerToLibrary();
                        }
                        return false;
                    }
                }, false);
            }
        },
        
        onOffline : function(){
            PARAMLIBRARY.responseCheck = false;
            //$appFront.responseCheck();
        },
        
        onOnline : function(){
            PARAMLIBRARY.responseCheck = true;
            //$appFront.responseCheck();
        },

        keyboardShow : function(){
            SoftKeyboard.show();
            this.isKeyboard = true;
        },

        keyboardHide : function(){
            console.log("keyboardHide");
            SoftKeyboard.hide();
            this.isKeyboard = false;
        },
        
        urlScheme : function(url){
            var vars = {};
            var param = url.split('://?')[1];
            param = param.split('&');
            for(var i = 0; i < param.length; i++) {
                var keySearch = param[i].split('=');
                var key = keySearch[0];
                var val = keySearch[1];
                if(key != '') vars[key] = decodeURI(val);
            } 
            
            if( ("action" in vars) == false )  return false;
            
            switch( vars.action ){
                case "bookAction" :
                    if( PARAMDATA.inappBrowser != null ){
                        PARAMDATA.inappBrowser.close();
                        PARAMDATA.inappBrowser = null;
                    }
                
                    if( typeof( vars.bookid ) == "undefined" || vars.bookid == "" ) return false;
                    var tempAppBookid = PARAMDATA.libInfo.auth+'_'+vars.bookid;
                    
                    
                    var waintLibStoreTime = setInterval(function(){
                        if( libStore ){
                            clearInterval(waintLibStoreTime);
                            if( libStore.isHtmlView ){
                                var tempViewBookObj = $.jStorage.get('bshelfInfo');
                                if( tempAppBookid == tempViewBookObj.app_book_id ) return false;
                                
                                libStore.viewerToLibraryAnimation();
                                $appFront.urlSchemeAction( vars );                      
                            }else{
                                $appFront.urlSchemeAction( vars );
                            }
                        }
                    }, 100);
                    
                    break;
                case "browserOpen" :
                    if( vars.url == "" ) return false;
                    var openUrl = decodeURIComponent(vars.url);
                    
                    navigator.notification.confirm(
                        PARAMDATA.lang.message.openbrowser_confirm,
                        function(buttonIndex){
                            if( buttonIndex == 2 ){
                                window.open( openUrl, '_system');
                                
                                if( PARAMDATA.inappBrowser != null ){
                                    PARAMDATA.inappBrowser.close();
                                    PARAMDATA.inappBrowser = null;
                                }
                            }
                        },
                        "OPEN",
                        [PARAMDATA.lang.oneword.confim_cancel, "OK"]
                    );
                    
                    break;
                
                default :
                    
                    break;
            }
        },
        
        urlSchemeAction : function(objData){
            
            switch( objData.action ){
                case "bookAction" :
                    setTimeout(function(){
                        var infoObj = { bookid : objData.bookid };
                        
                        libStore._getServerToBookInfo( infoObj, function(returnData, obj){
                            if( returnData != 'ok' ) return false;
                            if( obj == "null" ){
                                libStore.alert(PARAMDATA.lang.message.not_book_data, 'BOOK ERROR');
                                return false;
                            }
                            
                            var checkBookStartus = libStore.checkGotoViewer( obj.bookid );
                            
                            if( checkBookStartus == false ) return false;
                            
                            libStore.disttypeAction( obj );
                        } );
                    }, 100);
                    
                    break;
            }
        },
        
        responseCheck : function(){
            //response check
            // $.ajax({
            //     url         : PARAMDATA.libInfo.baseUrl,
            //     timeout     :1000,
            //     async       : false,
            //     cache       : false,
            //     statusCode: {
            //         200: function (response) {
            //             PARAMLIBRARY.responseCheck = true;
            //         },
            //         400: function (response) {
            //             console.log('400 Not working!');
            //             PARAMLIBRARY.responseCheck = false;
            //         },
            //         0: function (response) {
            //             console.log('0 Not working!');
            //             PARAMLIBRARY.responseCheck = false;
            //         } 
            //     }
                
            // });
        },
        
        addScripte : function(){
            var srcArr = ["script/mobile_lite/dbAdmin.js"];
            for(var i in srcArr){
                var script = document.createElement('script');
                script.src = srcArr[i];
                script.type = 'text/javascript';
                document.getElementsByTagName('head')[0].appendChild(script);
            }           
        },
        
        getBookshelfCateData : function(){
            //getConnectStatus
            var storageCateData = $.jStorage.get(this.bsCateKey);
            if( storageCateData == null ) {
                this.setBookshelfCateData();
            }else{
                PARAMLIBRARY.bs_cate_data = storageCateData;
            }
            
        },
        
        setBookshelfCateData : function(){
            $.jStorage.set( this.bsCateKey, PARAMLIBRARY.bs_cate_data );
        },
        
        getConnectStatus : function(){
            
            if(appFlag == true){
                var networkState = navigator.connection.type;
                var states = {};
                states[Connection.UNKNOWN]  = 'no';
                states[Connection.ETHERNET] = 'ok';
                states[Connection.WIFI]     = 'ok';
                states[Connection.CELL_2G]  = 'no';
                states[Connection.CELL_3G]  = 'ok';
                states[Connection.CELL_4G]  = 'ok';
                states[Connection.CELL]     = 'ok';
                states[Connection.NONE]     = 'no';
                
                this.nowConnetStatus = networkState;
                return states[networkState];
            }else{
                return 'ok';
            }
        },
        
        //hybrid only
        onDeviceReady : function(){
            $appFront.defindEvent();

            $webApiRouter.closeViewerToBookshelf();
            $.jStorage.set("viewStatus", { status : 0, appid : '' });
            exec = cordova.require('cordova/exec');
            exec(
                function(data){
                    $appFront.appDocPath = data.docDir;
                    $appFront.appTmpPath = data.tmpDir;
                    
                },function(){
                    console.log('error');
                },
                'appWisebookController',
                'getAppParamInfo',
                []
            );
            
            $.extend($appFront, sqlLite);
            $.extend($appFront, applicationAccess);
            
            
            dbAdmin = new dbAdmin();
            
            dbAdmin.createDB( function(db){
                wisebookDB = db;
                                
                if( wisebookDB ){     
                    startUiclassLibrary();
                    $webApiRouter.changeBookshelfInfo();
                }
            });
        },

        defindEvent : function(){
            //webApiRouter( getBookshelfInfo method ) -> setInfo( manifest setting )
            $(document).bind(lib_defind.LIBRARY_BOOKSHELFINFO, function(e, info){
                PARAMDATA.setInfo(info);
            });
        },

        dbValidate : function(){
            //sortno
            if( dbAdmin.bsTableItems != null ){
                var rowLength = dbAdmin.bsTableItems.length;
                for(var i=0; i<rowLength; i++){
                    var row = dbAdmin.bsTableItems.item(i);
                    if( row.name == "sortno" ){
                        
                        var sql = 'SELECT count(1) FROM bshelf GROUP BY sortno HAVING count(1) > 1 LIMIT 1';
                        var sqldata = null;
                        
                        if( PARAMDATA.customInfo.name == "cloud_portal" ) {
                            sql = 'SELECT count(1) FROM bshelf WHERE plan_type=?  GROUP BY sortno HAVING count(1) > 1 LIMIT 1';
                            sqldata = (PARAMDATA.portalFlag == true) ? ["portal"] : ["cloud"];
                        }
                        
                        $appFront.query( sql, sqldata,
                            function(dbData){
                                if( dbData.res.rows.length > 0 ){
                                    sql = "SELECT * FROM bshelf ORDER BY sortno ASC, id ASC";
                                    
                                    if( PARAMDATA.customInfo.name == "cloud_portal" ) {
                                        sql = "SELECT * FROM bshelf WHERE plan_type=?  ORDER BY sortno ASC, id ASC";
                                        sqldata = (PARAMDATA.portalFlag == true) ? ["portal"] : ["cloud"];
                                    }
                                    
                                    $appFront.query( sql, sqldata, 
                                        function( list ){
                                            var rowListLen = list.res.rows.length;
                                            for(var i=0; i<list.res.rows.length; i++){
                                                var row = list.res.rows.item(i);
                                                var updateSql = 'UPDATE bshelf SET sortno=? WHERE id=?';
                                                $appFront.query( updateSql, [(i+1), row.id], function(){
                                                    console.log(updateSql);
                                                });
                                            }                                           
                                        } 
                                    );
                                }
                            }
                        );
                    }
                }
            }           
        },
        
        setAppParamData : function(dbRowData, callback){
            var rowLength = dbRowData.length;
            var tmpAppParamData = {};
            var tmpAppParamVisibleData = {};
            PARAMLIBRARY.bshelf_data = {};
            for(var i=0; i<rowLength; i++){
                var row = dbRowData.item(i);
                        
                var d =  new Date( row.down_date * 1000 ),
                    year  = d.getFullYear(),
                    month = d.getMonth() + 1,
                    day  = d.getDate(),
                    hour = ( d.getHours()   < 10 ) ? '0' + d.getHours()   : d.getHours(),
                    min  = ( d.getMinutes() < 10 ) ? '0' + d.getMinutes() : d.getMinutes(),
                    sec   = ( d.getSeconds() < 10 ) ? '0' + d.getSeconds() : d.getSeconds(),
                    downDate = year + '/' + month + '/' + day + ' ' + hour + ':' + min + ':' + sec;
                
                var appSetObj = {
                    app_book_id     : row.app_book_id,
                    bookPath        : row.bookPath,
                    thumbPath       : row.thumbPath,
                    thumb_w         : row.thumb_w,
                    thumb_h         : row.thumb_h,
                    selected        : row.selected,
                    status          : row.status,
                    down_date       : downDate,
                    objcontents      : JSON.parse(row.objcontents),
                    eventType       : row.eventType,
                    cate_seq        : row.cate_seq,
                    procQueuStatus  : row.procqueu_status,
                    procWaitBusy    : row.procwait_busy,
                    planType        : row.plan_type,
                    sortno          : row.sortno
                }
                tmpAppParamData[row.app_book_id] = appSetObj;
                if (appSetObj.objcontents.sel_disttype == 'download') {
                    tmpAppParamVisibleData[row.app_book_id] = appSetObj;
                }
            }
            
            PARAMLIBRARY.bshelf_data = tmpAppParamData;
            PARAMLIBRARY.visible_data = tmpAppParamVisibleData;
            callback();
        },      
        
        nalert : function(text, title, callbackOk){
            libStore.alert(text, title, callbackOk);
        },
        
        appAlert : function(text, title, callbackOk){
            navigator.notification.alert(
                text,
                function(){ if( callbackOk ) callbackOk(); },
                title,
                'OK'
            );
        },
        
        showConfirm : function(text, title, callbackOk, callbackCancel){
            if (typeof title === 'function') {
                callbackCancel = arguments[2];
                callbackOk = arguments[1];
                title = undefined;
            }

            libStore.confirm(text, title, callbackOk, callbackCancel);
        },
        
        /*bookshelf -> view open */
        createView : function(appid){
            if( appFlag == false ) return false;
            libStore._loadingImgView('show');
            $webApiRouter.openedViewer();

            PARAMLIBRARY.createViewInfo = PARAMLIBRARY.bshelf_data[appid];
            PARAMLIBRARY.isAppBookshelfFlag = true;

            if( cloudFlag && PARAMDATA.portalFlag == false )
                PARAMLIBRARY.createViewInfo.userid = PARAMDATA.memInfo.userid; 

            PARAMLIBRARY.isAppBookshelfFlag = true;
            libStore.htmlViewerElem.html(libStore.htmlviewer);
            
        },
        
        /*psy20150805*/
        createViewStream : function(dbObj, bookObj){
            libStore.htmlLibraryElem.addClass('disable');

            console.log('createViewStream', bookObj);
            PARAMLIBRARY.createViewInfo = dbObj;

            if( 'keyword' in bookObj ){
                //全文検索
                PARAMLIBRARY.createViewSeachInfo = {
                    keyword : ""+bookObj.keyword,
                    page : bookObj.page,
                    type : "OR"   //OR, AND
                };
            }


            //PARAMLIBRARY.createViewInfo.bookSeq = bookObj.bookSeq;
            //PARAMLIBRARY.createViewInfo.memId = bookObj.memId;
            PARAMLIBRARY.isAppBookshelfFlag = false;
            
            libStore.htmlViewerElem.removeClass('disable').html(libStore.htmlviewer);
        },
        
        startBookOpen : function(dnObj) {
            $appFront.setDownloadInfoDB(dnObj, function(dnData){
                this.createView(dnObj.app_book_id);
            });
        },
        startBookDownload : function(dnObj){
            PARAMLIBRARY.new_bs_cate_seq = 0;
            PARAMLIBRARY.new_bs_cate_title = "";
            if(appFlag == true){
                //download STEP2
                console.log('startBookDownload');
                $appFront.setDownloadInfoDB(dnObj, function(dnData){
                    //sort date
                    $appFront.getLibrarybshelfDBData(function(dbRowsData){
                        /*DB DATA GET*/
                        $appFront.setAppParamData(dbRowsData, function(){
                        
                            $(document).trigger(dnData.eventType, dnData);
                            setTimeout(function(){
                                $appFront.serverToApplicationZipDownlaod(dnData);
                            }, 300);
                        
                        });
                    });
                    
                });
            }else {
                frontWorker.postMessage({cmd : dnObj.selected, returnData : dnObj});
            }
        },

        forceDeleteBookDownload : function(dnObj, callback){
            console.log('----------forceDeleteBookDownload-------------', dnObj);
            try{
                console.log('----fileTransfer.abort()------');
                fileTransfer.abort();
            }catch(e){}

            $appFront.libraryBookDeleteDB(dnObj.app_book_id, function(data){ 
                var bookPath = $appFront.appDocPath+'/'+dnObj.bookPath;
                exec(
                    function(data){
                        console.log('----------forceDeleteBookDownload BOOK DELETE END -------------');
                        console.log(data);
                        callback();
                        
                    },function(){
                        console.log('forceDeleteBookDownload BOOK DELETE Error');
                        callback();
                    },
                    'appWisebookController',
                    'bookDeleteProcessing',
                    [bookPath]
                );
            });
        },

        cancelBookDownload : function(cancelId, callback){
            $appFront.cancelObj = PARAMLIBRARY.bshelf_data[cancelId];
            //$appFront.cancelObj = cancelId;
            if(appFlag == true){
                console.log('----------cancelBookDownload-------------');
                console.log($appFront.cancelObj);
                if($appFront.cancelObj.status == 100){
                    
                    $appFront.deleteBookData($appFront.cancelObj.app_book_id);
                
                }else if($appFront.cancelObj.status == 3){
                    
                    $appFront.nalert(PARAMDATA.lang.message.cancel_unziping, 'CANCEL');
                    
                }else{
                    try{
                        console.log('----fileTransfer.abort()------');
                        fileTransfer.abort();
                    }catch(e){
                        //alert('cancelBookDownload');
                        $appFront.cancelBookError();
                    }
                    
                    
                }
                callback();
            }else{
                frontWorker.postMessage({cmd :'downloadCancel', returnData : $appFront.cancelObj});
            }
        },
        
        deleteBookData : function(deleteId){
            var deleteObj = PARAMLIBRARY.bshelf_data[deleteId];
            var sql = '';
            if(appFlag == true){
                var bookPath = $appFront.appDocPath+'/'+PARAMLIBRARY.bshelf_data[deleteId].bookPath;
                console.log('----------deleteBook-------------', bookPath);

                $.extend( PARAMLIBRARY.bshelf_data[deleteId], { status: 80, procQueuStatus : 'E', procWaitBusy : 0 } );
                $(document).trigger( deleteObj.eventType, PARAMLIBRARY.bshelf_data[deleteId] );
                //DB STATUS UPDATE
                sql = 'UPDATE {table} SET status=? WHERE app_book_id=?';
                $appFront.libraryUpdate(sql, [80, deleteObj.app_book_id]);
                
                //DB 削除SEEP status -> 80
                console.log('----------deleteBook START DB DELETE : 80 -------------');
                $appFront.libraryBookDeleteDB(deleteId, function(data){
                    
                    console.log('----------deleteBook BOOK DELETE : 85 -------------');
                    $.extend( PARAMLIBRARY.bshelf_data[deleteId], { status: 85 } );
                    $(document).trigger( deleteObj.eventType, PARAMLIBRARY.bshelf_data[deleteId] );
                    
                    exec(
                        function(data){
                            console.log('----------deleteBook BOOK DELETE END -------------');
                            console.log(data);
                            $.extend( PARAMLIBRARY.bshelf_data[deleteId], { status: 89 } );
                            
                            $(document).trigger( deleteObj.eventType, PARAMLIBRARY.bshelf_data[deleteId] );
                         
                            for(var key in PARAMLIBRARY.bshelf_data)
                                if(PARAMLIBRARY.bshelf_data[key].procQueuStatus == "W" && PARAMLIBRARY.bshelf_data[key].procWaitBusy == 80) return;
                         
                            $webApiRouter.setDeleteStatus("0");
                            libBookShelf.refresh();
                         
                        },function(){
                            console.log('deleteBook BOOK DELETE Error');
                        },
                        'appWisebookController',
                        'bookDeleteProcessing',
                        [bookPath]
                    );
                });
            }
        },
        
        sortNoUpdate : function(){
            for( var appkey in PARAMLIBRARY.bshelf_data ){
                if( PARAMLIBRARY.bshelf_data[appkey].sortno == null ) {
                    console.log(PARAMLIBRARY.bshelf_data[appkey]);
                    continue;
                }
                var updateSql = 'UPDATE bshelf SET sortno=? WHERE app_book_id=?';
                $appFront.query( updateSql, [PARAMLIBRARY.bshelf_data[appkey].sortno, PARAMLIBRARY.bshelf_data[appkey].app_book_id], function(){
                   
                });
            }
            
            PARAMLIBRARY.bshelf_data = libStore.object_sort( PARAMLIBRARY.bshelf_data, "sortno", "desc", true );
        }
    };
    
    /***********************************************************
        hybrid ACCESS ZIP
    ***********************************************************/
    applicationAccess = {
        //download STEP3
        serverToApplicationZipDownlaod : function(dnObj){
            console.log('--------------serverToApplicationZipDownlaod---------------',dnObj);
            var sql='';
            $.extend(PARAMLIBRARY.bshelf_data[dnObj.app_book_id], { status: 2 });
            
            //status update 2
            sql = 'UPDATE {table} SET status=? WHERE app_book_id=?';
            $appFront.libraryUpdate(sql, [2, dnObj.app_book_id]);
            
            $(document).trigger(dnObj.eventType, PARAMLIBRARY.bshelf_data[dnObj.app_book_id]);    
            
            //file server to temp
            fileTransfer = new FileTransfer();
            var zipName = $appFront.appTmpPath+dnObj.app_book_id+'.zip';
            
            //progress
            fileTransfer.onprogress = function(progressEvent){
                if (progressEvent.lengthComputable) {
                    
                    var progressVal = ((progressEvent.loaded / progressEvent.total)*100) +'%';
                    $.extend(PARAMLIBRARY.bshelf_data[dnObj.app_book_id], { progress: progressVal });
                    $(document).trigger(dnObj.eventType, PARAMLIBRARY.bshelf_data[dnObj.app_book_id]);
                }
            };

            if (dnObj.objcontents.sel_disttype == "stream") {
                downUrl = dnObj.objcontents.streaming;
            } else {
                downUrl = dnObj.objcontents.download;
                if( typeof viewdefind != "undefined" ) {
                    console.log('ダウンロードを開始しました。');
                    $(document).trigger(viewdefind.VIEW_MESSAGE_FADE_TYPE, 'ダウンロードを開始しました。');
                }
            }

            //ict edit
            if(downUrl.indexOf('http://')==0){
              downUrl = downUrl.replace('http://','https://');
            }


            if( cloudFlag && PARAMDATA.portalFlag == false ) downUrl +="&user="+ PARAMDATA.memInfo.userid;
            
            console.log(downUrl);
            console.log(zipName);
            
            fileTransfer.download(
                downUrl,
                zipName,
                function(){
                    //status update 3
                    sql = 'UPDATE {table} SET status=? WHERE app_book_id=?';
                    $appFront.libraryUpdate(sql, [3, dnObj.app_book_id]);
                
                    $.extend( PARAMLIBRARY.bshelf_data[dnObj.app_book_id], { status: 3 } );
                    $(document).trigger( dnObj.eventType, PARAMLIBRARY.bshelf_data[dnObj.app_book_id] );
                    
                    setTimeout(function(){
                        $appFront.bookUnzipProcessing(zipName, dnObj);
                    }, 500);
                },
                function(err){
                    console.log('-------------fileTransfer ERROR---------------');
                    console.log(err);
                    
                    switch(err.code){
                        case 3 : 
                            //FileTransferError.CONNECTION_ERR
                            console.log('-------------fileTransfer ERROR CODE 3 CONNECTION_ERR---------------');
                            
                            console.log( PARAMLIBRARY.bshelf_data[dnObj.app_book_id] );
                            
                            var tmpCancelAppBookObj = PARAMLIBRARY.bshelf_data[dnObj.app_book_id];
                            
                            if( tmpCancelAppBookObj.selected == 'update' ){
                                $appFront.nalert(err.http_status+' error', 'update error');
                                $appFront.timemachineUpdateData( tmpCancelAppBookObj );
                            }else{
                                $appFront.nalert(err.http_status+' error', 'download error');
                            
                                $.extend( PARAMLIBRARY.bshelf_data[dnObj.app_book_id], { eventType : 'cancelBookdownload' } );
                                $appFront.cancelObj = PARAMLIBRARY.bshelf_data[dnObj.app_book_id];
                                
                                $appFront.cancelBookError();
                            }
                        break;
                            
                        case 4 :
                            //FileTransferError.ABORT_ERR
                            console.log('-------------fileTransfer ERROR CODE 4 ABORT_ERR---------------', $appFront.cancelObj);
                            if( $appFront.cancelObj != null )
                                $appFront.cancelBookError();
                        break;
                        
                        default :
                            if( err.http_status == 404 ){
                                console.log('------------- 404 error ---------------');
                                $appFront.appAlert('404 error', 'FILE TRANSFER');
                            }else{
                                $appFront.appAlert('error', 'FILE TRANSFER');
                            }
                            if( PARAMLIBRARY.bshelf_data[dnObj.app_book_id].app_book_id != null ){
                                $.extend( PARAMLIBRARY.bshelf_data[dnObj.app_book_id], { eventType : 'cancelBookdownload' } );
                                $appFront.cancelObj = PARAMLIBRARY.bshelf_data[dnObj.app_book_id];
                                $appFront.cancelBookError();
                            }
                            
                        break;
                    }
                    
                    $(document).trigger( 'bookDownloadingError.viewer' );
                },
                true
            );
        },
        saveDownCount : function(){
            var bookinfoUrl = PARAMDATA.manifest.down_count + '?store_book_id=' + PARAMDATA.downloadQueue[0].objcontents.bookid + '&mem_id=' + PARAMDATA.downloadQueue[0].objcontents.author + '&user_id=' + PARAMLIBRARY.user_id + '&flag=save&os_tp=' + PARAMDATA.ostp;
            console.log("ajax for " + bookinfoUrl);
            $.ajax({
                url         : bookinfoUrl,
                type        : 'GET',
                dataType    : 'json',
                async       : false,
                cache       : false,
                success     : function(jsonData){
                  console.log("saveDownCount done ");
                  console.log(jsonData);
                },
                error       : function(a,b,c){
                  console.log("saveDownCount error ");
                  console.log(a);
                  console.log(b);
                  console.log(c);

                }
            });
        },
        timemachineUpdateData : function( obj ){
            console.log('-------------timemachineUpdateData---------------');
            var timemachineObj = $appFront.timeMachineObj;
            if( timemachineObj == null ) timemachineObj = PARAMLIBRARY.bshelf_data[obj.app_book_id];
            
            var tmpDown_date = Math.round(new Date(timemachineObj.down_date).getTime() / 1000);
            
            $.extend(PARAMLIBRARY.bshelf_data[obj.app_book_id], { status: 100, thumbPath : timemachineObj.thumbPath, down_date : timemachineObj.down_date, procQueuStatus : 'E', procWaitBusy : 0});

            var sql = 'UPDATE {table} SET status=?, thumbPath=?, down_date=?, procqueu_status=?, procwait_busy=? WHERE app_book_id=?';
            $appFront.libraryUpdate(sql, [100, timemachineObj.thumbPath, tmpDown_date, 'E', 0, obj.app_book_id]);
            
            $(document).trigger( PARAMLIBRARY.bshelf_data[obj.app_book_id].eventType, PARAMLIBRARY.bshelf_data[obj.app_book_id] );
        },
        
        cancelBookError : function(){
            //download cancel 
            console.log('-------------DOWLOAD CANCEL status : 50---------------');
            $.extend(PARAMLIBRARY.bshelf_data[$appFront.cancelObj.app_book_id], {status : 50})
            console.log(PARAMLIBRARY.bshelf_data[$appFront.cancelObj.app_book_id]);
            $(document).trigger( $appFront.cancelObj.eventType, PARAMLIBRARY.bshelf_data[$appFront.cancelObj.app_book_id] );
            
            console.log('-------------DOWLOAD CANCEL status : 59 DB 削除---------------');
            $appFront.libraryBookDeleteDB($appFront.cancelObj.app_book_id, function(data){
                setTimeout(function(){
                    $.extend(PARAMLIBRARY.bshelf_data[$appFront.cancelObj.app_book_id], {status : 59});
                    $(document).trigger( $appFront.cancelObj.eventType, PARAMLIBRARY.bshelf_data[$appFront.cancelObj.app_book_id] );
                    $appFront.cancelObj = {};
                }, 1000);
            });
        },
                
        //download STEP4 END
        bookUnzipProcessing : function(zipName, dnObj){
            console.log('---------------bookUnzipProcessing-----------------');
            
            var sql = '', sqlData = [];
            var tempAuthorToPath = ( PARAMDATA.portalFlag == true ) ? "portal_"+dnObj.objcontents.author : dnObj.objcontents.author;
            var bookFolderName = PARAMLIBRARY.user_id == '' ? dnObj.objcontents.bookid : PARAMDATA.memInfo.auth + '_' + PARAMLIBRARY.user_id + '_' + dnObj.objcontents.bookid;

            exec(
                function(data){
                    //success
                    //bookPath, down_date, thumbPath ,thumb.jpg
                    var bookPath = data.path+'/',
                        thumbPath = bookPath+'thumb.jpg';
                    
                    if(dnObj.objcontents.sel_disttype == 'stream') {
                        bookPath = dnObj.bookPath;
                    }
                    // else {
                    //     bookPath = $appFront.appDocPath+'/'+bookPath;
                    // }
                    
                    var nowDate = Math.round(new Date().getTime() / 1000);
                    var d = new Date( nowDate * 1000 ),
                        year  = d.getFullYear(),
                        month = d.getMonth() + 1,
                        day  = d.getDate(),
                        hour = ( d.getHours()   < 10 ) ? '0' + d.getHours()   : d.getHours(),
                        min  = ( d.getMinutes() < 10 ) ? '0' + d.getMinutes() : d.getMinutes(),
                        sec   = ( d.getSeconds() < 10 ) ? '0' + d.getSeconds() : d.getSeconds(),
                        down_date = year + '/' + month + '/' + day + ' ' + hour + ':' + min + ':' + sec;
                    
                    sql = 'UPDATE {table} SET bookPath=?, thumbPath=?, status=?, down_date=?, procqueu_status=?, procwait_busy=? WHERE app_book_id=?';
                    sqlData = [bookPath, thumbPath, 100, nowDate, 'E', dnObj.procWaitBusy, dnObj.app_book_id];
                    $appFront.libraryUpdate(sql, sqlData);
                    $.extend( PARAMLIBRARY.bshelf_data[dnObj.app_book_id], { bookPath : bookPath, thumbPath : thumbPath,  status: 100,  down_date : down_date, procQueuStatus : 'E', procWaitBusy : dnObj.procWaitBusy} );



                    if (dnObj.selected == 'download') {
                        if(dnObj.objcontents.sel_disttype == 'stream'){
                          if( typeof viewdefind != "undefined" ){
                                $(document).trigger(viewdefind.VIEW_MESSAGE_FADE_TYPE, '本棚に追加しました。');
                           }
                        }else{
                          if( typeof viewdefind != "undefined" ){
                                $(document).trigger(viewdefind.VIEW_MESSAGE_FADE_TYPE, '本棚に追加しました。');
                           }

                            $appFront.saveDownCount();
                        }
                    };
                    setTimeout(function(){
                        $(document).trigger( dnObj.eventType, PARAMLIBRARY.bshelf_data[dnObj.app_book_id] );
                    }, 1000);
                    
                },
                function(err){
                    console.log('-----------------bookUnzipProcessing ERROR---------------------');
                    console.log(err);
                    
                    $appFront.nalert('bookUnzipProcessing ERROR', 'bookUnzipProcessing');
                    
                    $.extend( PARAMLIBRARY.bshelf_data[dnObj.app_book_id], { eventType : 'cancelBookdownload' } );
                    $appFront.cancelObj = PARAMLIBRARY.bshelf_data[dnObj.app_book_id];
                    $appFront.cancelBookError();
                    
                },
                'appWisebookController',
                'unzipProcessing',
                [zipName, tempAuthorToPath, dnObj.objcontents.bookid]
            );
        }
    }
    
    /***********************************************************
        SQL LITE
    ***********************************************************/
    sqlLite = {
        bsTable         : 'bshelf',
        viewTable       : 'viewer',
        optionTable     : 'option',
        memberInfoTable : 'memberinfo',
        
        query : function(sql, params, callbank, callbackErr){

            if( typeof(params) == 'undefined' || params == null) params = [];
            console.log('-------------query-----------------', sql);
            console.log('-------------query params-----------------', params);
            wisebookDB.transaction(
                function(tx){
                    tx.executeSql(sql, params, function(tx, res){
                        if( callbank ) callbank({tx:tx, res:res});
                    });
                },
                function(err){
                    console.log('--------db error-------------');
                    console.log(err);
                    if( callbackErr ) callbackErr(err);
                    
                    //error
                    return err;
                }
            );
        },
        
        getLibrarybshelfDBData : function(callback){
            console.log('START LIBRARY GET DB DATA');
            var that = this,
                sql, sqldata=[];
            
            if( cloudFlag == true  ){
                if( this.vaildPortal == false ){
                    this.vaildPortal = true;
                    this.dbValidate();
                }else if( that.validCloud == false ){
                    this.validCloud = true;
                    this.dbValidate();
                }

                sql = 'SELECT * FROM '+that.bsTable+' WHERE plan_type=? ORDER BY sortno DESC';
                sqldata = (PARAMDATA.portalFlag == true) ? ["portal"] : ["cloud"];
            }else{
                sql = 'SELECT * FROM '+that.bsTable+' ORDER BY sortno DESC';
            }
                
            that.query(sql, sqldata, function(dbData){
                callback(dbData.res.rows);
            });
        },
        
        
        setStreamInfoDB : function( dnObj, callbank ){
            console.log("setStreamInfoDB");
        
            var that = this,
                nowDate = Math.round(new Date().getTime() / 1000),
                sql = '',
                sqlData = [];
            
           //var plan_type = "library"
           //if( cloudFlag == true )  plan_type = ( PARAMDATA.portalFlag == true ) ? "portal" : "cloud";
        },
        
        openBookInsertDB : function(dnObj, callback) {
            console.log('insertBookshelfDB');
            
            var that = this,
                nowDate = Math.round(new Date().getTime() / 1000),
                sql = '',
                sqlData = [];
            
            var plan_type = "library"
            if( cloudFlag == true )  plan_type = ( PARAMDATA.portalFlag == true ) ? "portal" : "cloud";
            console.debug(dnObj);
            sql = 'INSERT INTO '+that.bsTable+' (app_book_id, bookPath, selected, status, down_date, objcontents, cate_seq, procqueu_status, procwait_busy, plan_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
            sqlData = [ dnObj.app_book_id, dnObj.bookPath, dnObj.selected, 100, nowDate, JSON.stringify(dnObj.objcontents), 0, 'E', 0, plan_type];

            console.log(sql);
            console.log(sqlData);
            
            that.query(sql, sqlData, function(data){
                var setAppParam = {
                    app_book_id     : dnObj.app_book_id,
                    bookPath        : dnObj.bookPath,
                    thumbPath       : dnObj.thumbPath,
                    thumb_w         : dnObj.thumb_w,
                    thumb_h         : dnObj.thumb_h,
                    selected        : dnObj.selected,
                    status          : 100,
                    down_date       : nowDate,
                    objcontents      : dnObj.objcontents,
                    eventType       : dnObj.eventType,
                    procWaitBusy    : 0,
                    planType        : plan_type,
                    sortno          : dnObj.sortno
                }
                
                setAppParam.cate_seq = 0;
                setAppParam.procQueuStatus = 'E';
                setAppParam.procWaitBusy = 0;
                callback(setAppParam);
            });
        },
        
        //download STEP1
        setDownloadInfoDB : function(dnObj, callbank){
            console.log('setDownloadInfoDB');
            
            var that = this,
                nowDate = Math.round(new Date().getTime() / 1000),
                sql = '',
                sqlData = [];
            
            var plan_type = "library"
            if( cloudFlag == true )  plan_type = ( PARAMDATA.portalFlag == true ) ? "portal" : "cloud";
            console.debug(dnObj);
            if(dnObj.selected == 'download'){
                var dbObj = libStore.checkDownloadData(dnObj.app_book_id);
                if(dbObj) {
                    sql = 'UPDATE '+that.bsTable+' SET thumbPath=?, thumb_w=?, thumb_h=?, selected=?, status=?, down_date=?, objcontents=?, procqueu_status=?, procwait_busy=?, sortno=? WHERE app_book_id=?';
                    sqlData = [dnObj.thumbPath, dnObj.thumb_w, dnObj.thumb_h, dnObj.selected, 1, nowDate, JSON.stringify(dnObj.objcontents), dnObj.procQueuStatus, dnObj.procWaitBusy, dnObj.sortno, dnObj.app_book_id];
                }
                else {
                    sql = 'INSERT INTO '+that.bsTable+' (app_book_id, bookPath, thumbPath,  thumb_w, thumb_h, selected, status, down_date, objcontents, eventType, cate_seq, procqueu_status, procwait_busy, plan_type, sortno) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)';
                    sqlData = [ dnObj.app_book_id, dnObj.bookPath, dnObj.thumbPath, dnObj.thumb_w, dnObj.thumb_h, dnObj.selected, 1, nowDate, JSON.stringify(dnObj.objcontents), dnObj.eventType, 0, 'E', 0, plan_type, dnObj.sortno];
                }
            }else if(dnObj.selected == 'update'){
                sql = 'UPDATE '+that.bsTable+' SET thumbPath=?, thumb_w=?, thumb_h=?, selected=?, status=?, down_date=?, objcontents=?, procqueu_status=?, procwait_busy=? WHERE app_book_id=?';
                sqlData = [dnObj.thumbPath, dnObj.thumb_w, dnObj.thumb_h, dnObj.selected, 1, nowDate, JSON.stringify(dnObj.objcontents), dnObj.procQueuStatus, dnObj.procWaitBusy, dnObj.app_book_id];
            }
            
            console.log(sql);
            console.log(sqlData);
            console.log(callbank);
            that.query(sql, sqlData, function(data){
                var setAppParam = {
                    app_book_id     : dnObj.app_book_id,
                    bookPath        : dnObj.bookPath,
                    thumbPath       : dnObj.thumbPath,
                    thumb_w         : dnObj.thumb_w,
                    thumb_h         : dnObj.thumb_h,
                    selected        : dnObj.selected,
                    status          : 1,
                    down_date       : nowDate,
                    objcontents      : dnObj.objcontents,
                    eventType       : dnObj.eventType,
                    procWaitBusy    : 0,
                    planType        : plan_type,
                    sortno          : dnObj.sortno
                }
                
                if(dnObj.selected == 'download' ) {
                    setAppParam.cate_seq = 0;
                    setAppParam.procQueuStatus = 'E';
                    setAppParam.procWaitBusy = 0;
                    
                }else if(dnObj.selected == 'update' ) {
                    setAppParam.procQueuStatus = 'W';
                    setAppParam.procWaitBusy = dnObj.procWaitBusy; 
                }
                
                callbank(setAppParam);
            });
        },
        
        libraryUpdate : function( updateSql, params){
            console.log('--------------libraryUpdate--------------------');
            var that = this;
            var sql = updateSql.replace("{table}", that.bsTable);
            console.log(sql);
            that.query(sql, params, function(data){
                console.log(data);
            });
        },
        
        libraryBookDeleteDB : function(appBookid, callback){
            //delete前にupdate sortno 20150405
            var sql='', sqlData,
                deleteSortno = PARAMLIBRARY.bshelf_data[appBookid].sortno;
            
            for( var appkey in PARAMLIBRARY.bshelf_data ){
                if( PARAMLIBRARY.bshelf_data[appkey].selected == "open" ) continue;

                var tmpSortno = PARAMLIBRARY.bshelf_data[appkey].sortno;

                if( tmpSortno > deleteSortno )
                    PARAMLIBRARY.bshelf_data[appkey].sortno -= 1;
            }
            this.sortNoUpdate();            
            
            sql = 'DELETE FROM bshelf WHERE app_book_id = ?';
            sqlData = [appBookid];
            
            //view db data delete
            $appFront.query(sql, sqlData, function(data){
                sql = 'DELETE FROM '+$appFront.viewTable+' WHERE app_book_id = ?';
                $appFront.query(sql, sqlData, function(data){
                    console.log('-----------DELETE viewer appBookid---------------');
                });
                sql = 'DELETE FROM '+$appFront.optionTable+' WHERE app_book_id = ?';
                $appFront.query(sql, sqlData, function(data){
                    console.log('-----------DELETE option appBookid---------------');
                });
                callback(data);
            });
            
            
        },
        
        setMemberInfo : function(memInfoData){
            console.log('--------------setMemberInfoDB--------------------');
            var sql = 'UPDATE '+$appFront.memberInfoTable+' SET info=? WHERE author=?';
            $appFront.query(sql, [JSON.stringify(memInfoData),  PARAMDATA.libInfo.auth], function(data){
                console.log(data);
            });
        },
        
        bsCateSeq_update : function( appid ){
            var sql = 'UPDATE {table} SET cate_seq=? WHERE app_book_id=?';
            var updateObj = PARAMLIBRARY.bshelf_data[appid];
            
            if(updateObj){
                $appFront.libraryUpdate(sql, [updateObj.cate_seq, updateObj.app_book_id]);
            }
        },
        
        setProcWaitBusy : function( data ) {
            var sql = 'UPDATE {table} SET procwait_busy=? WHERE app_book_id=?';
            $appFront.libraryUpdate(sql, [data.procWaitBusy, data.app_book_id]);
        }
    };
    
})();

h5applib = new appFront();
