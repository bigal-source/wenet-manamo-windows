/*************************************************************************************
	DB ADMIN VERSION 
**************************************************************************************/
(function(){
	var wisebookDB;
	
	window.dbAdmin = function(){
	};
	
	dbAdmin.prototype = {
		DATABASE_NAME 		: 'wisebook.db',
		DATABASE_VERSION 	: 3,
		NOW_VERSION			: 0,
		bsTable 			: 'bshelf',
		viewTable 			: 'viewer',
		optionTable 		: 'option',
		memberInfoTable 	: 'memberinfo',
		
		bsTableItems		: null,
		
		createDB : function( callback ){
			var that = this;
			wisebookDB = window.sqlitePlugin.openDatabase({name: this.DATABASE_NAME});
			console.trace();
			
			wisebookDB.transaction(
				function(tx) {
					tx.executeSql(
						'PRAGMA user_version',
						[],
						function(tx, res){
							var row = res.rows.item(0);
							that.NOW_VERSION = row.user_version;
							
							if( that.NOW_VERSION == 0 ) that.newDeviceIniti(callback);
							else {
								if( that.DATABASE_VERSION > that.NOW_VERSION ){
									tx.executeSql(
										'PRAGMA table_info('+that.bsTable+')',
										[],
										function(tx, infoRes){
											that.bsTableItems = infoRes.rows;
											that.userVersion( callback, that.NOW_VERSION+1 );
										}
									);
								}else callback( wisebookDB );
							}
							console.trace();
						}
					);
				}
				
			);
		},

		newDeviceIniti : function(callback){
			var that = this,
				sql='';

			sql = 'CREATE TABLE IF NOT EXISTS '+that.bsTable+' (id integer primary key AUTOINCREMENT, app_book_id text unique NOT NULL, bookPath text, thumbPath text, thumb_w integer, thumb_h integer, selected text, status integer, down_date date, objcontents text, eventType text, cate_seq integer, procqueu_status text, procwait_busy integer, plan_type text, sortno integer)';
			this.query(sql, null);

			sql = 'CREATE TABLE IF NOT EXISTS '+that.memberInfoTable+' (author text unique NOT NULL, info text, loginAutoinfo text)';
			this.query(sql, null);

			sql = 'CREATE TABLE IF NOT EXISTS '+that.viewTable+' (app_book_id text NOT NULL, module text, page integer, dataobj text)';
			this.query(sql, null);
				
			sql = 'CREATE TABLE IF NOT EXISTS '+that.optionTable+' (app_book_id text NOT NULL, setting text, lastpage text)';
			this.query(sql, null);

			that.query('PRAGMA user_version='+that.DATABASE_VERSION, null,
				function(){}
			);
			console.log("new Device DB initi ok");
			callback(wisebookDB);
		},
		
		/* db version update*/
		userVersion : function( callback, versionNo ){
			var that = this,
				sql = "",
				temVersion = versionNo;
			
			if( temVersion > this.DATABASE_VERSION ){
				callback(wisebookDB); 
				return false;
			}
			
			switch( temVersion ){
				case 1 :
					var existColumn = this.existsColumn(that.bsTableItems, "plan_type");
					if( !existColumn ){
						sql = 'ALTER TABLE '+that.bsTable+' ADD plan_type text COLUMN';
						this.query( sql, null,
							function(){
								console.log(" db plan_type column add ");
								that.query( 'PRAGMA user_version='+temVersion, null,
									function(){
										that.userVersion( callback, temVersion+1 );
									}
								);
							}
						);
					}else{
						that.userVersion( callback, temVersion+1 );
					}
					break;
				case 2 :					
					var existColumn = this.existsColumn(that.bsTableItems, "sortno");

					if( !existColumn ){
						sql = 'ALTER TABLE '+that.bsTable+' ADD sortno integer COLUMN';
						this.query( sql, null,
							function(dbData){
								
								console.log("db sortno column add");
								that.query( 'PRAGMA user_version='+temVersion, null,
									function(){
										that.userVersion( callback, temVersion+1 );
									}
								);								
							}
						);
					}else{
						this.userVersion( callback, temVersion+1 );
					}					
					break;
				case 3 :
					
					//objcontens -> rename objcontents
					var existColumn = this.existsColumn(that.bsTableItems, "objcontents");
					if( !existColumn ){
						sql = 'ALTER TABLE '+that.bsTable+' ADD objcontents text COLUMN';
						
						this.query( sql, null,
							function(){
								sql = 'UPDATE '+that.bsTable+' SET objcontents = objcontens';
								that.query( sql, null,
									function(){
										that.query( 'PRAGMA user_version='+temVersion, null,
											function(){
												that.userVersion( callback, temVersion+1 );
											}
										);
									}
								);
							}
						);
					}else{
						this.userVersion( callback, temVersion+1 );
					}
					break;

			}			
		},
		
		existsColumn : function(rows, checkColumn){
			var rowLength = rows.length;
			for(var i=0; i<rowLength; i++){
				var row = rows.item(i);
				if( row.name == checkColumn ) return true;
			}
			
			return false;
		},
		
		query : function(sql, params, queryCallbank, callbackErr){
			if( !params ) params = [];
			
			wisebookDB.transaction(
				function(tx){
					console.log("db admin", sql);
					tx.executeSql(sql, params, function(tx, res){
						if( queryCallbank ) queryCallbank({tx:tx, res:res});
					});
				},
				function(err){
					console.log('--------db error  DB ADMIN-------------');
					console.log(err);
					if( callbackErr ) callbackErr(err);
					return err;
				}
			);
		}
		
	};
	
})();
