deviceWiseBook = '';
device7inch = false;
iosVersion = 0;
iosDeviceCheck = false;
androidDeviceCheck = false;
libStore = null;
isMobilePhone = false;
androidInfo = {
	androidver : 0,
	appwebkit : 0
}


var utils = (function () {
	var me = {};
	
	me.extend = function (target, obj) {
		for ( var i in obj ) {
			target[i] = obj[i];
		}
	};
	
	me.extend(me, {
		retina : window.devicePixelRatio > 1,
		hasTouch: 'ontouchstart' in window,
		hasPointer: (window.navigator.pointerEnabled || window.navigator.msPointerEnabled) && navigator.msMaxTouchPoints && navigator.msMaxTouchPoints > 1
	});
	
	function _eventType(type){
		var evetType;
		switch (type){
			case 'start' :
				evetType = 'mousedown';
				if(me.hasTouch) evetType = "touchstart";
				else if(me.hasPointer) evetType = window.PointerEvent ? "pointerdown" : "MSPointerDown";
			break;
					
			case 'move' :
				evetType = 'mousemove';
				if(me.hasTouch) evetType = "touchmove";
				else if(me.hasPointer) evetType = window.PointerEvent ? "pointermove" : "MSPointerMove";
			break;
				
			case 'end' :
				evetType = 'mouseup';
				if(me.hasTouch) evetType = "touchend";
				else if(me.hasPointer) evetType = window.PointerEvent ? "pointerup" : "MSPointerUp";
			break;
				
			case 'cancel' :
				evetType = 'mouseup';
				if(me.hasTouch) evetType = "touchcancel";	
				else if(me.hasPointer) evetType = window.PointerEvent ? "pointercancel" : "MSPointerCancel";
			break;
		}
			
		return evetType;
	}
	
	function _vandors(){
		var dummyStyle = document.createElement('div').style
		
		var vendorList = (function () {
			var vendors = 't,webkitT,MozT,msT,OT'.split(','),
				t,
				i = 0,
				l = vendors.length;
			
			for ( ; i < l; i++ ) {
				t = vendors[i] + 'ransform';
				if ( t in dummyStyle ) {
					return vendors[i].substr(0, vendors[i].length - 1);
				}
			}
			
			return false;
		})();
		
		return cssVendor = vendorList ? '-' + vendorList.toLowerCase() + '-' : '';
	}
	
	function prefixStyle(vendor, style){
		if ( vendor === '' ) return style;

		style = style.charAt(0).toUpperCase() + style.substr(1);
		
		return vendor + style;
	}
	
	vandor = _vandors();
	me.extend(me,{
		vandor : vandor,
		transform : prefixStyle(vandor, 'transform'),
		transitionProperty : prefixStyle(vandor, 'transitionProperty'),
		transitionDuration : prefixStyle(vandor, 'transitionDuration'),
		transformOrigin : prefixStyle(vandor, 'transformOrigin'),
		transitionTimingFunction : prefixStyle(vandor, 'transitionTimingFunction'),
		transitionDelay : prefixStyle(vandor, 'transitionDelay')
	});
	
	var start_e = _eventType('start');
	var move_e = _eventType('move');
	var end_e = _eventType('end');
	var cancel_e = _eventType('cancel');  
	
	me.extend(me, {
		RESIZE_EV	: 'resize',
		START_EV 	: start_e,
		MOVE_EV	 	: move_e,
		END_EV		: end_e,
		CANCEL_EV	: cancel_e,
		CLICK_EV	: 'click',
		MOUSE_DW	: 'mousedown',
		MOUSE_MV	: 'mousemove',
		MOUSE_EN	: 'mouseup'
	});

	return me;
})();

function startUiclassLibrary(){
	var sendAjax = [];
	deviceWiseBook = (appFlag) ? appSelectdevice() : selectdevice();
	if( androidDeviceCheck ) $('html').addClass('android');
	
	sendAjax.push( $.ajax({ url : "script/mobile_lite/lang/ja.json", cache:false, dataType:"json", type:"get", success : function(data){ PARAMDATA.lang = data; } }) );
	sendAjax.push( $.ajax({ url : "customer/library_info.json", cache:false, dataType:"json", type:"get", success : function(data){ PARAMDATA.customInfo = data;} }) );	
	
	$.when.apply(null, sendAjax).done(function(){
	    settingLibrary();
	}).fail(function(){
    	console.log("error");
	});
}

function settingLibrary(){
    var stylesheetStr = '';
    //addScripte(PARAMDATA.customInfo.module);
    
    //css 処理
    if( deviceWiseBook == 'ipad' || deviceWiseBook == 'an_Tablet') {
		//pad
		stylesheetStr += addStylesheetStr(PARAMDATA.customInfo.device_css_url.tablet);
		if( androidDeviceCheck ) stylesheetStr += addStylesheetStr(PARAMDATA.customInfo.device_css_url.an_tablet);
				
		loadUrl = PARAMDATA.customInfo.device_html_url.tablet;
	}else if(deviceWiseBook == 'iphone' || deviceWiseBook == 'android'){
		//phone
		isMobilePhone = true;
		
		if( device7inch ) {
			stylesheetStr += addStylesheetStr(PARAMDATA.customInfo.device_css_url.device_7inch);			
			if( androidInfo.androidver <= 4.3 ) stylesheetStr += addStylesheetStr("css_lite/phone/low-android-7inch-level1.css");
		}else {
			stylesheetStr += addStylesheetStr(PARAMDATA.customInfo.device_css_url.phone);
		}
		if( androidInfo.androidver < 4.3 && androidDeviceCheck ) stylesheetStr += addStylesheetStr("css_lite/low-android-level2.css");
		loadUrl = PARAMDATA.customInfo.device_html_url.phone;	
	}
	
	var custom_css_arr = PARAMDATA.customInfo.custom_css_tablet;
	if( isMobilePhone == true ) custom_css_arr = PARAMDATA.customInfo.custom_css_phone;
	if( device7inch ) custom_css_arr = PARAMDATA.customInfo.custom_css_7inch;
	
	if( custom_css_arr.length > 0 ){
		for( var c in custom_css_arr ){
			stylesheetStr += addStylesheetStr( custom_css_arr[c] );
		}
	}
	$('link').after(stylesheetStr);
	
	$('#htmlLibrary').load(loadUrl, function(){
	    libStore = new librarystore();
	    libBookShelf = new libBookshelf();
	});
}

function addScripte(obj){
	for(var i in obj){
		var script = document.createElement('script');
		script.src = obj[i];
    	script.type = 'text/javascript';
    	document.getElementsByTagName('head')[0].appendChild(script);
	}
}

function addStylesheetStr( cssStr ){
	return '<link href="'+cssStr+'" rel="stylesheet" type="text/css" />';
}

function appSelectdevice(){
	var platform = device.platform.toLowerCase(),
		u = navigator.userAgent.toLowerCase(),
		userDevice = "";

	if( platform == "ios" ){
		iosDeviceCheck=true;
		if( u.match(/ipad/i) ){
			userDevice = 'ipad';
		}else{
			userDevice = 'iphone';
			isMobilePhone = true;
		}
	}else if( platform == "android" ){
		androidDeviceCheck = true;

		var tmpAppwebkit_ver = navigator.userAgent.match(/(AppleWebKit\/)\d*.\d*/);
		androidInfo.appwebkit = parseFloat( tmpAppwebkit_ver[0].match(/\d.*/g) );		
		var tmpAndroid_ver =  navigator.userAgent.match(/(Android)\s\d*.\d/g);
		if(!tmpAndroid_ver){tmpAndroid_ver =  navigator.userAgent.match(/(Android)\s\d*/g);};
		androidInfo.androidver = parseFloat( tmpAndroid_ver[0].match(/\d.*/g) );

		
		if( u.match(/mobile/i) ){
			userDevice = "android";
			isMobilePhone = true;
		}else{
			userDevice = "an_Tablet";
		}
		
		console.log( 'size : ', screen.width);

		//7inch check
		var orient = ( screen.width > screen.height ) ?  "landscape" : "portrait";
		if( orient == "portrait" && screen.width >= 600 && screen.width <= 610  ){
			userDevice = 'android';
			device7inch = true;
		}else if( screen.width >= 960 && screen.width <= 970 ) {
			userDevice = 'android';
			device7inch = true;
		}
	}

	return userDevice;
}


function selectdevice(){

	var userDevice = 'ipad';
	if( navigator.userAgent.match(/iPad/i) ) { 
		userDevice = 'ipad';iosDeviceCheck=true;
		var tempVersion = iOSversion();
		iosVersion = tempVersion[0];
	}else if( navigator.userAgent.match(/iPhone/i) ) { 
		userDevice = 'iphone'; iosDeviceCheck=true;
		var tempVersion = iOSversion();
		iosVersion = tempVersion[0];
		isMobilePhone = true;
	}else if( navigator.userAgent.match(/Android/i) ){
		androidDeviceCheck = true;
		
		var tmpAppwebkit_ver = navigator.userAgent.match(/(AppleWebKit\/)\d*.\d*/);
		androidInfo.appwebkit = parseFloat( tmpAppwebkit_ver[0].match(/\d.*/g) );		
		var tmpAndroid_ver =  navigator.userAgent.match(/(Android)\s\d*.\d/g);
		if(!tmpAndroid_ver){tmpAndroid_ver =  navigator.userAgent.match(/(Android)\s\d*/g);};

		androidInfo.androidver = parseFloat( tmpAndroid_ver[0].match(/\d.*/g) );
		
		var android_ver = navigator.userAgent.match(/(Android)\s[0-9]/g);		
		android_ver = android_ver[0].match(/[0-9]/);
		if(android_ver < 4) PARAMLIBRARY._alert(printf(lang.js_str.alert_version_warn, android_ver));
		userDevice = (navigator.userAgent.match(/Mobile/i)) ? 'android' : 'an_Tablet';
		
		//7inch check
		var orient = ( screen.width > screen.height ) ?  "landscape" : "portrait";
		if( orient == "portrait" && window.innerWidth >= 600 && window.innerWidth <= 610  ){
			userDevice = 'android';
			device7inch = true;
		}else if( window.innerWidth >= 960 && window.innerWidth <= 970 ) {
			userDevice = 'android';
			device7inch = true;
		}
	} else if( utils.hasPointer ) {
		userDevice = 'wintouch';
	}
	
	return userDevice;
}

function iOSversion(){
	var v = (navigator.appVersion).match(/OS (\d+)_(\d+)_?(\d+)?/);
	v = (v) ? v : 7; // test
    return [parseInt(v[1], 10), parseInt(v[2], 10), parseInt(v[3] || 0, 10)];
}

function browserLanguage() {
	try {
		return (navigator.browserLanguage || navigator.language || navigator.userLanguage).substr(0,2)
	}catch(e) {
    	return undefined;
	}
}

function imageFitCommonRetWidthHeight(wrapWidth, wrapHeight, imgWidth, imgHeight) {
	var maxWidth = wrapWidth; 
	var maxHeight = wrapHeight;
	var ratio = 0;  
	var width = imgWidth;
	var height = imgHeight;

	var ret_width = width;
	var ret_height = height;

	// Check if the current width is larger than the max
	if(width > maxWidth){
		ratio = maxWidth / width;   // get ratio for scaling image
		ret_width = maxWidth; // Set new width
		ret_height = height * ratio;  // Scale height based on ratio

		height = height * ratio;    // Reset height to match scaled image
	}   

	var width = ret_width;;
	var height = ret_height;

	// Check if current height is larger than max
	if(height > maxHeight){
		ratio = maxHeight / height; // get ratio for scaling image
		ret_height = maxHeight;
		ret_width = width * ratio;    // Scale width based on ratio
		width = width * ratio;    // Reset width to match scaled image
	} 

	var img_sizes = {'width': Math.floor(ret_width), 'height' :Math.floor(ret_height)}; 

	return img_sizes;
}

function thumDataError(elem){
	var topElem = $(elem).attr('data-elem');
	if( topElem ) $('.'+topElem).find('.top-download-status').remove();
}

function handleOpenURL(url){
	if( appFlag == true ){
		setTimeout(function() {
			h5applib.urlScheme(url);
		}, 200);
	}
}

function transitionsview(){
	$(document).trigger(lib_defind.LIBRARY_TRANSITIONS);
}
