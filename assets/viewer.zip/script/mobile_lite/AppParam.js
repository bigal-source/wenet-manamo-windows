(function(window) {	
	window.applibraryParam = function() {
		that = this;
		this._init();
	}
	
	applibraryParam.prototype = {
		splashFlag 		: false,
		responseCheck 	: false,
		sortType		: "sortno",  //reverse, sortno
		createViewInfo : null, // view point info
		createViewSeachInfo : null,

		_initParamSkelton: function() {
			
			this.bshelf_data 			= {};
			this.memberinfo 			= false;
			this.bs_cate_data 			= [];
			this.new_bs_cate_seq		= 0;
			this.new_bs_cate_title		= "";		
		},
		
		_init : function(){
			this._initParamSkelton(); // All Default Skelton
		},

		setbshelf_data : function(callback){
			this.bshelf_data = {};
			//get DB data
            h5applib.getLibrarybshelfDBData( function(dbRowsData){
            	h5applib.setAppParamData(dbRowsData, function(){
                    callback();
                });
            });
		}
	};

})(window); 
PARAMLIBRARY = new applibraryParam();