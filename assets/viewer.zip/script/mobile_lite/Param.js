(function(window) {	
	ParamLib = function() {
		that = this;
		this._init();
	}
	
	ParamLib.prototype = {
		//mobile
		libInfo				: null,
		memInfo 			: {
			auth : "",
			userid : ""
		},

		customInfo			: {},
		lang		       	: null,
		manifest  			: {},

		retina			   	: null,
		windows_pcAndTablet	: null,
		
		inappBrowser		: null,
		
		orient			   	: '',
		screenWidth		   	: 0,
		screenHeight	   	: 0,
		bookTotal_p_h      	: 0,
		bookTotal_l_h	   	: 0,
		
		changsizeflag	   	: false,
		
		processAppid		: null,
		downloadQueue		: [],
		processInterVal		: null,
		processTimer		: 1000,
		
		//custom
		bookAllDataBody		: null,
		photoSlideBody		: null,
		photoSlideObj		: null,
				
		descFlag			: true,
		scrollFlag			: true,
		
		ostp				: '',
		
		plan				: "",	//library, cloud, portal
		portalFlag			: false,
		
		_init : function(){
			this.retina = window.devicePixelRatio > 1;  //ratina
			this.windows_pcAndTablet = window.navigator.pointerEnabled || window.navigator.msPointerEnabled;
		},

		setInfo : function(info){
			if( typeof info == "undefined" ) return false;

			this.ostp = (iosDeviceCheck)? 'I' : 'A';
			/*
                info data : 
                type ->  array  0 : library, cloud, portal 1 : memberid, 2 : userid
                urls -> json "{update_check , update_list ....},  //minifest  
            */
			console.log("info",info);
			
			//member info setting
            if( info.type[0] == "library" ){
                cloudFlag = false;
                this.portalFlag = false;
                $.extend( this.memInfo, { auth : info.type[1], userid : "" } );
                h5applib.bsCateKey = this.memInfo.auth+'_bsCate'; //bookshelf category setting
            }else {
                cloudFlag = true;
                if( info.type[0] == "cloud" ){
                	this.portalFlag = false;
                	$.extend( this.memInfo, { auth : info.type[1], userid : info.type[2] } );

                	h5applib.bsCateKey = 'phonegap-cloud_bsCate';
                }else{
                	//portal
                	this.portalFlag = true;
                	this.memInfo = {};
                	h5applib.bsCateKey = "phonegap-portal_bsCate"; 
                }
            }

            //set manifest
            this.manifest = info.urls;
            console.log("=================================================");
            try{
				if( libStore.isProcessing ){
					var processAppid = that.processAppid;
					PARAMLIBRARY.bshelf_data[processAppid].eventType = 'cancelBookdownload';
							
					if( PARAMLIBRARY.bshelf_data[processAppid].selected == 'update' && PARAMLIBRARY.bshelf_data[processAppid].procWaitBusy == 30 ){
						libUpdate.updateCancelDestroy( processAppid );
					}							
					
					h5applib.forceDeleteBookDownload(PARAMLIBRARY.bshelf_data[processAppid], function(){

						libStore.dowloadDeleteProcessingQueu(processAppid);
						that.processAppid = null;
						libStore.isProcessing = false;

						//get DB data
						PARAMLIBRARY.setbshelf_data(function(){ $(document).trigger(lib_defind.LIBRARY_USERINFOCHANGE); });
					});
				}else{
					//get DB data
					PARAMLIBRARY.setbshelf_data(function(){ $(document).trigger(lib_defind.LIBRARY_USERINFOCHANGE); });
				}
			}catch(e){
				PARAMLIBRARY.setbshelf_data(function(){ $(document).trigger(lib_defind.LIBRARY_USERINFOCHANGE); });
			}
		},
		
		_updatesize : function(){
			this._scrollInit();			
			this._checkOrient();			
		},
		
		_scrollInit : function(){
			if (iosDeviceCheck) {
				$('.page-content').scrollTop(0)
				document.body.scrollLeft = 0;
				document.body.scrollTop = 0;
				setTimeout(function () {
				    document.body.scrollLeft = 0;
				}, 0);
			}
		},
		
		_checkOrient : function(){
			if(iosDeviceCheck){
				if(Math.abs(window.orientation) === 90) this.orient = "landscape";
				else this.orient = "portrait";				
			}else{
				if( window.innerWidth > window.innerHeight ) this.orient = "landscape";
				else this.orient = "portrait";				
			}
		}
	};

	window.ParamLib = ParamLib;

})(window);

PARAMDATA = new ParamLib();
