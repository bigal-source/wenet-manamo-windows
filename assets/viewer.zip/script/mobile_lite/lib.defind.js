(function(){
	library_defind = function(){};
	
	library_defind.prototype = {
        LIBRARY_BOOKSHELFINFO : "library.bookshelfinfo",
        LIBRARY_RESIZE : "library.reisze",

        LIBRARY_TRANSITIONS : "library.transitions",
        LIBRARY_USERINFOCHANGE : "library.userinfochange"

    }
})();
lib_defind = new library_defind();