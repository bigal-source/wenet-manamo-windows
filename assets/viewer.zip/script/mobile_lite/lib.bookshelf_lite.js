(function(window){
	window.libBookshelf = function(options) {
		$bsLib = this;
 this._init();;
	}
	
	libBookshelf.prototype = {
		isResume : false,
		bookShelfStorageData	: [],
        loaded                  : false,
		bshelfViewTypeElem		: null,
		bshelfTypeListElem		: null,
		
		thumb_box_img_w			: 150,
		thumb_box_img_h			: 220,
	
		bookshelfType			: 'box',  //'box', 'list'		
		
		bookshelfEditMode		: false, 
		bookItemCount			: 4,
		
		progressPasue			: false,
		
		bookshelfSelectedBook	: [],    //bookshelf category 
		bsCateSelectBookCount	: 0,	//bookshelf category
		
		expirationBooks				: [],
		expirationServerCheckFlag 	: false,
		
		checkExpireTimer			: null,
		delayTime				  	: 3*60*60*1000, //3H
		
		dragdropChange				: false,
		
		holdWaitStart				: false,
		holdInterval				: null,
		
		_init : function(){
			//android low version tag remove
			//if( androidInfo.androidver < 4.3 && androidDeviceCheck ) $('#bookshelf-category-move-link, .bookshelf-sub-navbar-category').remove();
			if( androidDeviceCheck ) h5applib.keyboardHide();

			this.bshelfViewParentsPageElem = $("#bookshelf-view").parents(".page");
			
			this.bshelfViewTypeElem = $('#bookshelf-view-type');
			this.bshelfTypeListElem = $('#bookshelf-view-list');
			
			this.bshelfBoxItemBaseElement = document.createElement('div');
			this.bshelfListItemBaseElement = document.createElement('div');
			
			libStore.getHtml('devicehtml_lite/planhtml/items/bookshelf/bookshelf-box-item.html', function(data){
				$bsLib.bshelfBoxItemBaseElement.innerHTML = data;
			}, true);
			
			var listItemElemUrl = 'devicehtml_lite/planhtml/items/bookshelf/bookshelf-list-item.html';
			if(isMobilePhone) listItemElemUrl = 'devicehtml_lite/planhtml/items/bookshelf/bookshelf-list-item-phone.html';
			libStore.getHtml(listItemElemUrl, function(data){
				$bsLib.bshelfListItemBaseElement.innerHTML = data;
			}, true);
			
			this.devieceSetting();
			this.bshelfEvent();

			setTimeout(
                       function(){
                       exec(
                            function(){
                            console.log("start");
                            $('#start-now-loading').fadeOut(function(){$(this).remove();});
                            },
                            function(){},
                            'appWisebookController',
                            'libraryInitiationEnd',
                            []
                            )
                       }
                       ,500);
			         

		},
		
		devieceSetting : function(){
			if(isMobilePhone){
				this.thumb_box_img_w = 85;
				this.thumb_box_img_h = 115;
				if(device7inch) {
					this.thumb_box_img_w = 130;
					this.thumb_box_img_h = 215;
				}
			}	
		},
		
		draganddropsortStart : function(e, dragItem){
			if( libStore.isProcessing ){
				h5applib.nalert(PARAMDATA.lang.message.download_one, PARAMDATA.lang.oneword.disttype_download);
				return false;
			}
			
			var handleReady, handleChange, handleEnd, handleResize;
			
			function handleDragDropReady(e, dragdrop){
				dragItem.find(".bshelf-box-thumb-img img").addClass("drag-and-drop-ready").css("webkit-box-reflect", "none");
				dragItem.find(".thumb-box-title").css("visibility", "hidden");
				$bsLib.itemList = [];
				$('.bookshelf-view-box-type .book-item-link').each(function(i, elem){
					var item = $(elem);
					if( item.attr( "sortno" ) ) $bsLib.itemList.push( item.attr( "sortno" ) );
				});
			}
			
			function handleDragDropChange(e, dragdrop){
				if( $bsLib.dragdropChange == false ) $bsLib.dragdropChange = true;
			}
			
			function handleDragDropEnd(e, dragdrop){
				dragItem.find(".bshelf-box-thumb-img img").removeClass("drag-and-drop-ready").css("webkit-box-reflect", "");
				dragItem.find(".thumb-box-title").css("visibility", "");
				
				//event.gesture.touches
				if( $bsLib.dragdropChange ){
					$('.bookshelf-view-box-type .book-item-link').each(function(i, elem){
						var item = $(elem),
							tmpAppid = elem.id;
						
						item.attr("sortno", $bsLib.itemList[i]);
						PARAMLIBRARY.bshelf_data[tmpAppid].sortno = parseInt( $bsLib.itemList[i] );
					});
					
					if( appFlag == true ) h5applib.sortNoUpdate();
					else h5applib.setBShelfLocalStorageData();
					
					
					$bsLib.dragdropChange = false;
				}					
				
				handleReady.off('ready');
				handleChange.off('change');
				handleEnd.off('drop');
				handleResize.off('dragResize');
			}
			
			function handleResize(e, elem){
				var dragElme = $(elem);
				dragElme.find(".bshelf-box-thumb-img img").removeClass("drag-and-drop-ready").css("webkit-box-reflect", "");
				dragElme.find(".thumb-box-title").css("visibility", "");
				
				handleReady.off('ready');
				handleChange.off('change');
				handleEnd.off('drop');
				handleResize.off('dragResize');
			}
			
			
			handleReady = dragItem.on('ready', handleDragDropReady);
			handleChange = dragItem.on('change', handleDragDropChange)
			handleEnd = dragItem.on('drop', handleDragDropEnd);
			handleResize = dragItem.on('dragResize', handleResize);
			
			draganddropsortable.dragDropSort( e, dragItem );
		},
		
		bshelfEvent : function(){
			$(document).on(lib_defind.LIBRARY_RESIZE, function(){
				console.log("bshelfEvent", lib_defind.LIBRARY_RESIZE);
				$bsLib.refresh();
			});

			$(document).on(lib_defind.LIBRARY_TRANSITIONS, function(){
				console.log("bshelfEvent", lib_defind.LIBRARY_TRANSITIONS);
				$bsLib.refresh();
			});

			$(document).on(lib_defind.LIBRARY_USERINFOCHANGE, function(){
				console.log("bshelfEvent", lib_defind.LIBRARY_USERINFOCHANGE);
				
				h5applib.getBookshelfCateData();

				PARAMLIBRARY.new_bs_cate_seq = 0;
				PARAMLIBRARY.new_bs_cate_title = "";

				if( $bsLib.checkExpireTimer != null ) {
                    clearTimeout($bsLib.checkExpireTimer);
                    $bsLib.checkExpireTimer = null;
                }

                $bsLib.isResume = false;
                $bsLib.expirationServerCheckFlag = false;
				$bsLib.refresh();
			});
			

			//box type sort
			$(document).on(utils.START_EV, '.bookshelf-view-box-type .book-item-link', function(e){
				if( $bsLib.holdWaitStart ) return false;
				var touchduration = ( !androidDeviceCheck ) ? 100 : 200,
					checkMoveStart = false,
					dragItem = $(this);
				
				var itemMove, itemEnd;
				
				function timer(interval){
					interval--;
					if(  interval < touchduration / 2 ) checkMoveStart = true;
					
			        if (interval >= 0) {
						$bsLib.holdInterval = setTimeout(function() {
							timer(interval);
						});
			        } else {
						taphold();
			        }
				}
				
				function taphold(){
					console.log("hold");					
					e.preventDefault();
					itemMove.off(utils.MOVE_EV);
					itemEnd.off(utils.END_EV);
					
					$bsLib.draganddropsortStart(e, dragItem);
					$bsLib.holdWaitStart = false;
				}
				
				function touchstart() {
					$bsLib.holdWaitStart = true;
					timer(touchduration);
				}
				
				function touchmove(){
					
					if( checkMoveStart && $bsLib.holdInterval != null && !androidDeviceCheck ){
						clearTimeout($bsLib.holdInterval);
						$bsLib.holdInterval = null;
						$bsLib.holdWaitStart = false;
						
						itemMove.off(utils.MOVE_EV);
						itemEnd.off(utils.END_EV);
					}
				}
				
				function touchEnd(){
					$bsLib.holdWaitStart = false;
					if( $bsLib.holdInterval != null ) {
						clearTimeout($bsLib.holdInterval);
						$bsLib.holdInterval = null;
					}
				}
				
				itemMove = dragItem.on( utils.MOVE_EV, touchmove );
				itemEnd = dragItem.on( utils.END_EV, touchEnd );
				touchstart();
			});
				
			$(document).hammer({tap_max_touchtime:200}).on('tap', '.goto-viewer, .btn-download-cancel, .bshelf-delete-bg-click, .book-update, .all-update, .bshelf-box-update-bg', function(){
				var clicked = $(this); 
				
				var editBookid =  clicked.attr('appid');
				
				if( clicked.hasClass('goto-viewer') ){
					console.time('goto-viewer');
					if( $bsLib.bookshelfEditMode == true ) return false;
					
					//downloadが streamの場合network check
					if( PARAMLIBRARY.bshelf_data[editBookid].objcontents.sel_disttype == 'stream' && h5applib.getConnectStatus() != 'ok' ){
						h5applib.nalert(PARAMDATA.lang.message.networkcheck, PARAMDATA.lang.oneword.ERROR);
						
						return false;
					}
					
					h5applib.createView(editBookid);
					
					return false;
				}else if( clicked.hasClass('btn-download-cancel') ){
					$bsLib.progressPasue = true;
					h5applib.showConfirm(PARAMDATA.lang.message.cancel_confirm, 'CANCEL',
						function(data){
							//ok
							libStore.isProcessing = true;
							PARAMLIBRARY.bshelf_data[editBookid].eventType = 'cancelBookdownload';
							
							if( PARAMLIBRARY.bshelf_data[editBookid].selected == 'update' && PARAMLIBRARY.bshelf_data[editBookid].procWaitBusy == 30 ){
								libUpdate.updateCancelDestroy( editBookid );
							}							
							
							h5applib.cancelBookDownload(editBookid, function(){
								$bsLib.progressPasue = false;
								$bsLib.refresh();
							});
						},
						function(){
							//no
							$bsLib.progressPasue = false;
							$bsLib.refresh();
						}
					);
					
					return false;
				}else if( clicked.hasClass('all-update') ){
					var updateOnElem = $('.bookshelf-update-on');
					
					//all update start
					if( updateOnElem.length >1 ){
						h5applib.showConfirm(PARAMDATA.lang.message.update_confirm, PARAMDATA.lang.oneword.update_tablet, function(){
							updateOnElem.each(function(){
								var tmpAppid = $(this).attr('appid');
																
								if( tmpAppid == undefined ) return true;

								if( tmpAppid == undefined || tmpAppid == null || !tmpAppid ) return false;
								
								$bsLib.setUpdateBshelfData(tmpAppid);
							});
							libUpdate.setUpdateQueueThread();
						});
					}
								
					return false;
				}else if( clicked.hasClass('book-update') || clicked.hasClass('bshelf-box-update-bg') ){
					var bshelfObj = PARAMLIBRARY.bshelf_data[editBookid];
					h5applib.showConfirm(PARAMDATA.lang.message.update_confirm, bshelfObj.objcontents.title,
						function(){
							//box update bg

							// 本棚で本をアップデートする際、ネット状態を確認
							if (h5applib.getConnectStatus() == 'ok'){
								$bsLib.setUpdateBshelfData(editBookid);
								libUpdate.setUpdateQueueThread();
							}else{
								$bsLib.refresh();
							}
						}
					);
										
					return false;
				}else if( clicked.hasClass('bshelf-delete-bg-click')  ){
					if( clicked.hasClass('expiration-on') ) {
						//期間過ぎたフックをclickしたら削除メセージが出る
						var tmpAppid = $(this).attr('appid');
						
						libStore.modalButtonOk = PARAMDATA.lang.changeText.bookshelfDeleteTitle;
						h5applib.nalert(PARAMDATA.lang.message.bookshelfSelectDelete, PARAMLIBRARY.bshelf_data[tmpAppid].objcontents.title, function(){ 
							libStore.modalButtonOk = 'OK';
							if(appFlag == true) $bsLib.deleteOneData( tmpAppid );
							else $bsLib.deleteDataPush();							
						});
					}else{
						if($bsLib.bookshelfType == 'box'){					
							if( clicked.hasClass('delete-check-on')  ) clicked.addClass('delete-check-off').removeClass('delete-check-on');
							else if( clicked.hasClass('delete-check-off') ) clicked.addClass('delete-check-on').removeClass('delete-check-off');
						}else{
							
							var tmpbookShelfId = $('#'+editBookid),
								deleteListBgElme = tmpbookShelfId.find('.bshelf-list-delete-bg');
														
							if( deleteListBgElme.hasClass('delete-check-on') ) {
								deleteListBgElme.addClass('delete-check-off').removeClass('delete-check-on').attr('appid', '');
							}else {
								deleteListBgElme.addClass('delete-check-on').removeClass('delete-check-off').attr('appid', editBookid);
							}
						}
						
						$bsLib.checkButtonDisable();
												
						$bsLib.selectDataArrayToValue();
					}
					
					return false;
				}
			});
			
			$('.bookshelf-type-change').hammer({tap_max_touchtime:200}).on('tap', function(){
				//mode
				$bsLib.modeChangeInit();
				
				if($bsLib.bookshelfType == 'box') {
					$(this).removeClass('icon-bookshelf-list-type-blue').addClass('icon-bookshelf-box-type-blue');
					$bsLib.bookshelfType = 'list';
				}else if($bsLib.bookshelfType == 'list'){
					$(this).removeClass('icon-bookshelf-box-type-blue').addClass('icon-bookshelf-list-type-blue');
					$bsLib.bookshelfType = 'box';
				}
				
				$bsLib.refresh();
			});
			
			
			$('.bookshelf-mode-change').hammer({tap_max_touchtime:200}).on('tap', function(){
				//init disable
				$bsLib.modeChangeInit();
				
				if($bsLib.bookshelfEditMode == false){
					$bsLib.changeModeBookshelf('on');
					$bsLib.bookshelfEditMode = true;
				}else{
					$bsLib.changeModeBookshelf('off');
					$bsLib.bookshelfEditMode = false;
				}
							
			});
			
			//sub navi delete
			$('.bookshelf-delete-btn').hammer({tap_max_touchtime:200}).on('tap', function(){			
				var deleteCheckOnElem = $('.delete-check-on');
				if( deleteCheckOnElem.length <= 0 ) return false;
				var tempSelectedBook = $bsLib.bookshelfSelectedBook;
				$bsLib.bookshelfSelectedBook = [];
				var deleteMsg = PARAMDATA.lang.message.bookshelfDelete.replace('num', deleteCheckOnElem.length);
				h5applib.showConfirm(deleteMsg, PARAMDATA.lang.changeText.bookshelfDeleteTitle, $bsLib.deleteDataPush, function(){
					$bsLib.bookshelfSelectedBook = tempSelectedBook;
				});
			});
		},
		
		checkButtonDisable : function(){
			//delete, move button color disbale enable check
			var deleteCheckOnElem = $('.delete-check-on');
			if( deleteCheckOnElem.length <= 0 ) $('.bookshelf-delete-btn, .bookshelf-category-move-btn').addClass("disable");
			else $('.bookshelf-delete-btn, .bookshelf-category-move-btn').removeClass("disable");
		},
		
		modeChangeInit : function(){
			this.bookshelfSelectedBook = [];
			$('.bookshelf-delete-btn, .bookshelf-category-move-btn').addClass("disable");
		},
		
		setUpdateBshelfData : function( appid ){
			var obj = libUpdate.getUpdateListData(appid);
			var checkProcessQueue = libUpdate.checkUpdateQueueData(obj.appBookid);
			if(checkProcessQueue) libUpdate.updateQueueData.push(obj);
		},
		
		selectDataArrayToValue : function(){
			var dataArray = [];
			$('.delete-check-on').each(function(key, elem){
				var tmpAppBookid = elem.getAttribute('appid');
				dataArray.push(tmpAppBookid);
			});
			this.bookshelfSelectedBook = dataArray;
		},
		
		deleteOneData : function(appid){
			PARAMLIBRARY.bshelf_data[appid].procQueuStatus = 'W';
			PARAMLIBRARY.bshelf_data[appid].procWaitBusy = 80;
			console.log("---resume download queue add--", PARAMLIBRARY.bshelf_data[appid]);
			PARAMDATA.downloadQueue.push(PARAMLIBRARY.bshelf_data[appid]);
			
			libStore.queuProcessing();
			//$bsLib.refresh();
		},
		
		deleteDataPush : function(){
			$('.delete-check-on').each(function(key, value){
				var tmpAppBookId = $(this).attr('appid');
				PARAMLIBRARY.bshelf_data[tmpAppBookId].procQueuStatus = 'W';
				PARAMLIBRARY.bshelf_data[tmpAppBookId].procWaitBusy = 80;
				console.log("---resume download queue add--", PARAMLIBRARY.bshelf_data[tmpAppBookId]);
				PARAMDATA.downloadQueue.push(PARAMLIBRARY.bshelf_data[tmpAppBookId]);
			});

			$webApiRouter.setDeleteStatus("1");
			libStore.queuProcessing();
			//$bsLib.refresh();
 		},
		changeModeBookshelf : function(satus){
			switch(satus){
				case 'on' :
					$('.bookshelf-mode-change').find('span').text(PARAMDATA.lang.changeText.bookshelfDeleteDone);
					$('.bookshelf-sub-navbar-category').addClass('hide');
					$('.bookshelf-sub-navbar-edit').removeClass('hide');
					
					
					if($bsLib.bookshelfType == 'box'){
						$('.bshelf-box-delete-bg:not(.expiration-on)').css('display', 'block');
					}else{
						$('.bshelf-list-delete-bg:not(.expiration-on)').addClass('bshelf-delete-on-left');
						$('.bshelf-list-delete-full-bg:not(.expiration-on)').css('display', 'block');
					}
					
					break;
					
				case 'off' :
					$('.bookshelf-mode-change').find('span').text(PARAMDATA.lang.changeText.bookshelfDeleteEidt);
					$('.bookshelf-sub-navbar-category').removeClass('hide');
					$('.bookshelf-sub-navbar-edit').addClass('hide');
					
					if($bsLib.bookshelfType == 'box'){
						$('.bshelf-box-delete-bg:not(.expiration-on)').removeClass('delete-check-on').addClass('delete-check-off').css('display', 'none');
					}else{
						$('.bshelf-list-delete-bg:not(.expiration-on)').removeClass('delete-check-on bshelf-delete-on-left').addClass('delete-check-off');
						$('.bshelf-list-delete-full-bg:not(.expiration-on)').css('display', 'none');
					}
					break;
			}
		},
		
		createBoxBg : function(cnt){
			var tmpElem = '';
			
			if($bsLib.bookshelfType == 'box'){
			
				for(var i=0; i<cnt; i++){
					tmpElem += '<div class="bookshelf-box-bg">'
							+	'<div class="bookshelf-box-item"></div>'
							+'</div>';
				}
				
			}else if( $bsLib.bookshelfType == 'list' ){
				
				tmpElem = '<ul class="bookshelf-list-bg"></ul>';
				
			}
			
			return tmpElem;
		},
		
		//step1 box create
		createBookShelfBox : function(){
			if(this.totalbshelfData <= 0) return false;
			
			for(var appkey in this.bookShelfStorageData){
				var obj = this.bookShelfStorageData[appkey];
				
				if( obj.procQueuStatus == 'W' && obj.procWaitBusy >= 80 && obj.procWaitBusy <= 89) continue;
				
				if(obj.selected == "open") continue;

				//cloud userid check
				if( cloudFlag && PARAMDATA.portalFlag == false ){
					if( obj.objcontents.clouduser != PARAMDATA.memInfo.userid ) continue;
				}
				
				var tmpElem = '',
					thumbImgSrc = obj.thumbPath;
				
				if( obj.status == 100 ){
					if( appFlag == true ) thumbImgSrc = h5applib.appDocPath +'/' + thumbImgSrc;
					if( PARAMLIBRARY.new_bs_cate_seq != 0 && obj.cate_seq != PARAMLIBRARY.new_bs_cate_seq ) continue;
				}
				
				_tempElement.innerHTML = '';
				_tempElement.innerHTML = this.bshelfBoxItemBaseElement.innerHTML;
				
				var findBoxElem = libStore.findElement('.book-item-link', _tempElement);
				
				findBoxElem.attr( {'id' : obj.app_book_id, 'draggable' : true, "sortno" : obj.sortno} );
				findBoxElem.find('.bshelf-box-delete-bg, .bshelf-box-update-bg').attr('appid', obj.app_book_id);
				
				//thumbnail
				//var ratiosizes = imageFitCommonRetWidthHeight(this.thumb_box_img_w, this.thumb_box_img_h, obj.thumb_w, obj.thumb_h);
				//findBoxElem.find('.bshelf-box-thumb-img img').attr({'src': thumbImgSrc, 'appid': obj.app_book_id}).css({width:ratiosizes.width, height:ratiosizes.height});
				
				//ict edit
        if(thumbImgSrc.indexOf('http://')==0){
          thumbImgSrc = thumbImgSrc.replace('http://','https://');
        }
				
				
				
				//findBoxElem.find('.bshelf-box-thumb-img img').attr({'src': thumbImgSrc, 'appid': obj.app_book_id});
				//ict edit 2019-03-28
				findBoxElem.find('.bshelf-box-thumb-img img').attr({'src': thumbImgSrc, 'appid': obj.app_book_id}).css({width:"100%",height:"100%"});

				//status 
				if( obj.status == 100 ) {
					findBoxElem.find('.bshelf-box-thumb-img img').addClass('goto-viewer');
					findBoxElem.find('.box-progress-bg').remove();
					
					var checkProcessQueue = libUpdate.checkUpdateQueueData(obj.app_book_id);
					if( !checkProcessQueue ) findBoxElem.find('.update_waint_bg').css('display', 'block');
					//processing check
				}else{
					findBoxElem.find('.bshelf-box-thumb-img img').removeClass('goto-viewer')
				}
				
				//expiration check
				if( $.inArray( obj.app_book_id, this.expirationBooks ) != -1 ) {
					findBoxElem.find('.bshelf-box-delete-bg').css('display', 'block').addClass('delete-check-on expiration-on').removeClass('delete-check-off');
				}
				
				//title
				if( isMobilePhone && !device7inch ) findBoxElem.find('.thumb-box-title').remove();
				else findBoxElem.find('.thumb-box-title span').text(obj.objcontents.title);
				
				$(".bookshelf-view-box-type").append(findBoxElem);
			}
			
			this.bookShelfUpdateBook();
		},
		
		//step1 list create AND item
		createBookShelfList : function(){
			var tmpElem = '',
				box_bg_ck = 0,
				box_bg = '',
				dataCnt	= 0;
		
			
			for(var appkey in $bsLib.bookShelfStorageData){
				var dataObj = $bsLib.bookShelfStorageData[appkey];
				
				if(dataObj.selected == "open") continue;

				dataCnt++;
				var thumbImgSrc = dataObj.thumbPath;
				var catchcopy = ( typeof(dataObj.objcontents.catchcopy) == 'string' ) ? dataObj.objcontents.catchcopy : '';
				var bookPages = ( typeof(dataObj.objcontents.pages) == 'string' ) ? dataObj.objcontents.pages : dataObj.objcontents.pages[0];
				var priceText = ( typeof(dataObj.objcontents.pricetext) == 'string' ) ? dataObj.objcontents.pricetext : '';
				
				if( dataObj.procQueuStatus == 'W' && dataObj.procWaitBusy >= 80 && dataObj.procWaitBusy <= 89){
					continue;
				}
				
				//cloud userid check
				if( cloudFlag && PARAMDATA.portalFlag == false ){
					if( dataObj.objcontents.clouduser != PARAMDATA.memInfo.userid ) continue;
				}
				
				if( dataObj.status == 100 ){
					if( appFlag == true ) thumbImgSrc = h5applib.appDocPath +'/' + thumbImgSrc;
					
					if( PARAMLIBRARY.new_bs_cate_seq != 0 && dataObj.cate_seq != PARAMLIBRARY.new_bs_cate_seq ){
						continue;
					}
				}
				
				if( dataObj.status > 50 && dataObj.status < 90 ) proceesingDisplay = 'block';
				
				var ratiosizes = imageFitCommonRetWidthHeight(libStore.thumb_img_w, libStore.thumb_img_h, dataObj.thumb_w, dataObj.thumb_h);
				
				if(box_bg_ck == 0){
					box_bg = '#fff';
					box_bg_ck = 1;	
				}else{
					box_bg = '#f2f2f2';
					box_bg_ck = 0;
				}
				
				
				_tempElement.innerHTML = '';
				_tempElement.innerHTML = $bsLib.bshelfListItemBaseElement.innerHTML;
				
				var findBoxElem = libStore.findElement('.list-items-detail', _tempElement);
				
				findBoxElem.attr('id', dataObj.app_book_id).css('background', box_bg);
				
				/*
if( cloudFlag == false ) $(findBoxElem).find('.list-thumb-wrap img').attr('src', thumbImgSrc).css({width:ratiosizes.width, height:ratiosizes.height});
				else $(findBoxElem).find('.list-thumb-wrap img').attr('src', thumbImgSrc).css({width:ratiosizes.width, height:ratiosizes.height});
*/
				findBoxElem.find('.list-thumb-wrap img').attr('src', thumbImgSrc).css({width:ratiosizes.width, height:ratiosizes.height});
				
				
				findBoxElem.find('.thumb-list-title span').text(dataObj.objcontents.title);
				
				
				if( dataObj.status == 100 ){
					
					findBoxElem.find('.list-data-processing-loading').css('display', 'none');
					
					//list-publish-lable
					findBoxElem.find('.no-complete').remove();
					findBoxElem.find('.box-progress-bg').remove();
					findBoxElem.find('.list-status-bg').remove();
					findBoxElem.find('.btn-download-cancel').remove();
					
					var $save_date_label = findBoxElem.find('.list-category-lable'),
						$save_date_text = findBoxElem.find('.list-category-text'),
						$save_page_label = findBoxElem.find('.list-page-lable'),
						$save_page_text = findBoxElem.find('.list-page-text'),
						$save_size_label = findBoxElem.find('.list-publish-lable'),
						$save_size_text = findBoxElem.find('.list-publish-text'),
						$save_downType_lable = findBoxElem.find('.list-price-lable'),
						$save_downType_txet = findBoxElem.find('.list-price-text');
										
					findBoxElem.find('.book-info-reade').addClass('goto-viewer').attr('appid', dataObj.app_book_id);
											
					var dateTitleString = PARAMDATA.lang.oneword.dldate;
					if( appFlag == false ) dateTitleString = PARAMDATA.lang.oneword.opendate;
					
					$save_date_label.text(dateTitleString);
					var date_str = libStore.getDateString(dataObj.down_date);
					$save_date_text .text(date_str);
					
					$save_page_label.text(PARAMDATA.lang.oneword.pagenum); 
					$save_page_text.text(bookPages);
					
					$save_size_label.text(PARAMDATA.lang.oneword.size); 
					$save_size_text.text(dataObj.objcontents.filesize);
					
					var bookshelf_down_type  = PARAMDATA.lang.oneword.disttype_download;
					if( dataObj.objcontents.sel_disttype == 'stream' || dataObj.selected == 'mobileviewer' ) bookshelf_down_type = PARAMDATA.lang.oneword.disttype_stream;
					$save_downType_lable.text(PARAMDATA.lang.oneword.dltype); 
					$save_downType_txet.text(bookshelf_down_type);
					
					var checkProcessQueue = libUpdate.checkUpdateQueueData(dataObj.app_book_id);
								
					if( !checkProcessQueue ) {
						findBoxElem.find('.update_waint_bg').css('display', 'block');
						findBoxElem.find('.book-info-reade').css('display', 'none');
					}
					
					//expiration check
					if( $.inArray( dataObj.app_book_id, this.expirationBooks ) != -1 ) {
						findBoxElem.find('.bshelf-list-delete-bg').attr('appid', dataObj.app_book_id).addClass('bshelf-delete-on-left expiration-on delete-check-on').removeClass('delete-check-off');
						findBoxElem.find('.bshelf-list-delete-full-bg').addClass('expiration-on');
						findBoxElem.find('.book-info-reade').remove();
					}
					
					//phone olny
					if( isMobilePhone ){
						if(PARAMDATA.orient == 'portrait'){
							var tmpCol = 'col-40';
							if( device7inch ) tmpCol = 'col-25'; 
						
							$save_date_label.css('display', 'none');
							$save_date_text.css('display', 'none');
							$save_downType_lable.css('display', 'none');
							$save_downType_txet.css('display', 'none');
							
							
							findBoxElem.find('.list-category-lable, .list-page-lable, .list-publish-lable, .list-price-lable')
								.addClass(tmpCol).removeClass('col-15 col-20');
							findBoxElem.find('.list-category-text, .list-page-text, .list-publish-text, .list-price-text')
								.addClass('col-60').removeClass('col-33');								
						}else{
							
							var tmpCol = 'col-20';
							if( device7inch ) tmpCol = 'col-15'; 
							
							$save_date_label.css('display', 'block');
							$save_date_text.css('display', 'block');
							$save_downType_lable.css('display', 'block');
							$save_downType_txet.css('display', 'block');

							findBoxElem.find('.list-category-lable, .list-page-lable, .list-publish-lable, .list-price-lable')
								.addClass(tmpCol).removeClass('col-40 col-25');
							
							findBoxElem.find('.list-category-text, .list-page-text, .list-publish-text, .list-price-text')
								.addClass('col-33').removeClass('col-60');
						}
					}
					
					findBoxElem.find('.bshelf-list-delete-full-bg').attr('appid', dataObj.app_book_id);
				}else{
					if( dataObj.status > 50 || dataObj.status > 80 ) {
						findBoxElem.find('.list-data-processing-loading').css('display', 'block');	
					}
					findBoxElem.find('.ok-complete').remove();
					findBoxElem.find('.list-detail-info-catchcopy').remove();
					findBoxElem.find('.list-status-bg').css('display', 'none');
					findBoxElem.find('.book-info-reade').remove();
					
					findBoxElem.find('.btn-download-cancel').attr('appid', dataObj.app_book_id);
				}
				
				tmpElem += findBoxElem[0].outerHTML;
			}
			
			
			$('.bookshelf-list-bg').html(tmpElem);
			
			
			if( dataCnt < ($bsLib.bookItemCount +1) ){
				tmpElem = '';
				for(var i=($bsLib.bookItemCount +1); i>0; i--){
					tmpElem += '<li class="list-items-detail"><div class="list-item-contents"></div></li>'
				}
				$('.bookshelf-list-bg').append(tmpElem);
			}
			
			this.bookShelfUpdateBook();
		},
		
		bookShelfUpdateBook : function(){
			console.log("bookshelf update",libUpdate.updateGetListData.length);
			if( libUpdate.updateGetListData.length > 0 ){
				for( var up in libUpdate.updateGetListData ){
					var updateObj = libUpdate.updateGetListData[up],
					bookShelfElem = $('#'+updateObj.appBookid);
					bookShelfElem.find('.top-update-status').css('display', 'block');
					if(this.bookshelfType == 'box'){
						
						bookShelfElem.find('.bshelf-box-update-bg').css('display', 'block').addClass('bookshelf-update-on');
						bookShelfElem.find('.bshelf-box-thumb-img img').removeClass('goto-viewer');
					}else{
						bookShelfElem.find('.list-detail-info-label').remove();
						bookShelfElem.find('.list-detail-info-description').css('display', '-webkit-box').html(updateObj.description);
					
						bookShelfElem.find('.book-info-reade').remove();
						bookShelfElem.find('.book-update').attr('appid', updateObj.appBookid).addClass('bookshelf-update-on').css('display', 'block');
					}
				}
			}
		},
		
		bookshelfViewAllStatusView : function(){
			for(var appkey in $bsLib.bookShelfStorageData){
			
				if($bsLib.bookShelfStorageData[appkey].status == 100) continue;
				
				//status : 2 -> prog, 3 -> preload view, 50->cancel, 80->delete, 100->完了, -100->error
				$bsLib.bookDivisionStausView($bsLib.bookShelfStorageData[appkey]);
			}
		},
		
		bookDivisionStausView : function(diviData){
			if( $bsLib.progressPasue == true ) return false;
			
			var $bookShelfId = $('#'+diviData.app_book_id);
			
			$bookShelfId.find('.box-progress-current').css('width', diviData.progress);
			
			switch (diviData.status){
				case 2 :
				
				if( !$('.btn_mybook').hasClass('downloaded_mybook') ) {
					$('.btn_mybook').addClass('downloaded_mybook').html('<span class="badge badge-red">1</span>');
				}
				
				
				//$bookShelfId.find('.list-status-text').text( PARAM.lang.oneword.book_progress+' : '+diviData.nowvalum+'/'+ diviData.totalvalum); //list type
				
				break;
				case 3 :
			
					$bookShelfId.find('.box-progress-buffer').css('display', 'block');
					
					$bookShelfId.find('.preload_loading_bg').css('display', 'block'); //box type
					
					$bookShelfId.find('.list-status-bg').css('display', 'block'); //list type
					$bookShelfId.find('.btn-download-cancel').remove();
					$bookShelfId.find('.list-status-text').text(PARAMDATA.lang.oneword.book_unzip);
					
					break;
			
				//download cancel
				case 50:
				case 55:
				case 59:
					if(diviData.status == 50){
						if($bsLib.bookshelfType == 'box'){
							//box type
							$bookShelfId.find('.preload_loading_bg').css('display', 'block');
						}else{
							//list type
							$bookShelfId.find('.list-data-processing-loading').css('display', 'block');
							$bookShelfId.find('#list-prgress-bg').remove();
							$bookShelfId.find('.list-status-text').text(PARAMDATA.lang.oneword.book_cancel);
							$bookShelfId.find('.list-status-bg').css('display', 'block');
							$bookShelfId.find('.list-status-text').text(PARAMDATA.lang.oneword.book_cancel);
						}
					}else if(diviData.status == 59){
						delete PARAMLIBRARY.bshelf_data[diviData.app_book_id];
						
						if( appFlag == false ) h5applib.setBShelfLocalStorageData();
						
						if( $('.btn_mybook').hasClass('downloaded_mybook') ) {
							$('.btn_mybook').removeClass('downloaded_mybook').html('');
						}
						
						$bsLib.refresh();
					}
					break;
				
				//delete status
				case 80:
				case 85:
				case 89:
					if(diviData.status == 80){
						if($bsLib.bookshelfType == 'box'){
							$bookShelfId.find('.preload_loading_bg').css('display', 'block');
							//$bookShelfId.find('.bshelf-box-delete').removeClass('bshelf-box-delete');
						}else{
							$bookShelfId.find('.list-data-processing-loading').css('display', 'block');
						}
					}else if(diviData.status == 89){
						delete PARAMLIBRARY.bshelf_data[diviData.app_book_id];	
						if( appFlag == false ) h5applib.setBShelfLocalStorageData();
						
						if( $('.btn_mybook').hasClass('downloaded_mybook') ) {
							$('.btn_mybook').removeClass('downloaded_mybook').html('');
						}
					}
					
					break;
				
				case 100 :
					
					if( $('.btn_mybook').hasClass('downloaded_mybook') ) {
						$('.btn_mybook').removeClass('downloaded_mybook').html('');
					}
                	
					PARAMLIBRARY.bshelf_data[diviData.app_book_id].procWaitBusy = 0;
					if( appFlag ) h5applib.setProcWaitBusy( PARAMLIBRARY.bshelf_data[diviData.app_book_id] );
					
					$bsLib.refresh();				
					break;
				
				default:
					
					
					break;
			}
		},
		
		checkBookShelfDownloadResume : function(){
			if( this.isResume ) return ;
			this.isResume = true;
			console.log("checkBookShelfDownloadResume");
			for (var appkey in PARAMLIBRARY.bshelf_data) {
				var bshelfObj = PARAMLIBRARY.bshelf_data[appkey];

				if(bshelfObj.selected == "open") continue;

				if( bshelfObj.status == 100) {
					if( bshelfObj.procQueuStatus == 'W' ) libStore.queuProcessing();
					continue;
				}

				switch(bshelfObj.status){
					case 80:
						if( libStore.isProcessing == true ) return;
						
						libStore.isProcessing = true;
                        
                        if(typeof PARAMLIBRARY.bshelf_data[appkey].eventType == 'undefined' || PARAMLIBRARY.bshelf_data[appkey].eventType == null) {
                            PARAMLIBRARY.bshelf_data[appkey].eventType = 'bookDeleteStatus';
                        }

						h5applib.deleteBookData(bshelfObj.app_book_id);
						
						break;
						
					default:
						bshelfObj.procQueuStatus = "W";
						console.log("---resume download queue add--", bshelfObj);
						PARAMDATA.downloadQueue.push(bshelfObj);

						// if( !libStore.isProcessing ){
						// 	bshelfObj.eventType = "bookDownloadingStatus";
						// 	libStore.isProcessing = true;
						// 	//h5applib.serverToApplicationZipDownlaod( bshelfObj );
						// }else{
						// 	console.log("---resume download queue add--", bshelfObj);
						// 	PARAMDATA.downloadQueue.push(bshelfObj);
						// 	console.log(PARAMDATA.downloadQueue);
						// }
						//console.log("tttttttttttttttttttttttttt", PARAMDATA.downloadQueue.length);
						// if( libStore.isProcessing == true ) {
						// 	console.log("---queue add--", bshelfObj);
						// 	PARAMDATA.downloadQueue.push(bshelfObj);
						// 	console.log(PARAMDATA.downloadQueue);
						// 	return;
						// }
						
						// bshelfObj.eventType = "bookDownloadingStatus";
						// libStore.isProcessing = true;
						
						break;
				}
			}
			libStore.queuProcessing();
		},
		
		expirationCheck : function(){
			// if( this.expirationServerCheckFlag ) return false;
			console.log("expirationCheck");
			this.expirationServerCheckFlag = true;
			
			this.checkExpireTimer = setTimeout(function(){
										$bsLib.checkExpireTimer = null;
										$bsLib.expirationServerCheckFlag = false;
									}, this.delayTime);
					
			this.getServerOneExpiration();
		},

		//期間が過ぎたら
		getServerOneExpiration : function(){
			console.log("h5applib.getConnectStatus() != 'ok' || !PARAMLIBRARY.responseCheck",h5applib.getConnectStatus(), PARAMLIBRARY.responseCheck);
			if(h5applib.getConnectStatus() != 'ok' || !PARAMLIBRARY.responseCheck) {
				$bsLib.expirationBooks = [];
				return false;
			}
			console.log("Object.keys(PARAMLIBRARY.bshelf_data)",Object.keys(PARAMLIBRARY.bshelf_data).length);
			
			if( Object.keys(PARAMLIBRARY.bshelf_data).length <= 0 ) return false;
			var data1 = new Array(); //author
			var data2 = new Array(); //bookid
			var data3 = new Array(); //date  

			//for(var appkey in PARAMLIBRARY.visible_data){
			for(var appkey in PARAMLIBRARY.bshelf_data){
                var bshelfObj = PARAMLIBRARY.bshelf_data[appkey];
 
                if(bshelfObj.status != 100 || bshelfObj.selected == "open") continue;

				if( cloudFlag && PARAMDATA.portalFlag == false ){
					//cloud user id check
				}

				//if( PARAMDATA.portalFlag == false ){

					//var nowCloudUser =  atob( PARAMLIBRARY.loginAutoInfo.user_id );
					//if( bshelfObj.objcontents.clouduser != nowCloudUser ) continue;
				//}
				
				data1.push( bshelfObj.objcontents.author );
				data2.push( bshelfObj.objcontents.bookid );
				data3.push( bshelfObj.down_date )
			}
			//http://dev.wisebook4.jp/bookstorexp/json_expirationdate/phonegap/?os_tp=H			
			var expirationUrl = PARAMDATA.manifest.expirationdate+bshelfObj.objcontents.author+'/?os_tp='+PARAMDATA.ostp;
			console.log("expiration url", expirationUrl);
			$.ajax({
				url 	: expirationUrl,
				data	: {"data1[]": data1, "data2[]" : data2, "data3[]": data3},
				type	: 'post',
				dataType: 'json',
				cache	: false,
				success	: function(jsondata){
					$bsLib.expirationBooks = [];
					
					for( var e in jsondata ){
						if( jsondata[e].expiration_date != "" ) {
							var bshelfObj = libStore.returnAppObject( jsondata[e].bookid );
							$bsLib.expirationBooks.push( bshelfObj.app_book_id );
						}
					}
				},
				error: function(){
					console.log('bookshlef XHR expiration error');
					$bsLib.expirationBooks = [];
				}
			});
		},		
			
		createUpdateCountView : function( updateFlag ){
			// var allUpdateBtn = $('.all-update'),
			// 	updateOnElem = $('.bookshelf-update-on'),
			//  	btnMybookElem = $('.btn_mybook');
			 
			//  if( libUpdate.updateBookCount <= 0 ){
			// 	allUpdateBtn.css('display', 'none');
			// 	btnMybookElem.removeClass('downloaded_mybook').html('');
			// 	return false;
			//  }
			 
			 
			// if( PARAMLIBRARY.new_bs_cate_title != "" ) {
			// 	//categoryの状態
			// 	if( updateOnElem.length <= 1 ) allUpdateBtn.css('display', 'none');
			// 	else if( libUpdate.updateBookCount > 1 ) allUpdateBtn.css('display', 'block');
			// }else{
			// 	//全ての状態
			// 	if( !btnMybookElem.hasClass('downloaded_mybook') ) btnMybookElem.addClass('downloaded_mybook');
				
			// 	if( libUpdate.updateBookCount > 1 ) allUpdateBtn.css('display', 'block');
			// 	else allUpdateBtn.css('display', 'none');
			// }
			//btnMybookElem.html('<span class="badge badge-red">'+libUpdate.updateBookCount+'</span>');

			// if( updateFlag ) this.refresh();
		},
		
		totalCount : function(){
			var totalCountData = 0;
			if( cloudFlag && PARAMDATA.portalFlag == false ){
				//cloud
				var nowCloudUser = PARAMDATA.memInfo.userid;
				for( var appkey in this.bookShelfStorageData ){
					var obj = this.bookShelfStorageData[appkey];
					if( obj.objcontents.clouduser == nowCloudUser && obj.selected != "open" ) totalCountData++;
				}
				return totalCountData;
			}else {
				for( var appkey in this.bookShelfStorageData ){
					var obj = this.bookShelfStorageData[appkey];
					if( obj.selected != "open" ) totalCountData++;
				}
			}

			return totalCountData;
		},
 
		refresh : function( skip ){
 
			console.log("bookshelf refresh");
			console.trace();
			var baseSubTitleString = "";

			this.expirationCheck();
			libUpdate.getUpdateCheckList();
			this.bshelfViewParentsPageElem.css("background", "");
			
			//this.bookShelfStorageData = PARAMLIBRARY.visible_data;
			this.bookShelfStorageData = PARAMLIBRARY.bshelf_data;
 
			this.totalbshelfData = this.totalCount();
			
			if (isMobilePhone == true) {
				if(PARAMDATA.orient == 'portrait') $bsLib.bookItemCount = 3;
				else $bsLib.bookItemCount = 4;
			} else {
				if(PARAMDATA.orient == 'portrait') $bsLib.bookItemCount = 4;
				else $bsLib.bookItemCount = 5;
			}
			
			if( cloudFlag == false ){
				baseSubTitleString = PARAMDATA.lang.oneword.bookshelfTotalBook;
			}else{
				baseSubTitleString = ( PARAMDATA.portalFlag == false ) ? PARAMDATA.lang.oneword.bookshelfTotalCloud : PARAMDATA.lang.oneword.bookshelfTotalPortal;
			}
			var tmpSubTitle = baseSubTitleString.replace('num', this.totalbshelfData);
			
			
			if( PARAMLIBRARY.new_bs_cate_title != "" ) {
				tmpSubTitle = PARAMLIBRARY.new_bs_cate_title +" ("+this.bsCateSelectBookCount + "件)";
			}
			
			$('#totalBookshelf').html( tmpSubTitle );
			
			if($bsLib.bookshelfType == 'box')  {
				$('.bookshelf-sub-box-navbar').removeClass('bookshelf-sub-list-navbar');
				if( !$('#bookshelf-view-type').hasClass('bookshelf-view-box-type') ){
					$('#bookshelf-view-type').removeClass('bookshelf-view-list-type').addClass('bookshelf-view-box-type');
				}
				$('#bookshelf-view-type').html('');
				this.createBookShelfBox();
			}else if($bsLib.bookshelfType == 'list'){	
				$('.bookshelf-sub-box-navbar').addClass('bookshelf-sub-list-navbar');
				if( !$('#bookshelf-view-type').hasClass('bookshelf-view-list-type') ){
					$('#bookshelf-view-type').removeClass('bookshelf-view-box-type').addClass('bookshelf-view-list-type');
				}
				var bookshelfListBg = this.createBoxBg();
				$('#bookshelf-view-type').html(bookshelfListBg);
				this.createBookShelfList();
			}
			
			this.bookshelfEditMode = false;
			this.changeModeBookshelf('off');
			this.bookshelfViewAllStatusView();
 
            setTimeout(function(){
                $bsLib.checkBookShelfDownloadResume();
                $bsLib.loaded = true;
            }, $bsLib.loaded ? 0 : 1000);
 
			this.createUpdateCountView();
 
			var updatedBookList = [];
			var downloadBookList = {};

			$.each(libUpdate.updateGetListData, function(i, item) {
				updatedBookList.push(item.appBookid);
			});

			for(var data in PARAMLIBRARY.bshelf_data)
				if(PARAMLIBRARY.visible_data[data])
					downloadBookList[data] = PARAMLIBRARY.bshelf_data[data];

			var currentBookStatusList = {
				"downloadBookList" : downloadBookList,
				"updatedBookList" : updatedBookList
			}
			
			$webApiRouter.setBookListInfo(currentBookStatusList, null);
		}
	};
})(window);
