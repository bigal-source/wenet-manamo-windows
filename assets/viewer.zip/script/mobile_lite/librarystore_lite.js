_tempElement = document.createElement('div');
panelDetail=null, panelPortalDetail = null;
(function(window){
    
    var that = null, getManiThumbImg=[];
    
    window.librarystore = function() {
        "use strict";
        
        that = this;
        
        if( appFlag ) navigator.splashscreen.hide();
        this._init();
    }
    
    librarystore.prototype = {
        simulatorFlag       : false,
        
        isHtmlView          : false,
        htmlLibraryElem     : null,
        htmlviewerElem      : null,
        htmlviewer          : null,
        
        preload             : null,
        fastClicks          : true,
        isInit              : false,
        isActive            : false,
        
        isModuleLoadingNone : false,
        
        dynamicNavbar       : true,
        view                :{
            selector        : '',
            clicked         : '',
            newNavbarInner  : '',
            viewClass       : 'view',
            pagesContainer  : '',
            history         : [],
            loadPage        : function(url){
                that.loadPage(url);
            },
            goBack      : function(url){
                that.goBack(url);
            }
        },
        
        topCateTypeData     : false,    // Top category type data       
        
        totalBookData       : false,    //total data
        coverData           : false,    //coverimg data
        booknew             : false,    //新着data
        bookhot             : false,    //おすすめdata
        bookbest            : false,    //人気data
        bookbanner          : false,
        categoryData        : false,
        
        thumb_img_w         : 120,
        thumb_img_h         : 160,
        
        bookshelfKey        : 'storebookshelf',
        htmlStoremarkKey    : 'storeBookmark',
        
        tabsSelect          : 0,
        goBookshelfNum      : 0,
        bannerleftPosition  : false,
        
        isPopupDetil        : false,   //detil popup only
        isModal             : false,
        isProcessing        : false,
        thumbImageInfo      : [],
        
        modalButtonOk       : 'OK',
        modalButtonCancel   : 'キャンセル',
        
        //nitification action template
        modalActionsTemplate: '<div class="actions-modal">{{buttons}}</div>',
        modalCenterActionsTemplate: '<div class="center-actions-modal">{{buttons}}</div>',
        
        isOverLayHide       : false,
        
        swipeout            : true,
        allowSwipeout       : true,
        sortable            : true,
        allowsPanelOpen     : true,
 
        // Variables for refresh for count
        viewCloseCount      : 0,
        viewRefreshCount    : 5,
 
        /**** penel ******/
        panelsCloseByOutside : true,
        
        
        /**** mani plugin ******/
        initInfiniteScrollFlag  : true,
        initScrollToolbarsFlag  : true,
        
        _init : function(){
            PARAMDATA._updatesize();

            this.pageAppIniti();
            $loadingElem = document.querySelector('#loading');
            this.htmlLibraryElem = $('#htmlLibrary');
            this.htmlViewerElem = $('#htmlViewer');
            this.getHtml("../viewer/index.html", function(data){
                that.htmlviewer = data;
            });
            
            this.moduleSetting();
            this.fastClicksInit();

            PARAMDATA._scrollInit();
            this.storeConfig();

            this.commonEvent();
            $.extend(this, appCallBackEvent);
            this.appAddTrigger();
            libUpdate = new libupdate();
            this._mobile_event();
        },

        commonEvent : function(){
            $(document).on(utils.MOVE_EV, '.no-touch-move', function(e){ e.preventDefault; });
            $(window).on('resize', this.resize);
            $(window).on('orientationchange', this.orientationchange);
        },
        
        //cloud portal only method
        // changePortalCloudStorageKey : function(){
        //     if( isMobilePhone ){
        //         this.goBack();
        //     }
        
        //     //bookshelf category change
        //     if( PARAMDATA.portalFlag ){
        //         h5applib.bsCateKey = "phonegap-portal_bsCate";
        //     }else{
        //         h5applib.bsCateKey = h5applib.cloudKeyStr+'_bsCate';
        //     }
        //     h5applib.getBookshelfCateData();
            
        //     PARAMLIBRARY.new_bs_cate_seq = 0;
        //     PARAMLIBRARY.new_bs_cate_title = "";
            
        //     if( appFlag == false ){
        //         if( PARAMDATA.portalFlag ){
        //             this.bookshelfKey   = 'portal_storebookshelf';
        //             this.htmlStoremarkKey = 'portal_storeBookmark';
        //         }else{
        //             this.bookshelfKey   = 'cloud_storebookshelf';
        //             this.htmlStoremarkKey = 'cloud_storeBookmark';
        //         }
                
        //         h5applib.changeStorageData( this.bookshelfKey );
                
        //         if( libUpdate )  {
        //             libUpdate.clearDataInit();
        //             libUpdate.getUpdateCheckList();
        //         }
        //     }else{
        //         h5applib.getLibrarybshelfDBData( function(dbRowsData){ 
        //             h5applib.setAppParamData(dbRowsData, function(){
        //                 console.log("libStore : 255 line");
        //                 setTimeout(function(){
        //                     if( libUpdate ) {
        //                         libUpdate.clearDataInit();
        //                         libUpdate.getUpdateCheckList();
        //                     }
        //                 }, 0);
        //             });
        //         });
        //     }
        // },
        
        resize : function(){
            PARAMDATA._updatesize();
            
            if(!iosDeviceCheck ){           
                $(document).trigger(lib_defind.LIBRARY_RESIZE);
            }
            
            that.sizeNavbars( $('.ui-wstabs.selected')[0] );
        },
        
        orientationchange : function(){
            if( Math.abs(window.orientation) === 90 ) document.body.scrollTop = 0;
            PARAMDATA._updatesize();
            if( iosDeviceCheck ){
                $(document).trigger(lib_defind.LIBRARY_RESIZE);
            }
        },
        
        moduleSetting : function(){
            if(this.swipeout) swipeout.initSwipeout();
            if(this.sortable) sortable.initSortable();          
            
            try{
                $.extend(this, action);
                $.extend(this, notification);
            }catch(e){
                console.log(e);
            }
        },
        
        storeConfig : function(){
            /*tab menu setting*/
            this.modalButtonCancel = PARAMDATA.lang.oneword.confim_cancel;
            
            this.setInitTabSetting();
        
            if( appFlag ) this.simulatorFlag = false;
            
            //device setting
            if(isMobilePhone){
                this.thumb_img_w = 85;
                this.thumb_img_h = 115;
                
                if(device7inch) {
                    this.thumb_img_w = 120;
                    this.thumb_img_h = 170;
                }
            }           
        },          
        
        sizeNavbars : function(viewContainer){
            var navbarInner = viewContainer ? $(viewContainer).find('.navbar .navbar-inner') : $('.navbar .navbar-inner');
            
            navbarInner.each(function () {
                var navInner = $(this),
                    left = navInner.find('.left'),
                    right = navInner.find('.right'),
                    center = navInner.find('.center'),
                    subnavbar = navInner.find('.subnavbar'),
                    noLeft = left.length === 0,
                    noRight = right.length === 0,
                    leftWidth = noLeft ? 0 : left.outerWidth(true),
                    rightWidth = noRight ? 0 : right.outerWidth(true),
                    centerWidth = center.outerWidth(true),
                    navbarWidth = navInner.width(),
                    onLeft = navInner.hasClass('navbar-on-left'),
                    currLeft, diff;
                
                if (noRight) {
                    currLeft = navbarWidth - centerWidth;
                }
                if (noLeft) {
                    currLeft = 0;
                }
                if (!noLeft && !noRight) {
                    currLeft = (navbarWidth - rightWidth - centerWidth + leftWidth) / 2;
                }
                var requiredLeft = (navbarWidth - centerWidth) / 2;
               
                if (navbarWidth - leftWidth - rightWidth > centerWidth) {
                    if (requiredLeft < leftWidth) {
                        requiredLeft = leftWidth;
                    }
                    if (requiredLeft + centerWidth > navbarWidth - rightWidth) {
                        requiredLeft = navbarWidth - rightWidth - centerWidth;
                    }
                    diff = requiredLeft - currLeft;
                }
                else {
                    diff = 0;
                }
                
                var inverter = 1;
                
                // Center left
                var centerLeft = diff;
                if (inverter == -1 && noLeft && noRight && center.length > 0) centerLeft = -centerLeft;
                center.css({left: centerLeft + 'px'});
        
                if (center.hasClass('sliding')) {
                    center[0].f7NavbarLeftOffset = -(currLeft + diff) * inverter;
                    center[0].f7NavbarRightOffset = (navbarWidth - currLeft - diff - centerWidth) * inverter;
                    if (onLeft) center.transform('translate3d(' + center[0].f7NavbarLeftOffset + 'px, 0, 0)');
                }
                if (!noLeft && left.hasClass('sliding')) {
                    if (inverter == -1) {
                        left[0].f7NavbarLeftOffset = -(navbarWidth - left.outerWidth()) / 2 * inverter;
                        left[0].f7NavbarRightOffset = leftWidth * inverter;
                    }
                    else {
                        left[0].f7NavbarLeftOffset = -leftWidth;
                        left[0].f7NavbarRightOffset = (navbarWidth - left.outerWidth()) / 2;
                    }
                    if (onLeft) left.transform('translate3d(' + left[0].f7NavbarLeftOffset + 'px, 0, 0)');
                }
                if (!noRight && right.hasClass('sliding')) {
                    if (inverter == -1) {
                        right[0].f7NavbarLeftOffset = -rightWidth * inverter;
                        right[0].f7NavbarRightOffset = (navbarWidth - right.outerWidth()) / 2 * inverter;
                    }
                    else {
                        right[0].f7NavbarLeftOffset = -(navbarWidth - right.outerWidth()) / 2;
                        right[0].f7NavbarRightOffset = rightWidth;
                    }
                    if (onLeft) right.transform('translate3d(' + right[0].f7NavbarLeftOffset + 'px, 0, 0)');
                }

                if (subnavbar.length && subnavbar.hasClass('sliding')) {
                    subnavbar[0].f7NavbarRightOffset = -subnavbar[0].f7NavbarLeftOffset;
                }
            });
        },
        
        findElement : function(selector, container){
            container = $(container);
            var found = container.find(selector);
            
            if (found.length === 1) return found;
            else {
                return undefined;
            }
        },
        
        getHtml : function(url, callbank, asyncFlag){
        
            var asyncEnable = true;
            if( asyncFlag ) asyncEnable = false;
            
            $.ajax({
                url     : url,
                type    : 'GET',
                async   : asyncEnable,
                success : function(data){
                    callbank(data);
                }
            });
        },
        
        /*======================================================
            ************   Pages   ************
        ======================================================*/
        // Page Callbacks API
        pageAppIniti : function(){
            this.pageCallbacks = {};
            _plugins = [];
            
            var pageCallbacksNames = ('beforeInit init beforeAnimation afterAnimation beforeRemove').split(' ');
            for (var i = 0; i < pageCallbacksNames.length; i++) {
                this.pageCallbacks[pageCallbacksNames[i]] = {};
            }
            
            
        },
        
        pageInitCallback : function( view, pageContainer, url, position ){
            var pageData = {
                container: pageContainer,
                url: url,
                query: $.parseUrlQuery(url || ''),
                name: $(pageContainer).attr('data-page'),
                view: view,
                from: position
            };
            
            pageContainer.PageData = pageData;
            
            // Before Init Callbacks
            this.pluginHook('pageBeforeInit', pageData);
            this.triggerPageCallbacks('beforeInit', pageData.name, pageData);
            $(pageData.container).trigger('pageBeforeInit', {page: pageData});
            
            this.initPage(pageContainer);
            
            this.pluginHook('pageInit', pageData);
            this.triggerPageCallbacks('init', pageData.name, pageData);
            $(pageData.container).trigger('pageInit', {page: pageData});
            
        },
        
        pageRemoveCallback : function(view, pageContainer, position){
            // Page Data
            var pageData = {
                container: pageContainer,
                name: $(pageContainer).attr('data-page'),
                view: view,
                from: position
            };
            
            // Before Init Callback
            this.pluginHook('pageBeforeRemove', pageData);
            this.triggerPageCallbacks('beforeRemove', pageData.name, pageData);
            $(pageData.container).trigger('pageBeforeRemove', {page: pageData});
        },
        
        triggerPageCallbacks : function(callbackName, pageName, pageData){
            var callbacks = this.pageCallbacks[callbackName][pageName];
            if (!callbacks || callbacks.length === 0) return;
            for (var i = 0; i < callbacks.length; i++) {
                callbacks[i](pageData);
            }
        },
        
        initPage : function(pageContainer){
            if (this.initInfiniteScrollFlag) this.initInfiniteScroll(pageContainer);
            if (this.initScrollToolbarsFlag) this.initScrollToolbars( pageContainer );
        },
        
        pluginHook : function (hook) {
            for (var i = 0; i < _plugins.length; i++) {
                if (_plugins[i].hooks && hook in _plugins[i].hooks) {
                    _plugins[i].hooks[hook](arguments[1], arguments[2], arguments[3], arguments[4], arguments[5]);
                }
            }
        },
        /*======================================================
            ************  Pages  END   ************
        ======================================================*/
        
        loadPage : function(url){
            $.get(url, function(data){
                that._load(url, data);
            });
        },
        
        _load : function(url, data){
            var viewContainer = $(this.view.selector),
                clickedElem = this.view.clicked,
                newPage, oldPage, navbar, newNavbarInner, oldNavbarInner;
            
            _tempElement.innerHTML = '';
            _tempElement.innerHTML = data;
            
            newPage = this.findElement('.page', _tempElement);
            
            if(!newPage){
                h5applib.nalert('ELEMENT NOT DATA', 'WISEBOOK');
                that.isActive = false;
                that._loadingImgView('none');
                return;
            }
            
            if(this.dynamicNavbar){
                newNavbarInner = this.findElement('.navbar-inner', _tempElement);
            }
            
            if( clickedElem.hasClass('wait-process') ){
                var module = clickedElem.attr('data-filter');
                                
                switch(module){
                    case 'member' :
                        that.viewMemeberInfo(_tempElement);
                        break;                      
                }
            }
            
            //newPage.find('.login-copyright span').text( (PARAMLIBRARY.memberinfo.copyright) ? PARAMLIBRARY.memberinfo.copyright : PARAMDATA.libInfo.copyright );
            
            newPage.addClass('page-on-right');
            
            oldPage = viewContainer.find('.page');
            $(this.view.pagesContainer).append(newPage[0]);
                        
            this.view.url = url;
            this.view.history.push(url);
            this.view.newNavbarInner = newNavbarInner;
            
            this.pageInitCallback(this.view, newPage[0], url, 'right');
            
            newNavbarInner.find('.sliding').each(function () {
                var sliding = $(this);
                
                sliding.transform('translate3d(' + (this.f7NavbarRightOffset) + 'px,0,0)');
                
                if (sliding.hasClass('left') && sliding.find('.back .icon').length > 0) {
                    sliding.find('.back .icon').transform('translate3d(' + (-this.f7NavbarRightOffset) + 'px,0,0)');
                }
            });
            
            if(this.dynamicNavbar){
                navbar = viewContainer.find('.navbar');
                
                oldNavbarInner = navbar.find('.navbar-inner');              
                
                newNavbarInner.addClass('navbar-on-right');
                navbar.append(newNavbarInner[0]);
            }
            
            this.pageAnimCallbacks('before', {pageContainer: newPage[0], url: url, position: 'right', oldPage: oldPage, newPage: newPage});
            
            
            this.animatePages(oldPage, newPage, 'to-left');
            
            if(this.dynamicNavbar){
                setTimeout(function () {
                    that.animateNavbars(oldNavbarInner, newNavbarInner, 'to-left');
                }, 0);
            }
            
            if(that.isModuleLoadingNone == false) that._loadingImgView('none');
            
            this.sizeNavbars( newPage.parents('.' + that.view.viewClass)[0] );
            
            newPage.animationEnd(function (e) {
                that.isActive = false;
                
                newPage.removeClass('page-from-right-to-center page-on-right').addClass('page-on-center');
                oldPage.removeClass('page-from-center-to-left').addClass('page-on-left');
                
                if (that.dynamicNavbar) {
                     newNavbarInner.removeClass('navbar-from-right-to-center').addClass('navbar-on-center');
                     oldNavbarInner.removeClass('navbar-from-center-to-left').addClass('navbar-on-left');
                }
                
                that.pageAnimCallbacks('after', {pageContainer: newPage[0], url: url, position: 'right', oldPage: oldPage, newPage: newPage});
            });
            
        },
        
        animatePages : function(leftPage, rightPage, direction){
            // Loading new page
            if (direction === 'to-left') {
                leftPage.removeClass('page-on-center').addClass('page-from-center-to-left');
                rightPage.addClass('page-from-right-to-center');
            }
            // Go back
            if (direction === 'to-right') {
                leftPage.removeClass('page-on-left').addClass('page-from-left-to-center');
                rightPage.removeClass('page-on-center').addClass('page-from-center-to-right');
            }
        },
        
        animateNavbars : function(leftNavbarInner, rightNavbarInner, direction){
            // Loading new page
            var removeClasses = 'navbar-on-right navbar-on-center navbar-on-left';
            if (direction === 'to-left') {
                rightNavbarInner.removeClass(removeClasses).addClass('navbar-from-right-to-center');
                rightNavbarInner.find('.sliding').each(function () {
                    var sliding = $(this);
                    sliding.transform('translate3d(0px,0,0)');
                });
                
                leftNavbarInner.hide();
                leftNavbarInner.removeClass(removeClasses).addClass('navbar-from-center-to-left');   
                leftNavbarInner.find('.sliding').each(function () {
                    var sliding = $(this);
                    sliding.transform('translate3d(' + (this.f7NavbarLeftOffset) + 'px,0,0)');
                });   
            }
            
             // Go back
             if (direction === 'to-right') {
                leftNavbarInner.show();
                leftNavbarInner.removeClass(removeClasses).addClass('navbar-from-left-to-center');
                leftNavbarInner.find('.sliding').each(function () {
                    var sliding = $(this);
                    sliding.transform('translate3d(0px,0,0)');
                });
                
                rightNavbarInner.removeClass(removeClasses).addClass('navbar-from-center-to-right');
                rightNavbarInner.find('.sliding').each(function () {
                    var sliding = $(this);
                    sliding.transform('translate3d(' + (this.f7NavbarRightOffset) + 'px,0,0)');
                });
                
             }
        },
        
        pageAnimCallbacks : function(callback, params){
            
            var oldPage = params.oldPage,
                newPage = params.newPage;
            
            if (callback === 'after') {
                            
            }else if( callback === 'before' ){
                 if (newPage.hasClass('no-navbar') && !oldPage.hasClass('no-navbar')) {
                 
                 }
                 if (!newPage.hasClass('no-navbar') && oldPage.hasClass('no-navbar')) {
                 
                 }
                 if (newPage.hasClass('no-sub-navbar') && !oldPage.hasClass('no-sub-navbar')) {
                    this.hideSubNavbar();
                 }
                 
                 if ( !newPage.hasClass('no-sub-navbar') && oldPage.hasClass('no-sub-navbar')) {
                    this.showSubNavbar();
                 }
            }
        },
        
        hideSubNavbar : function(){
            $(this.view.selector).addClass('hidden-sub-navbar').animationEnd(function(){
                $(that.view.selector).addClass('hidden-sub-navbar-complete');
            });
        },
        
        showSubNavbar : function(){
            $(this.view.selector).addClass('hidden-sub-navbar').removeClass('hidden-sub-navbar hidden-sub-navbar-complete').animationEnd(function(){
                $(that.view.selector).removeClass('hidden-sub-navbar');
            });
        },
        
        afterGoBack : function(oldPage, newPage, oldNavbarInner, newNavbarInner){
             oldPage = $(oldPage);
             newPage = $(newPage);
             
             this.pageRemoveCallback(this.view, oldPage[0], 'right');
             oldPage.remove();
             
             newPage.removeClass('page-from-left-to-center page-on-left').addClass('page-on-center');
               
             // Updated dynamic navbar
            if (this.dynamicNavbar) {
                $(oldNavbarInner).remove();
                $(newNavbarInner).removeClass('navbar-on-left navbar-from-left-to-center').addClass('navbar-on-center');
            }

            // Update View's History
            this.view.history.pop();
        },
        
        goBack : function(url){
            var viewContainer = $(this.view.selector),
                pagesInView = viewContainer.find('.page'),
                clickedElem = this.view.clicked,
                oldPage, newPage, oldNavbarInner, newNavbarInner, navbar;
            
            function _animate() {
                that.pageAnimCallbacks('before', {pageContainer: newPage[0], url: url, position: 'left', oldPage: oldPage, newPage: newPage});
                
                that.animatePages(newPage, oldPage, 'to-right');
 
                // Dynamic navbar animation
                if (that.dynamicNavbar) {               
                    setTimeout(function () {
                        that.animateNavbars(newNavbarInner, oldNavbarInner, 'to-right');
                    }, 0);
                }
                
                newPage.animationEnd(function () {
                    that.isActive = false;
                    that.afterGoBack(oldPage[0], newPage[0], oldNavbarInner[0], newNavbarInner[0]);
                    that.pageAnimCallbacks('after', {pageContainer: newPage[0], url: url, position: 'left', oldPage: oldPage, newPage: newPage});
                });
                
                
                that.sizeNavbars( newPage.parents('.' + that.view.viewClass)[0] );
                
                if( newNavbarInner.hasClass('navbar-on-left') ){
                    newNavbarInner.find('.sliding').each(function () {
                        var sliding = $(this);
                        sliding.transform('translate3d(' + (this.f7NavbarLeftOffset) + 'px,0,0)');
                    });
                }               
            }
            
            if (pagesInView.length > 1) {
                newPage = $(pagesInView[pagesInView.length - 2]);
                oldPage = $(pagesInView[pagesInView.length - 1]);
                
                // Dynamic navbar
                if(this.dynamicNavbar){ 
                    dynamicNavbar = true;
                    // Find navbar
                    var inners = viewContainer.find('.navbar-inner');
                            
                    newNavbarInner = $(inners[inners.length-2]);
                    oldNavbarInner = $(inners[inners.length-1]);
                }
                
                _animate();
            }else{
                
            }
        },
        
        
        popup : function(modal, removeOnClose){
            if (typeof removeOnClose != 'undefined') removeOnClose = true;
            
            if (typeof modal === 'string' && modal.indexOf('<') >= 0) {
                 var _modal = document.createElement('div');
                 _modal.innerHTML = $.trim(modal);
                
                 if (_modal.childNodes.length > 0) {
                    modal = _modal.childNodes[0];
                    if (removeOnClose) modal.classList.add('remove-on-close');
                    $('body').append(modal);
                    
                 }else return false;
            }else{
                if(removeOnClose){
                    $(modal).addClass('remove-on-close');
                }
            }           
            
            that.isActive = true;
            
            modal = $(modal);
            
            if (modal.length === 0) return false;
            modal.css('display', 'block');
            
            if (modal.find('.' + that.view.viewClass).length > 0) {
                that.sizeNavbars(modal.find('.' + that.view.viewClass)[0]);
            }

            var overlayClickRemoveCheck = false;
            if( modal.hasClass('no-overlay-to-remove') ) overlayClickRemoveCheck = true;
            
            this.openModal(modal, overlayClickRemoveCheck);
        },
        
        openModal : function(modal, noRemoveOverlayClose){
            modal = $(modal);

            var isPopover = modal.hasClass('popover');
            var isPopup = modal.hasClass('popup');
            var marginTop = Math.round(modal.outerHeight() / 2);
            if(androidDeviceCheck && isMobilePhone) marginTop += 80;
            if (!isPopover && !isPopup) modal.css({marginTop: - marginTop + 'px'});
            
            if ($('.modal-overlay').length === 0 && !isPopup) {
                $('body').append('<div class="modal-overlay"></div>');
            }
            if ($('.popup-overlay').length === 0 && isPopup) {
                $('body').append('<div class="popup-overlay"></div>');
            }
            var overlay = isPopup ? $('.popup-overlay') : $('.modal-overlay');
            
            if( noRemoveOverlayClose ) overlay.addClass('modal-overlay-visible modal-no-remove');
            else overlay.addClass('modal-overlay-visible');
            
            modal.trigger('open', modal);
            
            that.isModal = true;
            
            setTimeout(function(){
                modal.removeClass('modal-out').addClass('modal-in').transitionEnd(function (e) {
                    modal.trigger('opened', modal);
                });
            }, 100);
            
        },
        
        closeModal : function(modal){
            modal = $(modal || '.modal-in');
            //$('.modal-overlay').removeClass('modal-overlay-visible');
            //modal.trigger('close');
            
            var isPopover = modal.hasClass('popover');
            var isPopup = modal.hasClass('popup');
            var removeOnClose = modal.hasClass('remove-on-close');
            
            var overlay = isPopup ? $('.popup-overlay') : $('.modal-overlay');
            
            overlay.removeClass('modal-overlay-visible');
            
            that.isOverLayHide = false;
            
            modal.trigger('close', modal);

            if( h5applib.isKeyboard ) h5applib.keyboardHide();

            if(!isPopover){
                modal.removeClass('modal-in').addClass('modal-out').transitionEnd(function (e) {
                    modal.trigger('closed', modal);
                    
                    if (!isPopup) modal.remove();
                    if (isPopup) modal.removeClass('modal-out').hide();
                    overlay.remove();
                    if (removeOnClose) modal.remove();
                    
                    if( $('.popup-overlay').length != 0 || $('.modal-overlay').length != 0 ) that.isModal = true;
                    else that.isModal = false;
                    
                    that.isActive = false;
                }); 
            }else{
                if(that.swipeout){
                    if(swipeout.swipeoutOpenedEl) swipeout.swipeoutClose( swipeout.swipeoutOpenedEl, function(){
                        that.allowSwipeout = true;
                    } );
                }
                
                modal.removeClass('modal-in modal-out').trigger('closed').hide();
                
                if (removeOnClose) modal.remove();
                
                if( $('.popup-overlay').length != 0 || $('.modal-overlay').length != 0 ) that.isModal = true;
                else that.isModal = false;
                
                that.isActive = false;
                
            }
            
        },
        
        popover : function(modal, target){
            if (typeof modal === 'string' && modal.indexOf('<') >= 0) {
                
                var _modal = document.createElement('div');
                _modal.innerHTML = $.trim(modal);
                
                if (_modal.childNodes.length > 0) {
                    modal = _modal.childNodes[0];
                    modal.classList.add('remove-on-close');
                    $('body').append(modal);
                }else return false;
            }
            
            modal = $(modal);
            
            target = $(target);
            
            if (modal.length === 0 || target.length === 0) return false;
            
            modal.show();
            function sizePopover() {
                modal.css({left: '', top: ''});
                var modalWidth =  modal.width();
                var modalHeight =  modal.height(); // 13 - height of angle
                var modalAngle = modal.find('.popover-angle');
                var modalAngleSize = modalAngle.width() / 2;
                modalAngle.removeClass('on-left on-right on-top on-bottom').css({left: '', top: ''});
                    
                var targetWidth = target.outerWidth();
                var targetHeight = target.outerHeight();
                var targetOffset = target.offset();
                var targetParentPage = target.parents('.page');
                if (targetParentPage.length > 0) {
                    targetOffset.top = targetOffset.top - targetParentPage[0].scrollTop;
                }
                    
                var windowHeight = $(window).height();
                var windowWidth = $(window).width();

                var modalTop = 0;
                var modalLeft = 0;
                var diff = 0;
                // Top Position
                var modalPosition = 'top';
                    
                if ((modalHeight + modalAngleSize) < targetOffset.top) {
                    // On top
                    modalTop = targetOffset.top - modalHeight - modalAngleSize;
                }
                else if ((modalHeight + modalAngleSize) < windowHeight - targetOffset.top - targetHeight) {
                    // On bottom
                    modalPosition = 'bottom';
                    modalTop = targetOffset.top + targetHeight + modalAngleSize;
                }
                else {
                    // On middle
                    modalPosition = 'middle';
                    modalTop = targetHeight / 2 + targetOffset.top - modalHeight / 2;
                    diff = modalTop;
                    if (modalTop < 0) {
                    modalTop = 5;
                    }
                    else if (modalTop + modalHeight > windowHeight) {
                    modalTop = windowHeight - modalHeight - 5;
                    }
                    diff = diff - modalTop;
                }
                // Horizontal Position
                if (modalPosition === 'top' || modalPosition === 'bottom') {
                    modalLeft = targetWidth / 2 + targetOffset.left - modalWidth / 2;
                    diff = modalLeft;
                    if (modalLeft < 5) modalLeft = 5;
                    if (modalLeft + modalWidth > windowWidth) modalLeft = windowWidth - modalWidth - 5;
                    if (modalPosition === 'top') modalAngle.addClass('on-bottom');
                    if (modalPosition === 'bottom') modalAngle.addClass('on-top');
                    diff = diff - modalLeft;
                    modalAngle.css({left: (modalWidth / 2 - modalAngleSize + diff) + 'px'});
                }
                else if (modalPosition === 'middle') {
                    modalLeft = targetOffset.left - modalWidth - modalAngleSize;
                    modalAngle.addClass('on-right');
                    if (modalLeft < 5) {
                    modalLeft = targetOffset.left + targetWidth + modalAngleSize;
                    modalAngle.removeClass('on-right').addClass('on-left');
                    }
                    if (modalLeft + modalWidth > windowWidth) {
                    modalLeft = windowWidth - modalWidth - 5;
                    modalAngle.removeClass('on-right').addClass('on-left');
                    }
                    modalAngle.css({top: (modalHeight / 2 - modalAngleSize + diff) + 'px'});
                }

                // Apply Styles
                modal.css({top: modalTop + 'px', left: modalLeft + 'px'});
            }
            sizePopover();
                    
            $(window).on('resize', sizePopover);
            modal.on('close', function () {
                $(window).off('resize', sizePopover);
            });
            
            this.openModal(modal);
        },
        
        openPanel : function(panelPosition){
            if (!this.allowsPanelOpen) return false;
            var panel = $('.panel-' + panelPosition);
            if (panel.length === 0 || panel.hasClass('active')) return false;
            
            if( that.view.clickElem.attr( "panel-move-left" ) )  
                panel.addClass( that.view.clickElem.attr( "panel-move-left" ) ).attr( "move-change", that.view.clickElem.attr( "panel-move-left" ) );
            
            this.closePanel();
            this.allowPanelOpen = false;
            var effect = panel.hasClass('panel-reveal') ? 'reveal' : 'cover';
            panel.css({display: 'block'}).addClass('active');
            panel.trigger('open', panel);
            
            if (panel.find('.' + that.view.viewClass).length > 0) {
                if (that.sizeNavbars) that.sizeNavbars(panel.find('.' + that.view.viewClass)[0]);
            }
            
            // Trigger reLayout
            var clientLeft = panel[0].clientLeft;
            
            // Transition End;
            var transitionEndTarget = effect === 'reveal' ? $('.' + that.view.viewsClass) : panel;
            var openedTriggered = false;
            this.isActive = true;
            
            function panelTransitionEnd(){
                transitionEndTarget.transitionEnd(function (e) {
                    if ($(e.target).is(transitionEndTarget)) {
                        if (panel.hasClass('active')) {
                            panel.trigger('opened');
                        }else {
                            panel.trigger('closed');
                        }
                        that.allowPanelOpen = true;
                        that.isActive = false;
                    }
                    else panelTransitionEnd();
                });
            }
                        
            panelTransitionEnd();
            
            $('body').addClass('with-panel-' + panelPosition + '-' + effect);
        },
        
        closePanel : function(){
            var activePanel = $('.panel.active');
            if (activePanel.length === 0) return false;
            
            this.isActive = true;
            var effect = activePanel.hasClass('panel-reveal') ? 'reveal' : 'cover';
            var panelPosition = activePanel.hasClass('panel-left') ? 'left' : 'right';
            activePanel.removeClass('active');
            
            var transitionEndTarget = effect === 'reveal' ? $('.' + this.view.viewsClass) : activePanel;
            activePanel.trigger('close');
            
            transitionEndTarget.transitionEnd(function () {
                if (activePanel.hasClass('active')) return;
                activePanel.css({display: ''});
                activePanel.trigger('closed');
                $('body').removeClass('panel-closing');
                
                if( activePanel.attr("move-change") ) {
                    activePanel.removeClass( activePanel.attr("move-change") ).removeAttr( "move-change" );
                }
                
                that.allowPanelOpen = false;
                that.isActive = false;
            });
            
            
            $('body').addClass('panel-closing').removeClass('with-panel-' + panelPosition + '-' + effect);
        },
        
        disttypeAction : function(bookObj){
            var actions = [];
            
            switch (bookObj.disttype) {
                case '1': // stream
                    actions.push({ text: PARAMDATA.lang.oneword.disttype_stream, onClick: function () { 
                            bookObj.sel_disttype = "stream";
                            that._downloadBookData(bookObj);
                        }
                     });
                    break; 

                case '2': // download
                    actions.push({ text: PARAMDATA.lang.oneword.disttype_download, onClick: function () {
                            bookObj.sel_disttype = "download";
                            that._downloadBookData(bookObj);
                        }
                    });
                    break; 

                case '3': // hybrid
                    actions.push({ text: PARAMDATA.lang.oneword.disttype_stream, onClick: function () {
                            bookObj.sel_disttype = "stream";
                            that._downloadBookData(bookObj);
                        }
                    });
                    
                    actions.push({ text: PARAMDATA.lang.oneword.disttype_download, onClick: function () {
                            bookObj.sel_disttype = "download";
                            that._downloadBookData(bookObj);
                        }
                    });
                    break; 

            }
            
            var cancelBtn = [
            {
                text : that.modalButtonCancel,
                bold : true
            }];
            
            this._centerAction([actions, cancelBtn], bookObj);
        },
        
        handleTapsEvent : function(){
            var clicked = $(this),
                bookid = clicked.attr('bookid');
                        
            if( clicked.hasClass('btn_download') || clicked.hasClass('btn_reade') ){
                var infoObj = { bookid : bookid, author : clicked.attr('data-author') };
                
                var checkBookStartus = that.checkGotoViewer( infoObj );
                if( checkBookStartus == false ) return false;
                    
                that._getServerToBookInfo( infoObj, function(returnData, obj){
                    if( returnData != 'ok' ) return false;
                    if( obj == "null" ){
                        h5applib.nalert(PARAMDATA.lang.message.not_book_data, 'BOOK ERROR');
                        return false;
                    }

                    that.disttypeAction( obj );
                } );
                
                return false;
            }
            
            if( clicked.hasClass('btn_download_before') ){
                var reDnObj = PARAMLIBRARY.bshelf_data[bookid];
            
                h5applib.showConfirm(PARAMDATA.lang.message.download_confirm, reDnObj.objcontents.title, 
                    function(){
                        reDnObj.selected = 'update',
                        reDnObj.eventType = "bookDownloadingStatus",
                        reDnObj.status = 20;
                        reDnObj.progress = 0;
                        reDnObj.objcontents.sel_disttype = 'download';
                        reDnObj.thumbPath = reDnObj.objcontents.image;
                        
                        $.extend(PARAMLIBRARY.bshelf_data[bookid], reDnObj);
                        h5applib.startBookDownload(PARAMLIBRARY.bshelf_data[bookid]);
                        libBookShelf.refresh();
                    }
                );
            
                return false;
            }
                        
            if( clicked.hasClass('banner-action') ){
                
            }
        },
        
        handleClicks : function(e){
            e.preventDefault();
            
            if(that.isActive == true) return false;
            
            var clicked = $(this),
                clickedClassArr = this.className.split(' ');
            
            that.view.clickElem = clicked;

            if( $.inArray('new-page',  clickedClassArr) != -1 || $.inArray('goBack',  clickedClassArr)  != -1 ){
                if( clicked.hasClass('check-bookshelf-select-count') ){
                    if( libBookShelf.bookshelfSelectedBook.length <= 0 ){
                        return false;
                    }
                }
                
                if($.inArray('new-page',  clickedClassArr) != -1) that._loadingImgView('show');
                if( that.isActive ) return false;
                
                
                that.isActive = true;
                that.view.clicked = clicked;
                that.view.selector = clicked.parents('.' + that.view.viewClass)[0];
                that.view.pagesContainer = $(that.view.selector).find('.pages');
                
                if( clicked.hasClass('new-page')  ) that.view.loadPage(clicked.attr('href'));
                else that.view.goBack(clicked.attr('href'));
                
                
            }else if( $.inArray('open-popup', clickedClassArr) != -1 || $.inArray('tap-open-popup', clickedClassArr) != -1 ){               
                var popup;
                //disttype check
                var tmpBookid = clicked.attr('bookid');
                
                if( typeof(tmpBookid) != "undefined" ){
                    
                    var nextStepFlag = true,
                        infoObj = { bookid : tmpBookid, author : clicked.attr('data-author') };
                    
                    that._getServerToBookInfo(  infoObj, function(returnData, obj){
                        if( returnData != 'ok' || obj == "null") {
                            nextStepFlag = false;
                            return false;
                        }
                        
                        if( !clicked.hasClass('only-detail-popup') ){
                            
                            var checkBookStartus = that.checkGotoViewer( infoObj );
                            
                            if( checkBookStartus == false ) {
                                nextStepFlag = false;
                                return false;
                            }
                        }
                        
                        if( obj.detailinfo_flag == "0" ){
                            that.disttypeAction( obj );
                            nextStepFlag = false;
                        }else{
                            that._detailBookInfoAdd(obj);
                        }
                        
                    } );
                    //return false;
                    if( !nextStepFlag ) return false;
                }
                
                if( clicked.hasClass('data-popup') ){
                    popup = clicked.attr('data-popup'); 
                }else if( typeof(clicked.attr('data-href') ) != "undefined" ){
                    
                    var getHref = clicked.attr('data-href');
                    that.getHtml(getHref, function(data){
                        that.popup(data, 'remove-on');
                    });
                    
                    return false;
                }else{
                    popup = '.popup';
                }
                
                that.popup(popup);
                
            }else if( $.inArray('modal-overlay', clickedClassArr) != -1 || $.inArray('popup-overlay', clickedClassArr) != -1 ){
                
                if( clicked.hasClass('modal-no-remove') || that.isOverLayHide == true ) return ;
                
                if(that.isModal == true) {
                    if( $('.popup.modal-in').size() > 0 ) that.closeModal('.popup.modal-in');
                    else that.closeModal();
                }
                
            }else if( $.inArray('open-popover', clickedClassArr) != -1 ){

                var popover;
                
                if( clicked.hasClass('check-bookshelf-select-count') ){
                    if( libBookShelf.bookshelfSelectedBook.length <= 0 ){
                        return false;
                    }
                }
                
                if ( clicked.attr('data-popover') ) {
                    popover = clicked.attr('data-popover');
                }else if( clicked.attr('data-href')  ){
                    var getHref = clicked.attr('data-href');

                    that.getHtml(getHref, function(data){
                        that.popover(data, clicked);
                    });
                    
                    return false;
                }else popover = '.popover';
                
                that.popover(popover, clicked);
                
            }else if( $.inArray('all-data-refresh', clickedClassArr) != -1 || $.inArray('all-portal-refresh', clickedClassArr) != -1 ){
                
                // if( h5applib.getConnectStatus() != 'ok'  ) {
                //     h5applib.nalert(PARAMDATA.lang.message.networkcheck, PARAMDATA.lang.oneword.ERROR);
                //     return false;
                // }

                // if( !PARAMLIBRARY.responseCheck ){
                //     h5applib.nalert(PARAMDATA.lang.message.responseError, PARAMDATA.lang.oneword.ERROR);
                //     return false;
                // }
                
                // that._loadingImgView('show');
                
                // if( cloudFlag == false ) that.libraryRefresh();
                // else {
                //     if( PARAMDATA.portalFlag == true ){
                //         that.portalRefresh(function(){
                //             that._loadingImgView('none');
                //         });
                //     }else{
                //         that.cloudRefresh(function(){
                //             that._loadingImgView('none');
                //         });
                //     }
                // }
                
                // return false;
            }else if( $.inArray('close-popup', clickedClassArr) != -1 ){
                
                if(that.isModal == true) that.closeModal('.popup.modal-in');
                
            }else if( $.inArray('open-panel', clickedClassArr) != -1 ){
                if ($('.panel').length === 1) {
                    if ($('.panel').hasClass('panel-left')) that.openPanel('left');
                    else that.openPanel('right');
                }else {
                    if (clicked.attr('data-panel') === 'right') that.openPanel('right');
                    else that.openPanel('left');
                }               
            }else if( $.inArray('close-panel', clickedClassArr) != -1 ){
                that.closePanel();
            }else if( $.inArray('panel-overlay', clickedClassArr) != -1 && that.panelsCloseByOutside  ){
                that.closePanel();
            }else if( $.inArray('tab-link',  clickedClassArr) != -1  ) {
                //var tmptab = clicked.attr('data-tab');
                //that.showTab( tmptab, clicked );
                
                return false;
            }
            
        },
                
        _mobile_event : function(){         
            $(document).on('click', '.new-page', this.handleClicks);
            
            $(document).hammer().on('tap', '.btn_download, .btn_reade, .banner-action, .btn_download_before, .portal-book-down', this.handleTapsEvent);
            
            $(document).hammer({tap_max_touchtime:200}).on('tap', '.open-popup, .tap-open-popup, .tab-btn, .goBack,  .open-panel, .close-panel, .panel-overlay, .modal-overlay, .popup-overlay, .close-popup, .open-popover, .all-data-refresh, .all-portal-refresh', this.handleClicks);
            
            /* POPUP TRIGGER */
            //popup open before event
            $(document).on('open', '.popup', function(e, popupElem){
                that.sizeNavbars($(popupElem).find('.' + that.view.viewClass)[0]);
            });
            
            //popup open after event
            $(document).on('opened', '.popup', function(e, popupElem){
                that.isActive = false;
            });
            
            
            $(document).on('close', '.popup', function (e, closeElem) {
                //$('body').removeClass('with-popup');
            });         
            //popup close after event
            $(document).on('closed', '.popup', function (e, closeElem) {

            });
            
            $(document).on('opened', '.modal', function(e, modalElem){
                
            });
            
            $(document).on('open', '.panel', function(e, panelElem){
                if( $(panelElem).hasClass("panel-left") ){
                    
                }else{
                    
                }
            });
            
            //sortable sort end
            $(document).on('sort', '.sortable', function(e){
                if( bsCategory ){
                    bsCategory.bsCategorySortProcessing();
                }               
                //console.log( $(this).find('li.sorte-li') );
            });
        },
        /**************************************************************************
                tabs
        **************************************************************************/
        

        _downloadBookData : function(bookObj) {         
            //no download
            if( that.isProcessing ){
                h5applib.nalert(PARAMDATA.lang.message.download_one, PARAMDATA.lang.oneword.disttype_download);
                
                return false;
            }
            that.closePanel();
            that.bookDownloadSetting(bookObj);
        },
        
        bookDownloadSetting : function(bookObj){    
            // that._loadingImgView('show');
            //psy 修正項目
                        
            var tempAppBookid = this.getPlanAppBookid(bookObj);         
            
            try{
                //queuは後で実装すると思う
                var checkProcessQueue = this.checkDownloadProceesingEnableQueu(tempAppBookid);
                
                if( checkProcessQueue == false ){
                    var thumbInfo =  that.getThumbImageInfo(bookObj.bookid);
                    var tempDnObj = {};
                    console.debug('bookDownloadSetting',bookObj);
                    tempDnObj.app_book_id = tempAppBookid;
                    tempDnObj.selected = 'download';
                    tempDnObj.eventType = 'bookDownloadingStatus';

                    if (bookObj.sel_disttype == 'stream') {
                        tempDnObj.bookPath = bookObj.stream_url;
                    }
                    else {
                        tempDnObj.bookPath = '/';
                    }

                    tempDnObj.thumbPath = bookObj.image;
                    tempDnObj.thumb_w = ( thumbInfo != null ) ? thumbInfo.tag.width : bookObj.image_w;
                    tempDnObj.thumb_h = ( thumbInfo != null ) ? thumbInfo.tag.height : bookObj.image_h;
                    tempDnObj.sortno = Object.keys(PARAMLIBRARY.bshelf_data).length + 1;
                    
                    if( typeof(bookObj.catchcopy) != 'string' ) bookObj.catchcopy = '';
                    if( typeof(bookObj.category) != 'string' )  bookObj.category = '';
                    
                    if( cloudFlag && PARAMDATA.portalFlag == false ){
                        bookObj.clouduser = PARAMDATA.memInfo.userid;
                    }
                    
                    tempDnObj.objcontents = bookObj;

                    if( this.isProcessing == true ){
                        tempDnObj.procQueuStatus = 'W';
                        PARAMDATA.downloadQueue.push(tempDnObj);
                    }else{
                        this.isProcessing = true;
                        
                        PARAMDATA.downloadQueue.push(tempDnObj);
                        h5applib.startBookDownload(tempDnObj);
                    }

                    that.queuProcessing();
                }else{
                    h5applib.nalert('DOWNLOAD QUEUEに存在しています', 'WISEBOOK');
                    return false;
                }
            }catch(e){
                console.log(e);
                h5applib.nalert('error download start', 'WISEBOOK');
                this._loadingImgView('none');
                this.isProcessing = false;
            }
            
        },
        
        // var infoObj = { bookid : bookid, author : clicked.attr('data-author') };
                
        // var checkBookStartus = that.checkGotoViewer( infoObj );
        // if( checkBookStartus == false ) return false;
            
        // that._getServerToBookInfo( infoObj, function(returnData, obj){
        //     if( returnData != 'ok' ) return false;
        //     if( obj == "null" ){
        //         h5applib.nalert(PARAMDATA.lang.message.not_book_data, 'BOOK ERROR');
        //         return false;
        //     }

        //     that.disttypeAction( obj );
        // } );

        bookOpenStream : function(obj) {
            var infoObj = {author:obj.memId, bookid:obj.bookSeq},
                tempAppBookid = this.getPlanAppBookid(infoObj),
                dbObj = this.checkDownloadData(tempAppBookid);

            console.log('-------server--------',obj);
            
            if(dbObj) {
                console.log('-------db book start1--------',dbObj);
                h5applib.createViewStream(dbObj, obj);
                return;
            }
            
            try{
                //book detail 情報を取ってからgo
                this._getServerToBookInfo( infoObj, function(returnData, detailInfoObj){
                    if( returnData != 'ok' ) return false;
                    if( detailInfoObj == "null" ){
                        h5applib.appAlert(PARAMDATA.lang.message.not_book_data, 'BOOK ERROR',
                            function(){
                                $webApiRouter.closeViewerToLibrary();
                            }
                        );
                        return false;
                    }
                    
                    var tempDnObj = {};
                    tempDnObj.app_book_id = tempAppBookid;
                    tempDnObj.selected = 'open';
                    tempDnObj.bookPath = obj.bookPath;

                    var bookObj = detailInfoObj;
                    bookObj.sel_disttype = "stream";
                    tempDnObj.objcontents = bookObj;
                    
                    h5applib.openBookInsertDB(tempDnObj,function(data) {
                        PARAMLIBRARY.bshelf_data[tempAppBookid] = data;
                        var dbObj = libStore.checkDownloadData(tempAppBookid);
                        if(dbObj) {
                            console.log('-------db book start2--------',dbObj);
                            h5applib.createViewStream(dbObj,obj);
                            return;
                        }
                    });
                });
            }catch(e){
                console.log(e);
            }            
        },
        
        viewerBookDataDownload : function(type, eventTarget){
            //type -> download, streamDownload
            if( !this.isHtmlView ) return false; //view open
            console.log(type);
            console.time("download");
            //PARAMLIBRARY.createViewInfo
            
            
            var obj = PARAMLIBRARY.createViewInfo.objcontents;
            obj.sel_disttype = ( type == "download" ) ? "download" : "stream";
            that._downloadBookData(obj);
        },
        
        /*************************************************************************************
            START : BOOK DATA CHECK SOURCE  
        **************************************************************************************/
        returnAppObject : function(bookid){
            for(var appkey in PARAMLIBRARY.bshelf_data){
                if(PARAMLIBRARY.bshelf_data[appkey].objcontents.bookid == bookid){
                    return PARAMLIBRARY.bshelf_data[appkey];
                    break;
                }
            }
        },
        
        checkDownloadData : function(appBookid){
            for(var appkey in PARAMLIBRARY.bshelf_data){
                if(PARAMLIBRARY.bshelf_data[appkey].app_book_id == appBookid){
                    return PARAMLIBRARY.bshelf_data[appkey];
                    break;
                }
            }
            
            return false;
        },
        
        checkGotoViewer : function(obj){
            //mobile browser only
            var tempAppBookid = this.getPlanAppBookid(obj);     
            var downloadObj =  this.checkDownloadData(tempAppBookid);
                        
            if(downloadObj && downloadObj.status == 100){
                this._loadingImgView('none');

                //downloadが streamの場合network check
                if( downloadObj.objcontents.sel_disttype == 'stream' && h5applib.getConnectStatus() != 'ok' ){
                    h5applib.nalert(PARAMDATA.lang.message.networkcheck, PARAMDATA.lang.oneword.ERROR);
                    
                    return false;
                }

                //server側 対応error
                if( downloadObj.objcontents.sel_disttype == 'stream' && !PARAMLIBRARY.responseCheck ){
                    h5applib.nalert(PARAMDATA.lang.message.networkcheck, PARAMDATA.lang.oneword.ERROR);
                    
                    return false;
                }
                
                h5applib.createView(downloadObj.app_book_id);
                
                return false;
            }
            
            return true;
        },
        
        getPlanAppBookid : function( obj ){
            var tempAppBookid = "";

            if( cloudFlag == false ){
                tempAppBookid = PARAMDATA.memInfo.auth+'_'+obj.bookid;
            }else{
                tempAppBookid = ( !PARAMDATA.portalFlag ) ? PARAMDATA.memInfo.auth+'_'+PARAMDATA.memInfo.userid+'_'+obj.bookid : "portal_" +  obj.bookid; 
            }
            
            return tempAppBookid;
        },
        
        /*************************************************************************************
            START : processing queu  
        **************************************************************************************/
        checkDownloadProceesingEnableQueu : function(appBookId){
            var enableQueu = false;
            
            for( var key in PARAMDATA.downloadQueue ){
                var queuValue = PARAMDATA.downloadQueue[key];
                if( queuValue.app_book_id == appBookId ){
                    enableQueu = true;
                    break;
                }
            }
            return  enableQueu;
        },
            
        dowloadDeleteProcessingQueu : function(appBookId){
            console.log("dowloadDeleteProcessingQueu",appBookId);
            for( var key in PARAMDATA.downloadQueue ){
                var queuValue = PARAMDATA.downloadQueue[key];
                if( queuValue.app_book_id == appBookId ){
                    console.log("-----dowloadDeleteProcessingQueu ok-----",appBookId);
                    PARAMDATA.downloadQueue.splice(key, 1);
                    break;
                }
            }
        },

        queuProcessing : function(){
            if(PARAMDATA.processInterVal != null) return ;
            PARAMDATA.processInterVal = setInterval(that.processingQueuThread, PARAMDATA.processTimer);
        },  

        processingQueuThread : function(){
            if( that.isProcessing == true ) return ;
            
            var checkProcessingData = false;
            var queuProcessingObj = {};

            for (var appkey in PARAMDATA.downloadQueue) {
                if( PARAMDATA.downloadQueue[appkey].procQueuStatus == 'W' ){
                    checkProcessingData = true;
                    queuProcessingObj = PARAMDATA.downloadQueue[appkey];
                    break;
                }
            }
            
            if( checkProcessingData == false ){
                clearInterval(PARAMDATA.processInterVal);
                PARAMDATA.processInterVal = null;
            }else{
                that.isProcessing = true;
                console.log("processingQueuThread", queuProcessingObj);
                switch(queuProcessingObj.procWaitBusy){
                    case 1 :
                        h5applib.startBookDownload(queuProcessingObj);
                        break;

                    case 80 :
                        PARAMLIBRARY.bshelf_data[queuProcessingObj.app_book_id].eventType = 'bookDeleteStatus';
                        h5applib.deleteBookData(queuProcessingObj.app_book_id);
                        
                        break;
                    default :
                        queuProcessingObj.eventType = "bookDownloadingStatus";
                        h5applib.serverToApplicationZipDownlaod( queuProcessingObj );
                        break;
                }
            }
        },
        /*************************************************************************************
            END : processing queu  
        **************************************************************************************/
        
        getBookInfo : function(bookid){
            var returnObj;

            for(var t in this.totalBookData.books){
                if( this.totalBookData.books[t].bookid == bookid ){
                    return this.totalBookData.books[t];
                    break;
                }
            }

            return null;
        },
        
        getThumbImageInfo : function(bookid){           
            for(var t in this.thumbImageInfo){
                if( this.thumbImageInfo[t].id == bookid ){
                    return this.thumbImageInfo[t];
                    break;
                }
            }

            return null;
        },
        
        _getServerToBookInfo : function(infoObj, callback){
            if( typeof infoObj.bookid == 'undefined' ) {
                h5applib.appAlert('ERROR', 'BOOK ERROR',
                    function(){
                        $webApiRouter.closeViewerToLibrary();
                    }
                );
                //h5applib.nalert('ERROR', 'WISEBOOK');
                //that._loadingImgView('none');
                //if( callback ) callback('error');
                return false;
            }
            var bookinfoUrl = PARAMDATA.manifest.bookinfo+infoObj.author+"/"+infoObj.bookid+"/?os_tp="+PARAMDATA.ostp;
                        
            $.ajax({
                url         : bookinfoUrl,
                type        : 'GET',        
                dataType    : 'json',
                data        : {dataType : 'json'},
                async       : false,
                cache       : false,
                success     : function(jsonData){
                    if( callback ) callback('ok', jsonData);
                },
                
                error       : function(a,b,c){
                    h5applib.nalert('NO BOOK DATA FAILED', 'WISEBOOK');
                    that._loadingImgView('none');
                    if( callback ) callback('error');
                    return false;
                    
                }
            });
        },

        _detailBookInfoAdd : function(obj){
            var $detail = $('.book-contents-body'),
                $detail_book_title = $detail.find('.popup_title'),
                $detail_book_thumb = $detail.find('.book-thumb'),
                $detail_book_catchcopy = $detail.find('.contents-book-subtitle'),
                $detail_book_category = $detail.find('.contents-book-category'),
                $detail_book_contents = $detail.find('.contents-book-detail-scroll'),
                $detail_book_openday = $detail.find('#info-book-day'),
                $detail_book_total_page = $detail.find('#info-total-page'),
                $detail_book_size = $detail.find('#info-book-size'),
                $detail_book_down_type = $detail.find('#info-book-down-type'),
                $detail_book_read_icon = $detail.find('#icon-detail-popup');
                
            $detail.find('.btn_download').attr({'bookid': obj.bookid, 'data-author' : obj.author});
            
            var tempAppBookid = this.getPlanAppBookid(obj),
                dwStatus = false,
                downloadObj =  this.checkDownloadData(tempAppBookid);
            
            if(downloadObj && downloadObj.status == 100) dwStatus = true;
            
            if( appFlag == true ){
                if( dwStatus ) {
                    if( isMobilePhone == false ) $detail_book_read_icon.removeClass('btn_down btn-align-d btn_i_download').addClass('btn_all_read btn-align-detail btn_read');
                    else $detail_book_read_icon.removeClass('btn_down btn-align-d btn_i_download').addClass('btn_phone btn-phone-detail btn_read');
                }else{
                    if( isMobilePhone == false ) $detail_book_read_icon.removeClass('btn_all_read btn-align-detail btn_read').addClass('btn_down btn-align-d btn_i_download');
                    else $detail_book_read_icon.removeClass('btn_phone btn-phone-detail btn_read').addClass('btn_down btn-align-d btn_i_download');
                }
            }else{
                if( isMobilePhone == false ) $detail_book_read_icon.removeClass('btn_down btn-align-d btn_i_download').addClass('btn_all_read btn-align-detail btn_read');
                else $detail_book_read_icon.removeClass('btn_down btn-align-d btn_i_download').addClass('btn_phone btn-phone-detail btn_read');
            }
            
            var opendayStr =  obj.bookinfo[0].info.split('-'),
                opendayStr = opendayStr[0] + PARAMDATA.lang.oneword.year + opendayStr[1] + PARAMDATA.lang.oneword.month + opendayStr[2] + PARAMDATA.lang.oneword.day;
            
            $detail_book_title.html(obj.title);
            $detail_book_catchcopy.html(obj.catchcopy);
            $detail_book_category.html(PARAMDATA.portalFlag ? obj.portal_category : obj.category);
            $detail_book_contents.html(obj.html);
            $detail_book_openday.text(opendayStr);
            $detail_book_total_page.text(obj.bookinfo[1].info);
            $detail_book_size.text(obj.bookinfo[2].info);
            
            var tmpDownloadType = obj.bookinfo[3].info;
            if( appFlag == false ) tmpDownloadType = PARAMDATA.lang.oneword.disttype_stream;
            $detail_book_down_type.text(tmpDownloadType);
            
            //var thumbInfo =  this.getThumbImageInfo(obj.bookid);
            
            var ratiosizes = imageFitCommonRetWidthHeight($detail_book_thumb.outerWidth(), $detail_book_thumb.outerHeight(), obj.image_w, obj.image_h);
            
            var thumbStyle = 'background:url('+obj.image+');background-size:cover;width:'+ratiosizes.width+'px;height:'+ratiosizes.height+'px;position:relative;';
            
            var dwStatusElem = '';
            if( appFlag ){
                if( dwStatus == false ){
                    dwStatusElem = '<div class="top-download-status"></div>';
                    if(obj.disttype == "1")  dwStatusElem = '<div class="top-download-status top-stream-html5-status"></div>';
                }
            }else{
                dwStatusElem = '<div class="top-download-status top-stream-html5-status"></div>';
            }
            
            $detail_book_thumb.html('<div style='+thumbStyle+'>'+dwStatusElem+'</div>');
            
            this.isPopupDetil = true;
        },

        fastClicksInit : function(){
            if( !utils.hasTouch ) return false;
        
            var touchStartX, touchStartY, touchStartTime, targetElement, trackClick, activeSelection, scrollParent, lastClickTime, isMoved;
            function targetNeedsFocus(el) {
                var tag = el.nodeName.toLowerCase();
                var skipInputs = ('button checkbox file image radio submit').split(' ');
                if (el.disabled || el.readOnly) return false;
                if (tag === 'textarea') return true;
                if (tag === 'select') {
                    if (androidDeviceCheck) return false;
                    else return true;
                }
                if (tag === 'input' && skipInputs.indexOf(el.type) < 0) return true;
            }
            function targetNeedsPrevent(el) {
                el = $(el);
                if (el.is('label') || el.parents('label').length > 0) {
                    if (androidDeviceCheck) {
                        //var osv = app.device.osVersion.split('.');
                        var osv = androidInfo.androidver;
                        
                        if (osv * 1 > 4 || (osv * 1 === 4 && osv * 1 >= 4)) {
                            return false;
                        }
                        else return true;
                    }
                    else return false;
                }
                return true;
            }
            function handleTouchStart(e) {
                
                isMoved = false;
                if (e.targetTouches.length > 1) {
                    return true;
                }
                if (iosDeviceCheck) {
                    var selection = window.getSelection();
                    if (selection.rangeCount && !selection.isCollapsed) {
                        activeSelection = true;
                        return true;
                    }
                    else {
                        activeSelection = false;
                    }
                }
                trackClick = true;
                targetElement = e.target;
                touchStartTime = (new Date()).getTime();
                touchStartX = e.targetTouches[0].pageX;
                touchStartY = e.targetTouches[0].pageY;
        
                // Detect scroll parent
                if (iosDeviceCheck) {
                    scrollParent = undefined;
                    $(targetElement).parents().each(function () {
                        var parent = this;
                        if (parent.scrollHeight > parent.offsetHeight && !scrollParent) {
                            scrollParent = parent;
                            scrollParent.f7ScrollTop = scrollParent.scrollTop;
                        }
                    });
                }
                if ((e.timeStamp - lastClickTime) < 100) {
                    e.preventDefault();
                }
            }
            function handleTouchMove(e) {
                if (!trackClick) return;
                trackClick = false;
                targetElement = null;
                isMoved = true;
            }
            function handleTouchEnd(e) {
                if (!trackClick) {
                    if (!activeSelection) e.preventDefault();
                    return true;
                }
                //psy
                if( androidInfo.androidver <= 4.3 && androidDeviceCheck && appFlag == true ){   
                    e.preventDefault();
                    if( targetElement.className.match('checkbox') ) return true;
                }
                
                if (!activeSelection) {
                    e.preventDefault();
                }
        
                if ((e.timeStamp - lastClickTime) < 100) {
                    return true;
                }
        
                lastClickTime = e.timeStamp;
                touchStartTime = 0;
        
                trackClick = false;
        
                if (iosDeviceCheck && scrollParent) {
                    if (scrollParent.scrollTop !== scrollParent.f7ScrollTop) {
                        return false;
                    }
                }
        
                // Trigger focus when required
                if (targetNeedsFocus(targetElement)) targetElement.focus();
                
                e.preventDefault();
                var touch = e.changedTouches[0];
                var evt = document.createEvent('MouseEvents');
                var eventType = 'click';
                if (androidDeviceCheck && targetElement.nodeName.toLowerCase() === 'select') {
                    eventType = 'mousedown';
                }
                evt.initMouseEvent(eventType, true, true, window, 1, touch.screenX, touch.screenY, touch.clientX, touch.clientY, false, false, false, false, 0, null);
                evt.forwardedTouchEvent = true;
                targetElement.dispatchEvent(evt);
        
                return false;
        
                
            }
            function handleTouchCancel(e) {
                trackClick = false;
                targetElement = null;
            }
        
            function onMouse(e) {
                if (!targetElement) {
                    return true;
                }
                if (e.forwardedTouchEvent) {
                    return true;
                }
                if (!e.cancelable) {
                    return true;
                }
                e.stopImmediatePropagation();
                e.stopPropagation();
                e.preventDefault();
        
                return false;
        
            }
            function handleClick(e) {
                var allowClick = false;
        
                if (trackClick) {
                    targetElement = null;
                    trackClick = false;
                    return true;
                }
                
                
                if (e.target.type === 'submit' && e.detail === 0) {
                    return true;
                }
        
                if (!targetElement) {
                    allowClick =  true;
                }
                if (e.forwardedTouchEvent) {
                    allowClick =  true;
                }
                if (!e.cancelable) {
                    allowClick =  true;
                }
        
                if (!allowClick) {
                    e.stopImmediatePropagation();
                    e.stopPropagation();
                    if (targetElement) {
                        if (targetNeedsPrevent(targetElement) || isMoved) e.preventDefault();
                    }
                    else {
                        e.preventDefault();
                    }
                    targetElement = null;
                }
        
                return allowClick;
            }
        
        
            document.addEventListener('click', handleClick, true);
            document.addEventListener('touchstart', handleTouchStart);
            document.addEventListener('touchmove', handleTouchMove);
            document.addEventListener('touchend', handleTouchEnd);
            document.addEventListener('touchcancel', handleTouchCancel);
        },
        
        setInitTabSetting : function(){
                        
            for( var d in PARAMDATA.customInfo.settingmenu ){
                var tmpObj = PARAMDATA.customInfo.settingmenu[d],
                    $uiViewName = $('.ui-view-'+tmpObj.key),
                    $toolsTabName = $('#'+tmpObj.id),
                    dataFilter = parseInt(d)+1,
                    datatabs = 'tab-'+dataFilter;
                
                
                $toolsTabName.find('.tabbar-label').text( eval( tmpObj.title ) );
                if( tmpObj.key == 'login' ) $('.login-link').find('.tabbar-label').text( eval( tmpObj.title ) );
                
                
                if( tmpObj.id == "" ) return true;
                tmpObj.dataFilter = dataFilter;
                
                
                $toolsTabName.attr( { 'data-filter' : dataFilter, 'data-tab' : '#'+datatabs, 'data-key' : tmpObj.key } );
                
                
                $uiViewName.attr('id', datatabs);
                
                if( tmpObj.selected == 1 ) { 
                    
                    $toolsTabName.addClass('selected');
                    
                    if( cloudFlag == false ) $uiViewName.addClass('selected');  
                    this.tabsSelect = dataFilter;
                }
            }
        },
                
        hideNavbar : function(navbarContainer){
            $(navbarContainer).addClass('navbar-hidden');
            return true;
        },
        
        showNavbar : function(navbarContainer){
            var navbar = $(navbarContainer);
            navbar.addClass('navbar-hiding').removeClass('navbar-hidden').transitionEnd(function () {
                navbar.removeClass('navbar-hiding');
            });
            return true;
        },
        
        hideToolbar : function(toolbarContainer){
            $(toolbarContainer).addClass('toolbar-hidden');
            return true;
        },
        
        showToolbar : function(toolbarContainer){
            var toolbar = $(toolbarContainer);
            toolbar.addClass('toolbar-hiding').removeClass('toolbar-hidden').transitionEnd(function () {
                toolbar.removeClass('toolbar-hiding');
            });
        },
        
        _loadingImgView : function(viewType){
            if(viewType == 'show'){
                $loadingElem.style.display = 'block';
                this.dataloading = true;
                
            }else{
                $loadingElem.style.display = 'none';
                this.dataloading = false;
            }
        },
        
        getDateString : function(dateVal){
            var n = new Date(),
                n_y = n.getFullYear(),
                n_m = n.getMonth(),
                n_d = n.getDate();
            
            var s = new Date(dateVal),
                s_y = s.getFullYear(),
                s_m = s.getMonth(),
                s_d = s.getDate();
            
            var tmpDateYear = PARAMDATA.lang.changeText.dateYear.replace("{{%Y}}", s_y);
            
            var month = s.getMonth() + 1,
                day  = s.getDate(),
                hour = ( s.getHours()   < 10 ) ? '0' + s.getHours() : s.getHours(),
                min  = ( s.getMinutes() < 10 ) ? '0' + s.getMinutes() : s.getMinutes();
            
            var tmpDateDay = PARAMDATA.lang.changeText.dateDay.replace("{{%m}}", month),
                tmpDateDay = tmpDateDay.replace("{{%d}}", day);
                
            var tmpDateTime = PARAMDATA.lang.changeText.dateTime.replace("{{%h}}", hour),
                tmpDateTime = tmpDateTime.replace("{{%i}}", min);
            
            if( n_y == s_y ) {
                if( n_m == s_m && n_d == s_d ) return tmpDateTime;
                else return tmpDateDay+' '+tmpDateTime;
            }else {
                return tmpDateYear+tmpDateDay+' '+tmpDateTime;
            }
        },
        
        mb_strimwidth : function(str,start,width,trimmarker){
            if(typeof trimmarker === 'undefined') trimmarker='';
            var trimmakerWidth = this.mb_strwidth(trimmarker),i=start,l=str.length,trimmedLength=0,trimmedStr='';
            
            for(;i<l;i++){
                var charCode=str.charCodeAt(i), c=str.charAt(i), charWidth=this.mb_strwidth(c), next=str.charAt(i+1), nextWidth=this.mb_strwidth(next);
                trimmedLength += charWidth;
                trimmedStr += c;
                if(trimmedLength+trimmakerWidth+nextWidth>width){
                    trimmedStr += trimmarker;
                    break;
                }
            }
            return trimmedStr;
        },
        
        mb_strwidth : function(str){
            var i=0,l=str.length,c='',length=0;
            for(;i<l;i++){
                c=str.charCodeAt(i);
                if(0x0000<=c&&c<=0x0019){
                    length += 0;
                }else if(0x0020<=c&&c<=0x1FFF){
                    length += 1;
                }else if(0x2000<=c&&c<=0xFF60){
                    length += 2;
                }else if(0xFF61<=c&&c<=0xFF9F){
                    length += 1;
                }else if(0xFFA0<=c){
                    length += 2;
                }
            }
            return length;
        },

        /* ===============================================================================
            ************   bookshelf to viewer open   ************
        =============================================================================== */
        viewerOpenAnimation : function(){
            console.log('libraryToViewerAnimation');
            
            this.animatePageOnlyMaterial(this.htmlLibraryElem, this.htmlViewerElem, 'to-left');
            
            this.isHtmlView = true;
            this._loadingImgView('none');

            this.htmlLibraryElem.animationEnd(function (e) {
                that.htmlLibraryElem.removeClass('page-material-from-center-to-left').addClass('disable page-material-on-left');
                that.htmlViewerElem.removeClass('page-material-from-right-to-center disable');
            });
        },

        viewerCloseAnimation : function(){
            this._loadingImgView('hide');
            PARAMLIBRARY.createViewSeachInfo = null;
            PARAMLIBRARY.createViewInfo = null;
            PARAMLIBRARY.isAppBookshelfFlag = false;
            that.isHtmlView = false;
            this.animatePageOnlyMaterial(this.htmlLibraryElem, this.htmlViewerElem, 'to-right');
            $webApiRouter.closeViewerToBookshelf();
            
            delete h5appview;

            this.htmlLibraryElem.animationEnd(function (e) {
                that.htmlLibraryElem.removeClass('page-material-from-left-to-center');
                that.htmlViewerElem.removeClass('page-material-from-center-to-right').addClass('disable');
                //if(++that.viewCloseCount == that.viewRefreshCount) $webApiRouter.reloadBookShelf();
            });
        },

        animatePageOnlyMaterial : function(leftPage, rightPage, direction){
            var removeClasses = 'page-material-on-right page-material-on-left disable';
            if (direction === 'to-left') {
                leftPage.removeClass(removeClasses).addClass('page-material-from-center-to-left');
                rightPage.removeClass(removeClasses).addClass('page-material-from-right-to-center');
            }
            // Go back
            if (direction === 'to-right') {
                leftPage.removeClass(removeClasses).addClass('page-material-from-left-to-center');
                rightPage.removeClass(removeClasses).addClass('page-material-from-center-to-right');
                
            }
        },
        /* ===============================================================================
            ************   bookshelf to viewer open end  ************
        =============================================================================== */   
        
        /* ===============================================================================
            ************   server to viewer open   ************
        =============================================================================== */
        libraryToViewer : function() {
            this.isHtmlView = true;
            that.isActive = false;
            console.log("libraryToViewer");
            $webApiRouter.openedViewer();
            if(that.isModal) that.closeModal();
        },

        viewerToLibrary : function(param){
            $webApiRouter.closeViewerToLibrary(param);
            this.htmlViewerElem.addClass('disable').html('');
            this.htmlLibraryElem.removeClass('disable');
            PARAMLIBRARY.createViewSeachInfo = null;
            PARAMLIBRARY.createViewInfo = null;
            this.isHtmlView = false;
            this.isActive = false;
        },
        /* ===============================================================================
            ************   server to viewer open end  ************
        =============================================================================== */


        object_sort : function( data, key, order, parse ){
            var sortArr = [], o = {},
                num_a = -1,
                num_b = 1;
                
            for (k in data) sortArr.push( data[k] );
            
            if(order === 'asc'){
                num_a = 1;
                num_b = -1;
            }
            
            data = sortArr.sort(function(a, b){
                var x = ( parse == true) ? parseInt(a[key]) : a[key];
                var y = ( parse == true) ? parseInt(b[key]) : b[key];
                if (x > y) return num_a;
                if (x < y) return num_b;
                return 0;
            });
            
            for(i=0;i<data.length;i++) {
                o[data[i].app_book_id] = data[i];
            }
            
            return o;
        }
    };
    
    /* ===============================================================================
        ************   APPCALLBACK EVENT 関連   ************
    =============================================================================== */
    appCallBackEvent = {
        appAddTrigger : function(){
            $(document).bind('bookDownloadingStatus', this.downloadTrigger  );
            $(document).bind('bookDeleteStatus', this.deleteTrigger );
            $(document).bind('cancelBookdownload', this.cancelTrigger )
        },
        
        downloadTrigger : function(ev, dnInfo){
            PARAMDATA.processAppid = dnInfo.app_book_id;
            
            switch(dnInfo.status){
                case 1 :        
                    if(that.isModal) that.closeModal();
                    
                    //stream場合は待機
                    if( dnInfo.objcontents.sel_disttype != "stream" ) that._loadingImgView('none');
                    
                    if( dnInfo.selected != 'update' && dnInfo.objcontents.sel_disttype != "stream" ){
                        libBookShelf.refresh();
                    }
                                        
                    if (appFlag == false) setTimeout(function(){ that.zipDownload(dnInfo) }, 2000);  //test
                    
                    break;
                case 2:
                case 3:
                    
                    libBookShelf.bookDivisionStausView(dnInfo);
                    
                    break;
                
                case 100:
                    if( dnInfo.selected == 'update' ){
                        if( typeof(libUpdate) != "undefined" && typeof(libUpdate.destroy) == 'function' ) libUpdate.destroy(dnInfo);
                    }
                    
                    if( PARAMDATA.portalFlag == false ){
                        if( typeof(topSkin) != "undefined" && typeof(topSkin.downloadRefresh) == 'function' ) topSkin.downloadRefresh(dnInfo);
                    }else{
                        if( typeof(topSkinPortal) != "undefined" && typeof(topSkinPortal.downloadRefresh) == 'function' ) topSkinPortal.downloadRefresh(dnInfo);
                    }
                                        
                    libBookShelf.bookDivisionStausView(dnInfo);
                    that.isProcessing = false;
                    
                    PARAMDATA.processAppid = null;
                    that.dowloadDeleteProcessingQueu(dnInfo.app_book_id);
                    that._loadingImgView('none');
                    
                    break;
                
                default:
                    break;
                
            }
        },
        
        deleteTrigger : function(ev, dnInfo){
            
            switch(dnInfo.status){
                case 80 :                       
                        libBookShelf.bookDivisionStausView(dnInfo);
                    break;
                case 85 :
                        //test用
                        if(appFlag == false){
                            that.deleteStatusChange(dnInfo);
                        }
                    break;
                
                case 89 :
                        libBookShelf.bookDivisionStausView(dnInfo);
                        that.isProcessing = false;

                        PARAMDATA.processAppid = null;
                        that.dowloadDeleteProcessingQueu(dnInfo.app_book_id);
                        if( typeof(libUpdate) != "undefined" && typeof(libUpdate.refresh) == 'function' ) libUpdate.refresh();
                    break;
            }
        },
        
        cancelTrigger : function(ev, dnInfo){
            console.log("cancelTrigger", dnInfo.status);
            switch(dnInfo.status){
                case 50 :
                        libBookShelf.bookDivisionStausView(dnInfo);
                    break;
                case 55 :
                        //test用
                        if(appFlag == false){
                            that.cancelStatusChange(dnInfo);
                        }
                    break;
                
                case 59 :
                        libBookShelf.bookDivisionStausView(dnInfo);
                        that.isProcessing = false;

                        PARAMDATA.processAppid = null;
                        that.dowloadDeleteProcessingQueu(dnInfo.app_book_id);
                    break;
            }
        }
    };
    
    /*===============================================================================
        ************  modal     ************
    ===============================================================================*/
    librarystore.prototype.modal = function( params ) {
        var modalTemplate = '<div class="modal {{noButtons}}">' 
                            +   '<div class="modal-inner">' 
                            +       '{{if title}}<div class="modal-title">{{title}}</div>{{/if title}}' 
                            +       '<div class="modal-text">{{text}}</div>' 
                            +       '{{afterText}}' 
                            +   '</div>' 
                            +   '<div class="modal-buttons">{{buttons}}</div>' 
                            +'</div>',
            
             _modalTemplateTempDiv = document.createElement('div');
        
        params = params || {};
         
        var buttonsHTML = '';
        if (params.buttons && params.buttons.length > 0) {
            for (var i = 0; i < params.buttons.length; i++) {
                buttonsHTML += '<span class="modal-button' + (params.buttons[i].bold ? ' modal-button-bold' : '') + '">' + params.buttons[i].text + '</span>';
            }
        }
        
        if (!params.title) {
            modalTemplate = modalTemplate.split('{{if title}}')[0] + modalTemplate.split('{{/if title}}')[1];
        }else {
            modalTemplate = modalTemplate.replace(/{{if\ title}}/g, '').replace(/{{\/if\ title}}/g, '');
        }
        var modalHTML = modalTemplate
                    .replace(/{{title}}/g, params.title || '')
                    .replace(/{{text}}/g, params.text || '')
                    .replace(/{{afterText}}/g, params.afterText || '')
                    .replace(/{{buttons}}/g, buttonsHTML)
                    .replace(/{{noButtons}}/g, !params.buttons || params.buttons.length === 0 ? 'modal-no-buttons' : '');
        
        _modalTemplateTempDiv.innerHTML = modalHTML;
        
        var modal = $(_modalTemplateTempDiv).children();
        
        $('body').append(modal[0]);
        
        modal.find('.modal-button').each(function (index, el) {
            $(el).hammer({tap_max_touchtime:200}).on('tap', function (e) {
                if (params.buttons[index].close !== false) {
                    if( $('.modal-no-remove').size() == 1 ) {
                        $('.modal-no-remove').removeClass('modal-no-remove');
                        modal.remove();
                    }else that.closeModal(modal);
                }
                if (params.buttons[index].onClick) params.buttons[index].onClick(modal, e);
                if (params.onClick) params.onClick(modal, index);
            });
        });
        
        var overlayClickRemoveCheck = false;
        if( $('.modal-overlay-visible').size() == 1 && !this.isHtmlView ) overlayClickRemoveCheck = true;
        
        
        this.openModal(modal, overlayClickRemoveCheck);
    } 
    
     /* ===============================================================================
        ************   Infinite Scroll   ************
    =============================================================================== */
    librarystore.prototype.initInfiniteScroll = function(pageContainer){
        function handleInfiniteScroll() {
            var inf = this;
            
            var scrollTop = inf.scrollTop;
            var scrollHeight = inf.scrollHeight;
            var height = inf.offsetHeight;
            var distance = inf.getAttribute('data-distance');
            if (!distance) distance = 50;
            
            if (typeof distance === 'string' && distance.indexOf('%') >= 0) {
                distance = parseInt(distance, 10) / 100 * height;
            }
            
            if (distance > height) distance = height;

            if (scrollTop + height >= scrollHeight - distance) {
                $(inf).trigger('infinite');
            }
        }
        
        function attachInfiniteScroll(infiniteContent){
            $(infiniteContent).on('scroll', handleInfiniteScroll);
        }
        
        function detachInfiniteScroll(infiniteContent){
            $(infiniteContent).off('scroll', handleInfiniteScroll);
        }
        
        pageContainer = $(pageContainer);
        var infiniteContent = pageContainer.find('.infinite-scroll');
        
        if( infiniteContent.length == 0 ) return false;
        
        attachInfiniteScroll(infiniteContent);
        
        function detachEvents() {
            detachInfiniteScroll(infiniteContent);
            pageContainer.off('pageBeforeRemove', detachEvents);
        }
        pageContainer.on('pageBeforeRemove', detachEvents);
    };
    
    
    /*===============================================================================
        ************   Hide/show Toolbar/Navbar on scroll   ************
    ===============================================================================*/
    librarystore.prototype.initScrollToolbars = function(pageContainer){
        var hideNavbarOnPageScroll = false,
            hideToolbarOnPageScroll = true,
            hideTabbarOnPageScroll = false,
            showBarsOnPageScrollEnd = true;
        
        pageContainer = $(pageContainer);
        var scrollContent = pageContainer.find('.page-content');
        if (scrollContent.length === 0) return;
        
        
        var hideNavbar = (this.hideNavbarOnPageScroll || scrollContent.hasClass('hide-navbar-on-scroll') || scrollContent.hasClass('hide-bars-on-scroll')) && !(scrollContent.hasClass('keep-navbar-on-scroll') || scrollContent.hasClass('keep-bars-on-scroll'));
        var hideToolbar = (this.hideToolbarOnPageScroll || scrollContent.hasClass('hide-toolbar-on-scroll') || scrollContent.hasClass('hide-bars-on-scroll')) && !(scrollContent.hasClass('keep-toolbar-on-scroll') || scrollContent.hasClass('keep-bars-on-scroll'));
        var hideTabbar = (this.hideTabbarOnPageScroll || scrollContent.hasClass('hide-tabbar-on-scroll')) && !(scrollContent.hasClass('keep-tabbar-on-scroll'));
        
        if (!(hideNavbar || hideToolbar || hideTabbar)) return;
        
        
        var viewContainer = scrollContent.parents('.' + that.view.viewClass);
        if (viewContainer.length === 0) return;
        
        var navbar = viewContainer.find('.navbar'), 
            toolbar =  ( viewContainer.find('.toolbar').length > 0 ) ? viewContainer.find('.toolbar') : $('.toolbar'), 
            tabbar;
        
        if (hideTabbar) {
            tabbar = viewContainer.find('.tabbar');
            if (tabbar.length === 0) tabbar = viewContainer.parents('.' + app.params.viewsClass).find('.tabbar');
        }
        
        var hasNavbar = navbar.length > 0,
        hasToolbar = toolbar.length > 0,
        hasTabbar = tabbar && tabbar.length > 0;
        
        var previousScroll, currentScroll;
            previousScroll = currentScroll = scrollContent[0].scrollTop;
        
        var scrollHeight, offsetHeight, reachEnd, action, navbarHidden, toolbarHidden, tabbarHidden;

        var toolbarHeight = (hasToolbar && hideToolbar) ? toolbar[0].offsetHeight : 0;
        var tabbarHeight = (hasTabbar && hideTabbar) ? tabbar[0].offsetHeight : 0;
        var bottomBarHeight = tabbarHeight || toolbarHeight;
        
        function handleScroll(e) {
            if (pageContainer.hasClass('page-on-left')) return;
            currentScroll = scrollContent[0].scrollTop;
            scrollHeight = scrollContent[0].scrollHeight;
            offsetHeight = scrollContent[0].offsetHeight;
            reachEnd = showBarsOnPageScrollEnd && (currentScroll + offsetHeight >= scrollHeight - bottomBarHeight);
            navbarHidden = navbar.hasClass('navbar-hidden');
            toolbarHidden = toolbar.hasClass('toolbar-hidden');
            tabbarHidden = tabbar && tabbar.hasClass('toolbar-hidden');
            
            if (previousScroll > currentScroll || reachEnd) {
                 action = 'show';
            }else{
                if (currentScroll > 44) {
                    action = 'hide';
                }else{
                     action = 'show';
                }
            }
            
            if (action === 'show') {
                if (hasNavbar && hideNavbar && navbarHidden) {
                    libStore.showNavbar(navbar);
                    pageContainer.removeClass('no-navbar-by-scroll'); 
                    navbarHidden = false;
                }
                if (hasToolbar && hideToolbar && toolbarHidden) {
                    libStore.showToolbar(toolbar);
                    pageContainer.removeClass('no-toolbar-by-scroll');
                    toolbarHidden = false;
                }
                if (hasTabbar && hideTabbar && tabbarHidden) {
                    libStore.showToolbar(tabbar);
                    pageContainer.removeClass('no-tabbar-by-scroll');
                    tabbarHidden = false;
                }
            }else{
                if (hasNavbar && hideNavbar && !navbarHidden) {
                    libStore.hideNavbar(navbar);
                    pageContainer.addClass('no-navbar-by-scroll'); 
                    navbarHidden = true;
                }
                if (hasToolbar && hideToolbar && !toolbarHidden) {
                    libStore.hideToolbar(toolbar);
                    pageContainer.addClass('no-toolbar-by-scroll'); 
                    toolbarHidden = true;
                }
                if (hasTabbar && hideTabbar && !tabbarHidden) {
                    libStore.hideToolbar(tabbar);
                    pageContainer.addClass('no-tabbar-by-scroll'); 
                    tabbarHidden = true;
                }
            }
            previousScroll = currentScroll;
        }
        scrollContent.on('scroll', handleScroll);
        scrollContent[0].f7ScrollToolbarsHandler = handleScroll;
        
        function destroyScrollToolbars( ){
            if (scrollContent.length === 0) return;
            var handler = scrollContent[0].f7ScrollToolbarsHandler;
            if (!handler) return;
            scrollContent.off('scroll', scrollContent[0].f7ScrollToolbarsHandler);
        }
        
        function detachEvents() {
            destroyScrollToolbars();
            pageContainer.off('destroyScrollToolbars', detachEvents);
        }
        
        pageContainer.on('destroyScrollToolbars', detachEvents);
    };
    
    /*===============================================================================
        ************  action message    ************
    ===============================================================================*/
    action = {
        _action : function(params){
            params = params || [];
            
            if (params.length > 0 && !$.isArray(params[0])) {
                params = [params];
            }
                    
            var actionsTemplate = this.modalActionsTemplate;
            var buttonsHTML = '';
            
            for (var i = 0; i < params.length; i++) {
                for (var j = 0; j < params[i].length; j++) {
                    if (j === 0) buttonsHTML += '<div class="actions-modal-group">';
                    var button = params[i][j];
                    var buttonClass = button.label ? 'actions-modal-label' : 'actions-modal-button';
                    if (button.bold) buttonClass += ' actions-modal-button-bold';
                    if (button.red) buttonClass += ' actions-modal-button-red';
                    buttonsHTML += '<span class="' + buttonClass + '">' + button.text + '</span>';
                    if (j === params[i].length - 1) buttonsHTML += '</div>';
                }
            }
            var modalHTML = actionsTemplate.replace(/{{buttons}}/g, buttonsHTML);
                    
            _tempElement.innerHTML = modalHTML;
            var modal = $(_tempElement).children();
                    
            $('body').append(modal[0]);
                    
            var groups = modal.find('.actions-modal-group');
            groups.each(function (index, el) {
                var groupIndex = index;
                $(el).children().each(function (index, el) {
                var buttonIndex = index;
                var buttonParams = params[groupIndex][buttonIndex];
                if ($(el).hasClass('actions-modal-button')) {
                    $(el).on('click', function (e) {
                        if (buttonParams.close !== false) that.closeModal(modal);
                        if (buttonParams.onClick) buttonParams.onClick(modal, e);
                    });
                }
                });
            });

            this.openModal(modal);
        },
        
        _centerAction : function(params, obj){
            params = params || [];
            
            if (params.length > 0 && !$.isArray(params[0])) {
                params = [params];
            }
            
            var centerActionsTemplate = this.modalCenterActionsTemplate;
            var centerActionHTML = '<div class="list-block"><ul>{{listButton}}</ul></div>'
            var buttonsHTML = '';
            
            //title
            if(obj){
                buttonsHTML += '<li class="title-contens-block">'
                            +   '<div class="info-contens">'
                            +       '<div class="info-title-wrap" ><span class="info-title">'+obj.title+'</span></div>'
                            +       '<span class="info-text">'+PARAMDATA.lang.message.download_select_type+'</span>'
                            +   '</div>'
                            +'</li>'
            }
            
            
            for (var i = 0; i < params.length; i++) {
                for (var j = 0; j < params[i].length; j++) {
                    if (j === 0) buttonsHTML += '<div class="actions-modal-group">';
                    var buttonParams = params[i][j];                    
                    var button = params[i][j];
                    var buttonClass = '';
                    if (button.bold) buttonClass += ' actions-modal-button-bold';
                    if (button.red) buttonClass = ' button-red';
                    
                    buttonsHTML += '<li><span class="list-button item-link'+buttonClass+'">'+button.text+'</span></li>';
                    if (j === params[i].length - 1) buttonsHTML += '</div>';
                }
            }

            var modalHTML = centerActionHTML.replace(/{{listButton}}/g, buttonsHTML);
            modalHTML = centerActionsTemplate.replace(/{{buttons}}/g, modalHTML);

            _tempElement.innerHTML = modalHTML;
            var modal = $(_tempElement).children();
            $('body').append(modal[0]);
        
            //delete modal
            modal.addClass('remove-on-close');

            modal.show('slow');
            function sizeCenterAction() {
                var modalHeight =  modal.height()/2;
                modal.css({marginTop:-modalHeight});
            }
            sizeCenterAction();

            var groups = modal.find('.actions-modal-group');
            groups.each(function (index, el) {
                var groupIndex = index;
                $(el).children('li').each(function (index, el) {
                    var buttonIndex = index;
                    var buttonParams = params[groupIndex][buttonIndex];
                    
                    $(el).hammer({tap_max_touchtime:200}).on('tap', function (e) {
                        if (buttonParams.close !== false) that.closeModal(modal);
                        if (buttonParams.onClick) buttonParams.onClick(modal, e);
                     });
                });
            });

            this.isOverLayHide = true;
            this.openModal(modal);
        },
        
        alert : function (text, title, callbackOk) {
            this.isOverLayHide = true;
        
            if (typeof title === 'function') {
                callbackOk = arguments[1];
                title = undefined;
            }
            return this.modal({
                text: text || '',
                title: typeof title === 'undefined' ? 'WISEBOOK' : title,
                buttons: [ {text: that.modalButtonOk, bold: true, onClick: callbackOk} ]
            });
        },
        
        confirm : function (text, title, callbackOk, callbackCancel) {
            this.isOverLayHide = true;
            
            if (typeof title === 'function') {
                callbackCancel = arguments[2];
                callbackOk = arguments[1];
                title = undefined;
            }
            
            return this.modal({
                text: text || '',
                title: typeof title === 'undefined' ? 'WISEBOOK' : title,
                buttons: [
                    {text: that.modalButtonCancel, onClick: callbackCancel},
                    {text: that.modalButtonOk, bold: true, onClick: callbackOk}
                ]
            });
        },
        
        _prompt : function(text, title, callbackOk, callbackCancel ){
            if (typeof title === 'function') {
                callbackCancel = arguments[2];
                callbackOk = arguments[1];
                title = undefined;
            }
            
            return this.modal({
                text: text || '',
                title: typeof title === 'undefined' ? 'WISEBOOK' : title,
                afterText: '<input type="text" class="modal-text-input">',
                buttons: [
                    {
                        text: that.modalButtonCancel
                    },
                    {
                        text: 'OK',
                        bold: true
                    }
                ],
                onClick: function (modal, index) {
                    if (index === 0 && callbackCancel) callbackCancel($(modal).find('.modal-text-input').val());
                    if (index === 1 && callbackOk) callbackOk($(modal).find('.modal-text-input').val());
                }
            });
            
        }
    };
    
    /*===============================================================================
        ************   notification ************
    ===============================================================================*/
    notification ={
        notificationCloseOnClick: false,
        notificationCloseIcon: true,
        
    
        _addNotification : function(params){
            if (!params) return;
            
            
            
            if (typeof params.closeIcon === 'undefined') params.closeIcon = this.notificationCloseIcon;
            if (typeof params.closeOnClick === 'undefined') params.closeOnClick = this.notificationCloseOnClick;
            
            var container = $('.notifications');
            if (container.length === 0) {
                $('body').append('<div class="notifications list-block media-list"><ul></ul></div>');
                container = $('.notifications');
            }
            
            var list = container.children('ul');
            
            var itemHTML;
            if (params.custom) {
                itemHTML = '<li>' + params.custom + '</li>';
            }
            
            itemHTML = '<li class="notification-item notification-hidden"><div class="item-content">' 
                    +   (params.media ?
                            '<div class="item-media">' 
                    +       params.media 
                    +'      </div>' : '') 
                    +       '<div class="item-inner">' 
                    +           '<div class="item-title-row">' 
                    +       (params.title ?     '<div class="item-title">' + params.title + '</div>' : '') 
                    +       (params.closeIcon ? '<div class="item-after"><a href="#" class="close-notification"><span></span></a></div>' : '') 
                    +       '</div>' 
                    +       (params.subtitle ? '<div class="item-subtitle">' + params.subtitle + '</div>' : '') 
                    +       (params.message ? '<div class="item-text">' + params.message + '</div>' : '') 
                    +       '</div>' 
                    +   '</div>'
                    +'</li>';
            
            _tempElement.innerHTML = itemHTML;
        
            var item = $(_tempElement).children();
        
            item.on('click', function (e) {
                if (params.onClick) params.onClick(e, item[0]);
                if (params.closeOnClick) that.closeNotification(item[0]);
                else if ($(e.target).is('.close-notification') || $(e.target).parents('.close-notification').length > 0) that.closeNotification(item[0]);
            });
            if (params.onClose) {
                item.data('storeNotificationOnClose', function () {
                    params.onClose(item[0]);
                });
            }
            if (params.additionalClass) {
                item.addClass(params.additionalClass);
            }
            if (params.hold) {
                setTimeout(function () {
                    if (item.length > 0) that.closeNotification(item[0]);
                }, params.hold);
            }
        
            list.prepend(item[0]);
            container.show();
            
            var itemHeight = item.height();
            item.css('marginTop', -itemHeight + 'px');
            item.transition(0);
        
            var clientLeft = item[0].clientLeft;
            item.transition('');
            item.css('marginTop', '0px');
        
            container.transform('translate3d(0, 0,0)');
            item.removeClass('notification-hidden');
        },
        
        closeNotification : function(item){
            item = $(item);
            if (item.length === 0) return;
            if (item.hasClass('notification-item-removing')) return;
            var container = $('.notifications');
        
            var itemHeight = item.height();
            item.css('height', itemHeight + 'px').transition(0);
            var clientLeft = item[0].clientLeft;
        
            item.css('height', '0px').transition('').addClass('notification-item-removing');
            if (item.data('storeNotificationOnClose')) item.data('storeNotificationOnClose')();
        
            if (container.find('.notification-item:not(.notification-item-removing)').length === 0) {
                container.transform('');
            }
        
            item.addClass('notification-hidden').transitionEnd(function () {
                item.remove();
                if (container.find('.notification-item').length === 0) {
                    container.hide();
                }
            });
        }
    };
    
    /*===============================================================================
        ************   Swipeout Actions ************
    ===============================================================================*/
    swipeout = {
        swipeoutOpenedEl    : null,
        absoluteSwipeout    : false,
    
        initSwipeout : function(){
            var that = this,
                isTouched, isMoved, isScrolling, 
                touchesStart = {}, touchStartTime, 
                touchesDiff, swipeOutEl, swipeOutContent, 
                swipeOutActions, swipeOutActionsWidth, 
                translate, opened;
            
            $(document).on(utils.START_EV, function (e) {
                if (that.swipeoutOpenedEl) {
                    
                    var target = $(e.target);

                    if (!(
                        that.swipeoutOpenedEl.is(target[0]) ||
                        target.parents('.swipeout').is(that.swipeoutOpenedEl) ||
                        target.hasClass('modal-in') ||
                        target.hasClass('modal-overlay')
                        )) 
                    {
                        that.swipeoutClose(that.swipeoutOpenedEl);
                    }
                }
            });
            
            function handleTouchStart(e){
                if(that.absoluteSwipeout) return;
            
                if (!libStore.allowSwipeout) return;
                isMoved = false;
                isTouched = true;
                isScrolling = undefined;
                touchesStart.x = e.type === 'touchstart' ? e.originalEvent.targetTouches[0].pageX : e.pageX;
                touchesStart.y = e.type === 'touchstart' ? e.originalEvent.targetTouches[0].pageY : e.pageY;
                touchStartTime = (new Date()).getTime();
            }
            
            function handleTouchMove(e){
                if (!isTouched) return;
                var pageX = e.type === 'touchmove' ? e.originalEvent.targetTouches[0].pageX : e.pageX;
                var pageY = e.type === 'touchmove' ? e.originalEvent.targetTouches[0].pageY : e.pageY;
                
              
                if (typeof isScrolling === 'undefined') {
                    isScrolling = !!(isScrolling || Math.abs(pageY - touchesStart.y) > Math.abs(pageX - touchesStart.x));
                }
               
                if (isScrolling) {
                    isTouched = false;
                    return;
                }
                
                if (!isMoved) {
                    if ($('.list-block.sortable-opened').length > 0) return;
                    swipeOutEl = $(this);
                    swipeOutContent = swipeOutEl.find('.swipeout-content');
                    swipeOutActions = swipeOutEl.find('.swipeout-actions-inner');
                    
                    swipeOutActions.css('visibility', 'visible');
                    
                    swipeOutActionsWidth = swipeOutActions.width();
                    opened = swipeOutEl.hasClass('swipeout-opened');
                    swipeOutEl.removeClass('transitioning');
                }
                isMoved = true;
        
                e.preventDefault();
               
                touchesDiff = pageX - touchesStart.x;
                translate = touchesDiff  - (opened ? swipeOutActionsWidth : 0);
        
                if (translate > 0) translate = 0;
                if (translate < -swipeOutActionsWidth) {
                    translate = -swipeOutActionsWidth - Math.pow(-translate - swipeOutActionsWidth, 0.8);
                }
        
                swipeOutContent.transform('translate3d(' + translate + 'px,0,0)');
            }
            
            function handleTouchEnd(e){
                
                 if (!isTouched || !isMoved) {
                    isTouched = false;
                    isMoved = false;
                    return;
                }
                isTouched = false;
                isMoved = false;
               
                var timeDiff = (new Date()).getTime() - touchStartTime;
                if (!(translate === 0 || translate === -swipeOutActionsWidth)) libStore.allowSwipeout = false;
                
                var action;
                if (opened) {
                    if (
                        timeDiff < 300 && translate > -(swipeOutActionsWidth - 10) ||
                        timeDiff >= 300 && translate > -swipeOutActionsWidth / 2
                    ) {
                        action = 'close';
                    }
                    else {
                        action = 'open';
                    }
                }
                else {
                    if (
                        timeDiff < 300 && translate < -10 ||
                        timeDiff >= 300 && translate < -swipeOutActionsWidth / 2
                    ) {
                        action = 'open';
                    }
                    else {
                        action = 'close';
                    }
                }
                
                if (action === 'open') {
                    that.swipeoutOpenedEl = swipeOutEl;
                    swipeOutEl.trigger('open');
                    swipeOutEl.addClass('swipeout-opened transitioning');
                    swipeOutContent.transform('translate3d(' + -swipeOutActionsWidth + 'px,0,0)');
                }
                else {
                    swipeOutEl.trigger('close');
                    that.swipeoutOpenedEl = undefined;
                    swipeOutEl.addClass('transitioning').removeClass('swipeout-opened');
                    swipeOutContent.transform('translate3d(' + 0 + 'px,0,0)');
                    
                    swipeOutActions = swipeOutEl.find('.swipeout-actions-inner');
                    swipeOutActions.css('visibility', 'hidden');
                }
                
                if (translate <= -swipeOutActionsWidth) {
                    if (!opened) {
                        swipeOutEl.trigger('opened');
                    }
                    libStore.allowSwipeout = true;
                }
                else if (translate >= 0) {
                    if (opened) {
                        swipeOutEl.trigger('closed');
                    }
                    libStore.allowSwipeout = true;
                }
                else {
                    
                    swipeOutContent.transitionEnd(function () {
                        libStore.allowSwipeout = true;
                        swipeOutEl.trigger(action === 'open' ? 'opened' : 'closed');
                    });
                }
            }
            
            $(document).on(utils.START_EV, '.list-block li.swipeout', handleTouchStart);
            $(document).on(utils.MOVE_EV, '.list-block li.swipeout', handleTouchMove);
            $(document).on(utils.END_EV, '.list-block li.swipeout', handleTouchEnd);
        },
        
        swipeoutOpen : function(el){
            var that = this;
            el = $(el);
            if (!el.hasClass('swipeout')) return;
            if (el.length === 0) return;
            if (el.length > 1) el = $(el[0]);
            el.trigger('open').addClass('transitioning swipeout-opened');
            var swipeOutActions = el.find('.swipeout-actions-inner');
            swipeOutActions.css('visibility', 'visible');
            
            el.find('.swipeout-content').transform('translate3d(-' + swipeOutActions.width() + 'px,0,0)').transitionEnd(function () {
                el.trigger('opened');
                libStore.allowSwipeout = false;
            });
            
            that.swipeoutOpenedEl = el;
        },
        
        swipeoutClose : function(el, callback){
            var that = this;
            el = $(el);
            if (el.length === 0) return;
            libStore.allowSwipeout = false;
            el.trigger('close');
            
            swipeOutActions = el.find('.swipeout-actions-inner');
            swipeOutActions.css('visibility', 'hidden');
            
            el.removeClass('swipeout-opened')
                .addClass('transitioning')
                .find('.swipeout-content')
                .transform('translate3d(' + 0 + 'px,0,0)')
                .transitionEnd(function () {
                    el.trigger('closed');
                    libStore.allowSwipeout = true;
                    
                     if( typeof( callback ) != 'undefined' ) callback();
                });
           
            if (that.swipeoutOpenedEl[0] === el[0]) that.swipeoutOpenedEl = undefined;
        }
    };
    
    /*===============================================================================
        ************   Sortable ************
    ===============================================================================*/
    sortable = {
        sortableToggle : function(sortableContainer){
            sortableContainer = $(sortableContainer);
            if (sortableContainer.length === 0) sortableContainer = $('.list-block.sortable');
            sortableContainer.toggleClass('sortable-opened');
            if (sortableContainer.hasClass('sortable-opened')) {
                sortableContainer.trigger('open');
            }
            else {
                sortableContainer.trigger('close');
            }
            return sortableContainer;
        },
    
        initSortable : function(){
            var isTouched, isMoved, touchStartY, touchesDiff, sortingEl, sortingItems, minTop, maxTop, insertAfter, insertBefore, sortableContainer;
            
            function handleTouchStart(e) {
                if( libStore.allowSwipeout == false ) return false;
                
                isMoved = false;
                isTouched = true;
                touchStartY = e.type === 'touchstart' ? e.originalEvent.touches[0].pageY : e.pageY;
                sortingEl = $(this).parents('.sorte-li');
                sortingItems = sortingEl.parent().find('li.sorte-li');
                sortableContainer = sortingEl.parents('.sortable');
                e.preventDefault();
                libStore.allowsPanelOpen = false;
                
            }
            function handleTouchMove(e) {
                if (!isTouched || !sortingEl) return;
                var pageX = e.type === 'touchmove' ? e.originalEvent.touches[0].pageX : e.pageX;
                var pageY = e.type === 'touchmove' ? e.originalEvent.touches[0].pageY : e.pageY;
                
                if (!isMoved) {
                    sortingEl.addClass('sorting');
                    sortableContainer.addClass('sortable-sorting');
                    minTop = sortingEl[0].offsetTop;
                    maxTop = sortingEl.parent().height() - sortingEl[0].offsetTop - sortingEl.height();
                    
                }
                isMoved = true;
                
                e.preventDefault();
                touchesDiff = pageY - touchStartY;
                var translate = touchesDiff;
                if (translate < -minTop) translate = -minTop;
                if (translate > maxTop) translate = maxTop;
                sortingEl.transform('translate3d(0,' + translate + 'px,0)');
                insertBefore = insertAfter = undefined;
                
                sortingItems.each(function () {
                    var currentEl = $(this);
                    if (currentEl[0] === sortingEl[0]) return;
                    var currentElOffset = currentEl[0].offsetTop;
                    var currentElHeight = currentEl.height();
                    var sortingElOffset = sortingEl[0].offsetTop + translate;
        
                    if ((sortingElOffset >= currentElOffset - currentElHeight / 2) && sortingEl.index() < currentEl.index()) {
                        currentEl.transform('translate3d(0,-100%,0)');
                        insertAfter = currentEl;
                        insertBefore = undefined;
                    }
                    else if ((sortingElOffset <= currentElOffset + currentElHeight / 2) && sortingEl.index() > currentEl.index()) {
                        $(this).transform('translate3d(0,100%,0)');
                        insertAfter = undefined;
                        if (!insertBefore) insertBefore = currentEl;
                    }
                    else {
                        $(this).transform('translate3d(0, 0%,0)');
                    }
                });
            }
            function handleTouchEnd(e) {
                
                libStore.allowsPanelOpen = true;
                if (!isTouched || !isMoved) {
                    isTouched = false;
                    isMoved = false;
                    return;
                }
                e.preventDefault();
                sortingItems.transform('');
                sortingEl.removeClass('sorting');
                sortableContainer.removeClass('sortable-sorting');
                
                if (insertAfter) {
                    sortingEl.insertAfter(insertAfter);
                    sortingEl.trigger('sort');
                }
                if (insertBefore) {
                    sortingEl.insertBefore(insertBefore);
                    sortingEl.trigger('sort');
                }
                insertAfter = insertBefore = undefined;
                isTouched = false;
                isMoved = false;
            }
            
            $(document).on(utils.START_EV, '.list-block.sortable .sortable-handler', handleTouchStart);
            $(document).on(utils.MOVE_EV, '.list-block.sortable .sortable-handler', handleTouchMove);
            $(document).on(utils.END_EV, '.list-block.sortable .sortable-handler', handleTouchEnd);
          
        },
        
        sortableOpen : function(sortableContainer){
            sortableContainer = $(sortableContainer);
            if (sortableContainer.length === 0) sortableContainer = $('.list-block.sortable');
            sortableContainer.addClass('sortable-opened');
            sortableContainer.trigger('open');
            return sortableContainer;
        },
        
        sortableClose : function(sortableContainer){
            sortableContainer = $(sortableContainer);
            if (sortableContainer.length === 0) sortableContainer = $('.list-block.sortable');
            sortableContainer.removeClass('sortable-opened');
            sortableContainer.trigger('close');
            return sortableContainer;
        }
    };
    
    /*===============================================================================
        ************  drag & drop sort  ************
    ===============================================================================*/
    draganddropsortable = {
        dragElemParent  : null,
        currentItem     : null,
        helper          : null,
        margins         : null,
        offset          : null,
        placeholder     : null,
        position        : null,
        
        positionAbs : null,
        lastPositionAbs : null,
        direction   : null,
        
        dragDropSort : function( event, el ){
            if (el[0].draggable !== true) return false;
            //drag-and-drop-body
            this.dragElemParent = el.parent();
            this.dragElemParent.parents(".views, .page-content").addClass("drag-drop-sort");
            
            this.refreshItems();
            this.refreshPositions();
        
            this.currentItem = el;
            
            this.helper = this._createHelper();
            this._cacheHelperProportions();
            
            this.margins = {
                left: (parseInt(el.css("marginLeft"),10) || 0),
                top: (parseInt(el.css("marginTop"),10) || 0)
            };
                        
            this.offset = el.offset();
            this.offset = {
                top: this.offset.top - this.margins.top,
                left: this.offset.left - this.margins.left
            };
            
            $.extend(this.offset, {
                touch: {
                    left: event.originalEvent.touches[0].pageX - this.offset.left,
                    top: event.originalEvent.touches[0].pageY - this.offset.top
                },
                parent: this.dragElemParent.offset()
            }); 
            
            this.helper.css("position", "absolute");
            this.cssPosition = this.helper.css("position");     
                        
            this.domPosition = { prev: el.prev()[0], parent: el.parent()[0] };
                        
            this.createPlaceholder();
            $(this.currentItem).trigger("ready", this._uiHash());
                        
            this.helper.css({zIndex : "999999"}).addClass("drag-drop-helper");
            
            this.listen();
        },
        
        refreshItems : function(){
            this.items = [];
            var items = this.items;
            var queries = $( '> *',  this.dragElemParent);
            
            for( var i=0; i<queries.length; i++){               
                var item = $(queries[i]);
                
                items.push({
                    item: item,
                    width: 0, height: 0,
                    left: 0, top: 0
                });
            }
        },
        
        refreshPositions : function( fast ){
            for (var i = this.items.length - 1; i >= 0; i--){
                var item = this.items[i];
                
                var t = item.item;
                
                if (!fast) {
                    item.width = t.outerWidth();
                    item.height = t.outerHeight();
                }
                
                var p = t.offset();
                item.left = p.left;
                item.top = p.top;
            }
        },
        
        _createHelper : function(){
            var helper = this.currentItem;
            
            if(helper[0].style.width == '') helper.width(this.currentItem.width());
            if(helper[0].style.height == '') helper.height(this.currentItem.height());
            
            return helper;
        },
        
        _cacheHelperProportions : function(){
            this.helperProportions = {
                width: this.helper.outerWidth(),
                height: this.helper.outerHeight()
            };
        },
        
        _generatePosition : function(event){
            var pageX = event.changedTouches.pageX;
            var point = event.touches ? event.touches[0] : event;
            var pageX = point.pageX;
            var pageY = point.pageY;
            
            return {
                top : pageY - this.offset.touch.top,
                left : pageX - this.offset.touch.left
            }
        },
        
        _convertPositionTo : function(d, pos){
            if(!pos) pos = this.position;
            var mod = d == "absolute" ? 1 : -1;
            
            return {
                top : pos.top,
                left : pos.left
            }
        },
        
        createPlaceholder : function(){
            var placeholder = this.placeholder;
        
            function elementsPlaceholder( contain, currentItem ){
                var className = placeholder;
                
            
                var el = $(document.createElement(contain[0].nodeName))
                        .addClass( currentItem[0].className+" drag-drop-placeholder" );
                
                //if(!className)
                //  el.css("visibility", "hidden");
                
                return el;
            }
            
            this.placeholder = elementsPlaceholder( this.dragElemParent, this.currentItem );
            $(this.currentItem).after( this.placeholder ).css( { position : "absolute", left : this.offset.left, top : this.offset.top } );
        },
        
        listen : function(){
            var that = this;
            var move = this.onEvt(document, "touchmove", this.move, this);
            var end = this.onEvt(document, "touchend", ontouchend, this);
            var cancel = this.onEvt(document, "touchcancel", cleanup, this);
            $(window).on('resize', cleanup);
            
            function ontouchend(event) {
                this.dragend(event);
                cleanup.call(this);
            }
            
            function cleanup() {
                $(this.currentItem).trigger("dragResize", that.currentItem);
                $(window).off('resize', cleanup);
                that.dragElemParent.parents(".views, .page-content").removeClass("drag-drop-sort");
                that.dragElemParent = null;
                that.items = null;
                
                if( that.placeholder != null ) {
                    that.placeholder.remove();
                    that.placeholder = null;
                }
                
                that.offset = null;
                that.margins = null;
                that.positionAbs = null;
                that.lastPositionAbs = null;
                
                that.currentItem = null;
                that.cssPosition = null;
                
                return [move, end, cancel].forEach(function(handler) {
                    return handler.off();
                });
            }
        },
        
        move : function(event){
            event.preventDefault();
            
            this.position = this._generatePosition(event);
            this.positionAbs = this._convertPositionTo("absolute");
            if (!this.lastPositionAbs) {
                this.lastPositionAbs = this.positionAbs;
            }
            
            this.positionAbs = this._convertPositionTo("absolute");
            
            this.helper.css( {"left" : this.position.left+'px', "top" :  this.position.top+'px'} );
            
            for (var i = this.items.length - 1; i >= 0; i--) {
                var item = this.items[i], itemElement = item.item[0], intersection = this.intersectsWithPointer( item );
                if (!intersection) continue;
                
                if(itemElement != this.currentItem[0]
                    &&  this.placeholder[intersection == 1 ? "next" : "prev"]()[0] != itemElement
                    &&  !$.contains(this.placeholder[0], itemElement)
                ){
                    this.direction = intersection == 1 ? "down" : "up";
                    
                    if( this.intersectsWithSides(item) ){
                        this.rearrange(event, item);
                    }else{
                        break;
                    }
                    
                    $(this.currentItem).trigger('change', this._uiHash());
                    break;
                }
                
            }
            
            this.lastPositionAbs = this.positionAbs;
        },
        
        intersectsWithPointer : function( item ){
            
            var isOverElementHeight = this.isOverAxis(this.positionAbs.top + this.offset.touch.top, item.top, (item.height*1.2)),
                isOverElementWidth = this.isOverAxis(this.positionAbs.left + this.offset.touch.left, item.left, (item.width*1.2)),
                isOverElement = isOverElementHeight && isOverElementWidth,
                verticalDirection = this.getDragVerticalDirection(),
                horizontalDirection = this.getDragHorizontalDirection();
            
            if( !isOverElement ) return false;
                
            return( ((horizontalDirection && horizontalDirection == "right") || verticalDirection == "down") ? 2 : 1 );
        },
        
        intersectsWithSides : function( item ){
            var isOverBottomHalf = this.isOverAxis(this.positionAbs.top + this.offset.touch.top, item.top, item.height),
                isOverRightHalf = this.isOverAxis(this.positionAbs.left + this.offset.touch.left, item.left, item.width),
                verticalDirection = this.getDragVerticalDirection(),
                horizontalDirection = this.getDragHorizontalDirection();
            
            if (horizontalDirection) {
                return ((horizontalDirection == "right" && isOverRightHalf) || (horizontalDirection == "left" && !isOverRightHalf));
            } else {
                return verticalDirection && ((verticalDirection == "down" && isOverBottomHalf) || (verticalDirection == "up" && !isOverBottomHalf));
            }
        },      
        
        getDragVerticalDirection : function(){
            var delta = this.positionAbs.top - this.lastPositionAbs.top;
            return delta != 0 && (delta > 0 ? "down" : "up");
        },
        
        getDragHorizontalDirection : function(){
            var delta = this.positionAbs.left - this.lastPositionAbs.left;
            return delta != 0 && (delta > 0 ? "right" : "left");
        },
        
        dragend : function(event){
            if(!event) return;
            this.clear(event);
            $(this.currentItem).trigger("drop", this._uiHash());
        },
        
        clear : function(event){
            if( this.currentItem.parent().length) {
                this.placeholder.before(this.currentItem);
                this.currentItem.removeClass("drag-drop-helper").removeAttr("style");
                this.placeholder.remove();
                this.placeholder = null;
            }
        },
        
        rearrange : function( event, i, hardRefresh ){
            i.item[0].parentNode.insertBefore(this.placeholder[0], (this.direction == 'down' ? i.item[0] : i.item[0].nextSibling));
            
            this.counter = this.counter ? ++this.counter : 1;
            var self = this, counter = this.counter;
            
            window.setTimeout(function() {
                if(counter == self.counter) self.refreshPositions(!hardRefresh);
            },0);
        },
                
        elementFromTouchEvent : function(el, event){
             var touch = event.changedTouches[0];
             
             var target = document.elementFromPoint(
                touch[this.coordinateSystemForElementFromPoint + "X"],
                touch[this.coordinateSystemForElementFromPoint + "Y"]
            );
             
             return target;
        },
        
        onEvt : function(el, event, handler, context) {
            if(context) handler = handler.bind(context)
            el.addEventListener(event, handler);
            return {
                off: function() {
                    return el.removeEventListener(event, handler);
                }
            };
        },
                
        isOverAxis : function( x, reference, size ) {
            return ( x >= reference ) && ( x < ( reference + size ) );
        },
        
        _uiHash: function() {
            return {
                helper: this.helper,
                placeholder: this.placeholder || $([]),
                position: this.position,
                offset: this.positionAbs,
                item: this.currentItem
            };
        }
    };
})(window);
