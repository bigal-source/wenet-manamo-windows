(function(){
    webApiRouter = function(){
    }
    
    webApiRouter.prototype = {
        callbackKey : 0,
        callbacks : {},
        interFaceBookshelf : function(exeFuncResult, callBackString, menuIndex) {
            if(callBackString != "") {
                try {
                    if(window._AppMenu_) {
                        window._AppMenu_.interfaceCallResult(callBackString, exeFuncResult, menuIndex);
                    }
                    else {
                        console.log('not exists');
                    }
                } catch (e) {
                    console.log(e);
                }

            }
        },
        isBook : function(param) {
            console.log("app is book");
            var tmpappbookid = libStore.getPlanAppBookid(param);
            var obj = libStore.checkDownloadData(tmpappbookid);
            var isbook = ( obj ) ? true : false;

            var returndata = JSON.stringify({isbook : isbook, bookdata : param});
            return returndata;
        },

        download : function(param) {
            console.log(param);
//          var json = JSON.parse(param);
            // window._AppMenu_.changeMenuBookshelf();
            
            libStore.bookDownloadSetting(param);

            return param;
        },
        openBookStream : function(param) {
//          var json = JSON.parse(param);
            // $webApiRouter.openedViewer();
            libStore.bookOpenStream(param);
        },

        getBookshelfInfo : function() {
            var bookshelfInfo = "";
            if(window._AppMenu_) {
                bookshelfInfo = JSON.parse( window._AppMenu_.interfaceBookshelfInfo() );
                $(document).trigger(lib_defind.LIBRARY_BOOKSHELFINFO, bookshelfInfo);
            }
            else {
                _iOSBridge_.callHandler('interfaceBookshelfInfo', '', function(response) {
                    
                    $(document).trigger(lib_defind.LIBRARY_BOOKSHELFINFO, response);
                });
            }
        },

        changeMenuBookshelf : function() {
            if(window._AppMenu_) {
                window._AppMenu_.changeMenuBookshelf();
            }
            else {
                _iOSBridge_.callHandler('changeMenuBookshelf', '', function(response) {
                    
                });
            }
        },
        
        changeBookshelfInfo: function() {
            $webApiRouter.getBookshelfInfo();
        },

        openViewer:function() {
            if(window._AppMenu_) {
                window._AppMenu_.interfaceCommand('openViewer','');
            }
            else {
                // _iOSBridge_.callHandler('openViewer', '', null);
            }
        },
        openedViewer : function() {
            if(window._AppMenu_) {
                console.trace();
                window._AppMenu_.interfaceCommand('openedViewer','');
                // window._AppMenu_.openedViewer();
            }
            else {
                _iOSBridge_.callHandler('openedViewer', '', null);
            }
        },
        closeViewerToBookshelf : function() {
            if(window._AppMenu_) {
                window._AppMenu_.interfaceCommand('closeViewerToLibrary',{});
                // window._AppMenu_.interfaceCloseViewer();
            }
            else {
                _iOSBridge_.callHandler('closeViewerToBookshelf', '', null);
            }
        },
        closeViewerToLibrary : function(param) {
            if(!param){param={};};
            if(window._AppMenu_) {
                window._AppMenu_.interfaceCommand('closeViewerToLibrary',JSON.stringify(param));
                // window._AppMenu_.interfaceCloseViewer();
            }
            else {
                _iOSBridge_.callHandler('closeViewerToLibrary', '', null);
            }
        },
        interfaceJSAlertForViewer : function(alertObj, callback) {
            //Android
            if(window._AppMenu_) {
                var callbackKey = $webApiRouter.addCallback(callback);
                console.log('callbackKey',callbackKey);
                window._AppMenu_.interfaceJSAlertForViewer(alertObj.text, alertObj.buttonname,callbackKey);
                // if( typeof( callback ) == "function" ) callback();
            }
            else {
//                navigator.notification.alert(
//                    alertObj.text,
//                    function(){
//                        if( typeof( callback ) == "function" ) callback();
//                    },
//                    alertObj.title,
//                    alertObj.buttonname
//                );
            }
        },
        hideViewer : function() {
            if (h5appview) {
                h5appview.hideView();
            }
        },
        addCallback : function(callback) {
            if (typeof callback != 'function') return null;

            $webApiRouter.callbackKey++;
            var key = 'k'+$webApiRouter.callbackKey;
            $webApiRouter.callbacks[key] = callback;
            return key;
        },
        routerCallback : function (callbackKey,res) {
            $webApiRouter.callbacks[callbackKey]( JSON.parse(res) );
            $webApiRouter.removeCallback(callbackKey);
        },
        removeCallback : function (callbackKey) {
            delete $webApiRouter.callbacks[callbackKey];
        },
        setDeleteStatus : function (status) {
            if(window._AppMenu_) {
                window._AppMenu_.setDeleteStatus(status);
            }
            else {
                _iOSBridge_.callHandler('setDeleteStatus', status, null);
            }
        },
        shareForSNS: function(url,callback){
            if(window._AppMenu_) {
                window._AppMenu_.shareForSNS(url, '');
            }
            else {
                _iOSBridge_.callHandler('shareForSNS',{'url':url} , null);
            }

        },

        setBookListInfo : function (currentBookStatusList, callback) {
            if(window._AppMenu_) {
                window._AppMenu_.setBookListInfo(JSON.stringify(currentBookStatusList), ''); 
            }
            else {
                _iOSBridge_.callHandler('setBookListInfo', currentBookStatusList, null);
            }
        },
        updateBookFromWBWebViewController : function (bookID) {
            if(window._AppMenu_) {
                if (h5applib.getConnectStatus() == 'ok'){
                    $bsLib.setUpdateBshelfData(bookID);
                    libUpdate.setUpdateQueueThread();
                }else{
                    $bsLib.refresh();
                }
            }
            else {}
        },
        openViewerIsNotDownloading : function (param) {
            var isDownloading = PARAMDATA.downloadQueue.length > 0 ? true : false;
            window._AppMenu_.openViewerIsNotDownloading(isDownloading, param);
        },        
        reloadBookShelf : function() {
            location.reload();
            if(window._AppMenu_) {
                window._AppMenu_.showSpin();
            } else {
                _iOSBridge_.callHandler('showSpin', null, function(){});
            }
        },
		setUserInfoToBookshelf : function (data) {
           setUserInfo(JSON.parse(data));
       }        
    }
})();

$webApiRouter = new webApiRouter();
//$webApiRouter.getBookshelfInfo();
