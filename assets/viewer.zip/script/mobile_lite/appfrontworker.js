onmessage = function(event) {
	var loopTimer = null;
	var cancelFlage = false;
	
	var data = event.data;
	
	
	
	switch (data.cmd){
		case 'download':
		case 'update':
		 	dwonloadStart(data.returnData);
			break;
		
		case 'dnProgress':
			dwonloadProgressLoop(data.returnData);
			break;
		case 'deleteBook' :
			deleteBookStatusStep1(data.returnData);
			postMessage({param:'deleteBook', returnData:data.returnData});
			break;
		case 'downloadCancel':
			if(loopTimer != null) clearInterval(loopTimer);
			cancelBookStatusStep1(data.returnData);
			break;
	}
	
	function dwonloadStart(returnData){
	
		var nowDate = Math.round(new Date().getTime() / 1000);
		
		var setAppParam = {
			app_book_id 	: returnData.app_book_id,
			bookPath		: '',
			thumbPath		: returnData.thumbPath,
			thumb_w			: returnData.thumb_w,
			thumb_h			: returnData.thumb_h,
			selected    	: returnData.selected,
			status			: 1,
			down_date		: nowDate,
			objcontens		: returnData.objcontens,
			sortno			: returnData.sortno,
			eventType		: returnData.eventType
		};
				
		if( returnData.selected == 'update' ){
			setAppParam.procQueuStatus = 'W';
			setAppParam.procWaitBusy = returnData.procWaitBusy;
		}
		else {
			setAppParam.procQueuStatus = 'E';
			setAppParam.procWaitBusy = 0;
		}
		
		
		if( returnData.selected == 'download' ) setAppParam.cate_seq = 0;
		
		postMessage({param : 'download',  returnData : setAppParam});
	}
	
	function dwonloadProgressLoop(returnData){
		var endLoop = 0;
		loopTimer = setInterval(function(){
			if(endLoop >= 99) {
				clearInterval(loopTimer);
				loopTimer = null;
				returnData.status = 3
				
				postMessage({param : 'download',  returnData : returnData});
			}
			
			if(cancelFlage){
				clearInterval(loopTimer);
				cancelFlage = false;
			}
			
			//endLoop +=20;
			endLoop++;
			if( endLoop > 100 ) endLoop = 100;
			var extendTarget ={progress : endLoop};
			returnData = extend(returnData, extendTarget);

			postMessage({param : 'download',  returnData : returnData});
		}, 50);
		
		
	}
	
	function deleteBookStatusStep1(returnObj){
		returnObj.status = 80;
		postMessage({param:'deleteBook', returnData:returnObj});
		deleteBookStatusStep2(returnObj);
	}
	
	function deleteBookStatusStep2(returnObj){
		setTimeout(function(){
			returnObj.status = 85;
			postMessage({param:'deleteBook', returnData:returnObj});	
		},1000);
	}
	
	function cancelBookStatusStep1(returnObj){
		cancelFlage = true;
		returnObj.status = 50;
		postMessage({param:'downloadCancel', returnData:returnObj});
		cancelBookStatusStep2(returnObj);
	}
	
	function cancelBookStatusStep2(returnObj){
		setTimeout(function(){
			returnObj.status = 55;
			postMessage({param:'downloadCancel', returnData:returnObj});	
		},1000);
	}
	
	function extend(target, obj){
		for ( var i in obj ) {
			target[i] = obj[i];
		}
		
		return target;
	}
};
