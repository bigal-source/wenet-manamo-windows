(function(window){
    window.libupdate = function(options) {
        $libUpdate = this;
        this.updateEvent();
    }
//update btnを押したらQueueに入る
libupdate.prototype = {
    updateTest          : false,
    preload             : null,
    serverSendData      : [],
    
    updateQueueData     : [],
    updateQueueTime     : null,
    
    updateBookCount     : 0,
    updateGetListData   : [],
    updateServerCheckFlag   : false,
    
    checkUpdateTimer        : null,
    delayTime               : 1*60*60*1000, //1H
    
    updateEvent : function(){
        $(document).on(lib_defind.LIBRARY_USERINFOCHANGE, function(){
            $libUpdate.updateServerCheckFlag = false;
        });
    },

    /*************************************************************************************
        APP UPDATE PROCESS
    **************************************************************************************/ 
    setUpdateQueueThread : function(){
        if($libUpdate.updateQueueTime != null) return ;
        
        $libUpdate.updateQueueTime = setInterval($libUpdate.updateQueueProcessing, 500);
    },
    
    setUpdateObj : function(obj){       
        var updateRequest = {
            app_book_id : obj.appBookid,
            selected    : 'update',
            eventType   : "bookDownloadingStatus",
            status      : 20,
            progress    : 0,
            thumbPath   : obj.image_l,
            thumb_w     : obj.thumb_w,
            thumb_h     : obj.thumb_h,
            procQueuStatus  : 'W',
            procWaitBusy    : 30 
            
        }
        
        if( typeof(obj.catchcopy) != 'string' ) obj.catchcopy = '';
        if( typeof(obj.category) != 'string' ) obj.category = '';
        
        if( cloudFlag && PARAMDATA.portalFlag == false ){
            obj.clouduser = PARAMDATA.memInfo.userid
        }

        //if( cloudFlag == true ) obj.clouduser =  Base64.decode( PARAMLIBRARY.loginAutoInfo.user_id );
        
        updateRequest.objcontents = obj;
        
        $.extend(PARAMLIBRARY.bshelf_data[obj.appBookid], updateRequest);
        
        return PARAMLIBRARY.bshelf_data[obj.appBookid];
    },
    
    updateQueueProcessing : function(){     
        if( libStore.isProcessing == true ) return ;
        
        if($libUpdate.updateQueueData.length <= 0) {
            clearInterval($libUpdate.updateQueueTime);
            $libUpdate.updateQueueTime = null;
        }else{
            
            var downloadObj = libStore.checkDownloadData( $libUpdate.updateQueueData[0].appBookid );
            
            if(downloadObj == false){
                $libUpdate.destroy();
            }else{
                libStore.isProcessing = true;
                var queuObj =  $libUpdate.setUpdateObj( $libUpdate.updateQueueData[0] );
                
                if( typeof(libBookShelf) != "undefined" && typeof(libBookShelf.refresh) == 'function' ) libBookShelf.refresh();
                h5applib.startBookDownload(queuObj);
            }
        }
    },

    checkUpdateQueueData : function(appBookid){
        if( !appBookid ) return false;
        
        var queueInput = true;
        
        if($libUpdate.updateQueueData.length > 0) {
            for(var q in $libUpdate.updateQueueData){
                if($libUpdate.updateQueueData[q].appBookid == appBookid){
                    queueInput = false;
                    break;
                }
            }
        }
        
        return queueInput;
    },
    /*************************************************************************************
        APP UPDATE PROCESS END
    **************************************************************************************/     
    getUpdateListData : function(appid){
        var returnUpdateData = null;
        for( var up in this.updateGetListData ){
            var updateListData = this.updateGetListData[up];
            if( updateListData.appBookid == appid ){
                var returnUpdateData = updateListData;
                this.updateGetListData.splice(up, 1);
                
                return returnUpdateData;
                break; 
            }
        }
        
        return false;
    },
    
    setUpdateListData : function(value){
        if (typeof (value.catchcopy) != 'string') value.catchcopy = '';
        var bshelfObj = libStore.returnAppObject(value.bookid);
        value.appBookid = bshelfObj.app_book_id;
        value.image_l = value.image_l + '?' + new Date().getTime();
    
        $.extend(bshelfObj.objcontents, value);
        
        $libUpdate.updateGetListData.push(bshelfObj.objcontents);
    },
    
    getListUpdateData: function ( ) {
        console.log('getListUpdateData');
        console.trace();
        if(h5applib.getConnectStatus() != 'ok' && !PARAMLIBRARY.responseCheck ) {
            return false;
        }

        var data1 = new Array(); //appid
        var data2 = new Array(); //bookid
        var data3 = new Array(); //date

        $.each($libUpdate.serverSendData, function (key, value) {
            data1.push(value.appid);
            data2.push(value.bookid);
            data3.push(value.dnDate);
        });
        
        var listUrl = PARAMDATA.manifest.update.getlist+"?os_tp="+PARAMDATA.ostp;
        
        $.ajax({
            url: listUrl,
            data    : { "data1[]": data1, "data2[]": data2, "data3[]": data3 },
            type    : 'POST',
            cache   : false,
            async   : false,
            dataType: 'json',
            success: function (jsondata) {
                $libUpdate.updateGetListData = [];
                
                for( var l in jsondata.wisebook ){
                    $libUpdate.setUpdateListData(jsondata.wisebook[l]);
                }
                console.log("libBookShelf.createUpdateCountView( true )",jsondata);
                libBookShelf.createUpdateCountView( true );
                libBookShelf.bookShelfUpdateBook();
            },
            error: function () {
                $libUpdate.updateGetListData = [];
            }
        });
    },
    
    checkServerUpdateInfo : function( ){
        if(h5applib.getConnectStatus() != 'ok' && !PARAMLIBRARY.responseCheck ) {
            $libUpdate.updateBookCount = 0;
            if( typeof(callback) == 'function' ) callback( 0 );
            return false;
        }
        
        var data1 = new Array(); //appid
        var data2 = new Array(); //bookid
        var data3 = new Array(); //date
        
        $.each(this.serverSendData, function(key, value){
            data1.push(value.appid);
            data2.push(value.bookid);
            data3.push(value.dnDate);
        });
        
        var checkUrl =  PARAMDATA.manifest.update.check+"?os_tp="+PARAMDATA.ostp;
        
        
        $.ajax({
            url : checkUrl,
            data    : {"data1[]": data1, "data2[]" : data2, "data3[]": data3},
            type    : 'POST',
            cache   : false,
            dataType: 'json',
            success : function(jsondata){
                $libUpdate.updateBookCount = parseInt(jsondata.wisebook.books.count);
                if( $libUpdate.updateBookCount > 0 ) $libUpdate.getListUpdateData();
            },
            error: function(a, b, c){
                $libUpdate.updateGetListData = [];
                console.log('update XHR expiration error');
            }
        });
        
    },
    
    getUpdateCheckList : function(){
        if( !appFlag ) return false;
            
        console.log("cloudFlag && PARAMDATA.portalFlag",cloudFlag , PARAMDATA.portalFlag);
        
        //cloud user
        if( cloudFlag && PARAMDATA.portalFlag == false ){
            // return false;
        }
        console.log("this.updateServerCheckFlag",this.updateServerCheckFlag);
        
        
        // if( this.updateServerCheckFlag ) return false;
        console.log("getUpdateCheckList");

        this.updateServerCheckFlag = true;
        this.checkUpdateTimer = setTimeout(function(){
                                    $libUpdate.checkUpdateTimer = null;
                                    $libUpdate.updateServerCheckFlag = false;
                                }, this.delayTime);
                                
        this.serverSendData = [];
        //for(var appkey in PARAMLIBRARY.visible_data){
        for(var appkey in PARAMLIBRARY.bshelf_data){
            var downData = PARAMLIBRARY.bshelf_data[appkey];
            
            if(downData.status != 100 || downData.selected == "open" ) continue;

            if( cloudFlag && PARAMDATA.portalFlag == false ){
                //cloud user id check
                if( downData.objcontents.clouduser != PARAMDATA.memInfo.userid ) continue;
            }
            
            var tempObj = {};
            tempObj.appBookid = downData.app_book_id;
            tempObj.appid     = '';
            tempObj.bookid    = downData.objcontents.bookid;
            
            if( this.updateTest ) tempObj.dnDate  = '2011/07/07 00:00:00'; //test
            else if( appFlag == true ) tempObj.dnDate  = downData.down_date;
            
            this.serverSendData.push(tempObj);
        }
        
        if(this.serverSendData.length > 0) this.getListUpdateData();
    },
    
    logoutUpdateDataClearAndNowUpdateData : function( callback ){ 
        this.updateBookCount = this.updateQueueData.length;
        if( typeof( callback ) == "function" ) callback();
    },
    
    //cloud portal only
    clearDataInit : function(){
        this.updateBookCount = 0;
        this.updateGetListData = [];    
    },
    
    destroy : function(dnInfo){
        if( typeof(this.updateQueueData[0])  == 'undefined' ) return false;
        
        var waitUpdateAppBookid = this.updateQueueData[0].appBookid;
        
        try{
            if( dnInfo.procQueuStatus == "E" && dnInfo.status == "100" && waitUpdateAppBookid == dnInfo.app_book_id && dnInfo.procWaitBusy == 30 ){
                this.updateQueueData.shift();
                if(this.updateBookCount > 0) this.updateBookCount--;
                PARAMLIBRARY.bshelf_data[dnInfo.app_book_id].procWaitBusy = 0;
                
                h5applib.setProcWaitBusy( PARAMLIBRARY.bshelf_data[dnInfo.app_book_id] );
            }
        }catch(e){
            clearInterval($libUpdate.updateQueueTime);
            this.updateQueueTime = null;
            this.updateQueueData = [];
            h5applib.nalert("update exception : "+e, PARAMDATA.lang.oneword.ERROR);
        }       
    },
    
    updateCancelDestroy : function( cancelAppid ){
        var waitUpdateAppBookid = this.updateQueueData[0].appBookid;
        if( waitUpdateAppBookid == cancelAppid ) {
            this.updateQueueData.shift();
            if(this.updateBookCount > 0) this.updateBookCount--;
        }
    }
};
})(window);
