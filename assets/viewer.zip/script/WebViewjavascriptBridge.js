;(function() {
	if (window.WebViewJavascriptBridge) { return }
	var messagingIframe
	var sendMessageQueue = []
	var receiveMessageQueue = []
	var messageHandlers = {}
	
	var CUSTOM_PROTOCOL_SCHEME = 'wvjbscheme'
	var QUEUE_HAS_MESSAGE = '__WVJB_QUEUE_MESSAGE__'
	
	var responseCallbacks = {}
	var uniqueId = 1
	
	function _createQueueReadyIframe(doc) {
		messagingIframe = doc.createElement('iframe')
		messagingIframe.style.display = 'none'
		messagingIframe.src = CUSTOM_PROTOCOL_SCHEME + '://' + QUEUE_HAS_MESSAGE
		doc.documentElement.appendChild(messagingIframe)
	}

	function init(messageHandler) {
		if (WebViewJavascriptBridge._messageHandler) { throw new Error('WebViewJavascriptBridge.init called twice') }
		WebViewJavascriptBridge._messageHandler = messageHandler
		var receivedMessages = receiveMessageQueue
		receiveMessageQueue = null
		for (var i=0; i<receivedMessages.length; i++) {
			_dispatchMessageFromObjC(receivedMessages[i])
		}
	}

	function send(data, responseCallback) {
		_doSend({ data:data }, responseCallback)
	}
	
	function registerHandler(handlerName, handler) {
		messageHandlers[handlerName] = handler
	}
	
	function callHandler(handlerName, data, responseCallback) {
		_doSend({ handlerName:handlerName, data:data }, responseCallback)
	}
	
	function _doSend(message, responseCallback) {
		if (responseCallback) {
			var callbackId = 'cb_'+(uniqueId++)+'_'+new Date().getTime()
			responseCallbacks[callbackId] = responseCallback
			message['callbackId'] = callbackId
		}
		sendMessageQueue.push(message)
		messagingIframe.src = CUSTOM_PROTOCOL_SCHEME + '://' + QUEUE_HAS_MESSAGE
	}

	function _fetchQueue() {
		var messageQueueString = JSON.stringify(sendMessageQueue)
		sendMessageQueue = []
		return messageQueueString
	}

	function _dispatchMessageFromObjC(messageJSON) {

		setTimeout(function _timeoutDispatchMessageFromObjC() {
			var message = JSON.parse(messageJSON)
			var messageHandler
			var responseCallback

			if (message.responseId) {
				responseCallback = responseCallbacks[message.responseId]
				if (!responseCallback) { return; }
				responseCallback(message.responseData)
				delete responseCallbacks[message.responseId]
			} else {
				if (message.callbackId) {
					var callbackResponseId = message.callbackId
					responseCallback = function(responseData) {
						_doSend({ responseId:callbackResponseId, responseData:responseData })
					}
				}
				
				var handler = WebViewJavascriptBridge._messageHandler
				if (message.handlerName) {
					handler = messageHandlers[message.handlerName]
				}
				
				try {
					handler(message.data, responseCallback)
				} catch(exception) {
					if (typeof console != 'undefined') {
						console.log("WebViewJavascriptBridge: WARNING: javascript handler threw.", message, exception)
					}
				}
			}
		})
	}
	
	function _handleMessageFromObjC(messageJSON) {
		if (receiveMessageQueue) {
			receiveMessageQueue.push(messageJSON)
		} else {
			_dispatchMessageFromObjC(messageJSON)
		}
	}

	window.WebViewJavascriptBridge = {
		init: init,
		send: send,
		registerHandler: registerHandler,
		callHandler: callHandler,
		_fetchQueue: _fetchQueue,
		_handleMessageFromObjC: _handleMessageFromObjC
	}

	var doc = document
	_createQueueReadyIframe(doc)
	var readyEvent = doc.createEvent('Events')
	readyEvent.initEvent('WebViewJavascriptBridgeReady')
	readyEvent.bridge = WebViewJavascriptBridge
	doc.dispatchEvent(readyEvent)
})();

//!--iOS Native連携//
function connectWebViewJavascriptBridge(callback) {
    if (window.WebViewJavascriptBridge) {
        callback(WebViewJavascriptBridge)
    } else {
        document.addEventListener('WebViewJavascriptBridgeReady', function() {
            callback(WebViewJavascriptBridge)
        }, false)
    }
}

function getBookList(){
	var bookList = [];
	for(key in PARAMLIBRARY.bshelf_data){
        if(key.indexOf(PARAMLIBRARY.user_id) <= 0 && !PARAMDATA.useInApp) continue;
		bookList.push(PARAMLIBRARY.bshelf_data[key].objcontents.bookid);
	}
	return bookList;
}

function setUserInfo(data){
console.log('-------------setUserInfo data- start--------------');
	console.log(JSON.stringify(data));
	
console.log('-------------setUserInfo data end---------------');	
	if(data.reset == "1"){
   		PARAMLIBRARY.user_id = '';
        h5applib.bsCateKey = 'ALL';
        libStore.closeModal();
        libStore.goBack();
   		return;
    }
    PARAMLIBRARY.user_id = data.user_id;
    h5applib.bsCateKey = data.user_id;
    libBookShelf.refresh();
}

function openViewerFromBookshelf(bookid){
    h5applib.createView(bookid);
}

connectWebViewJavascriptBridge(function(bridge) {
    window._iOSBridge_ = bridge;

    bridge.init(function(message, responseCallback) {
//        var data = { 'Javascript Responds':'Wee!' }
//        responseCallback(data)
    });

    bridge.registerHandler('interfaceBookshelf', function(data, responseCallback) {
        var responseData = eval(data.method)(data.json);
        responseCallback(responseData);
    });

    bridge.registerHandler('openViewerIsNotDownloading', function(data, responseCallback) {
        var isDownloading = PARAMDATA.downloadQueue.length > 0 ? true : false;
        responseCallback(isDownloading);
    });

    bridge.registerHandler('callAddImageFunc', function(data, responseCallback) {
        wisebookPhotoAndVideo.fileList = data;
        wisebookPhotoAndVideo.createPhotoOrVideoImage();
        $webApiRouter.rotateLock(false);
    });

    bridge.registerHandler('forceChangeOrientation', function(orient, responseCallback) {
    	if(PARAM.orient != orient){
    		console.log(orient, PARAM.orient);
    		htmlview._resize({type:'orientationchange'});
    	}
    });

    bridge.registerHandler('setUserInfoToBookshelf', function(data, responseCallback) {
    	
    	setUserInfo(data);
    });

    bridge.registerHandler('openViewerFromBookshelf', function(data, responseCallback) {
        openViewerFromBookshelf(data);
    });
                               
    if(window.windowRouterInfo !== undefined)
        window.windowRouterInfo.webAppFlag = true;
});
//iOS Native連携--!//
