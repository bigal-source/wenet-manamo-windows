//psy21131126
window.viewUtils = (function (n) {
	var me = {},
		u = n.userAgent.toLowerCase();
	
	me.extend = function (target, obj) {
		for ( var i in obj ) {
			target[i] = obj[i];
		}
	};
	
	me.extend(me, {
		orientchange 	: 'onorientationchange' in window ? true : false,
		retina 			: window.devicePixelRatio > 1,
		hasTouch		: 'ontouchstart' in window,
		hasPointer		: (n.pointerEnabled || n.msPointerEnabled) && n.msMaxTouchPoints && n.msMaxTouchPoints > 1,
		iosInfo			:{
			version : null,
			check 	: false
		},
		androidInfo		: {
			webkit 		: null,
			version 	:null,
			check   	: false,
			inch7 		: false,
			isAndroidLowVersion : false
		},
		msiever			: null
	});
	
	me.extend(me, {
		Tablet:(u.indexOf("windows") != -1 && u.indexOf("touch") != -1) || u.indexOf("ipad") != -1 || (u.indexOf("android") != -1 && u.indexOf("mobile") == -1) || (u.indexOf("firefox") != -1 && u.indexOf("tablet") != -1) || u.indexOf("kindle") != -1 || u.indexOf("silk") != -1 || u.indexOf("playbook") != -1,
		Mobile:(u.indexOf("windows") != -1 && u.indexOf("phone") != -1) || u.indexOf("iphone") != -1 || u.indexOf("ipod") != -1 || (u.indexOf("android") != -1 && u.indexOf("mobile") != -1) || (u.indexOf("firefox") != -1 && u.indexOf("mobile") != -1) || u.indexOf("blackberry") != -1
	});
	
	function _eventType(type){
		var evetType;
		switch (type){
			case 'start' :
				evetType = 'mousedown';
				if(me.hasTouch) evetType = "touchstart";
				else if(me.hasPointer) evetType = window.PointerEvent ? "pointerdown" : "MSPointerDown";
			break;
					
			case 'move' :
				evetType = 'mousemove';
				if(me.hasTouch) evetType = "touchmove";
				else if(me.hasPointer) evetType = window.PointerEvent ? "pointermove" : "MSPointerMove";
			break;
				
			case 'end' :
				evetType = 'mouseup';
				if(me.hasTouch) evetType = "touchend";
				else if(me.hasPointer) evetType = window.PointerEvent ? "pointerup" : "MSPointerUp";
			break;
				
			case 'cancel' :
				evetType = 'mouseup';
				if(me.hasTouch) evetType = "touchcancel";	
				else if(me.hasPointer) evetType = window.PointerEvent ? "pointercancel" : "MSPointerCancel";
			break;
		}
			
		return evetType;
	}
	
	function device(){
		var userDevice = 'pc';
		if( u.match(/ipad/i) || u.match(/iphone/i) ){
			me.iosInfo.check = true;
			if( u.match(/ipad/i) ) userDevice = 'ipad';
			else if( u.match(/iphone/i) ) userDevice = 'iphone';
			
			var v =  (n.appVersion).match(/OS (\d+)_(\d+)_?(\d+)?/);
			v = (v) ? v : 7; // test
			me.iosInfo.version = parseInt(v[1], 10);
		}
		else if( u.match(/android/i) ){
			me.androidInfo.check = true;
			var v = u.match(/(android)\s[0-9]/g);
			me.androidInfo.version = v[0].match(/[0-9]/);
			userDevice = (u.match(/mobile/i)) ? 'android' : 'an_Tablet';
			
			if( me.Tablet ){
				var orient = ( screen.width > screen.height ) ?  "landscape" : "portrait";
				me.androidInfo.inch7 = ( orient == "portrait" && window.innerWidth >= 600 && window.innerWidth <= 610  ) || ( window.innerWidth >= 960 && window.innerWidth <= 970 );
			}
			
			try{
    			var tmpAppwebkit_ver =  u.match(/(applewebkit\/)\d*.\d*/);
                me.androidInfo.webkit = parseFloat( tmpAppwebkit_ver[0].match(/\d.*/g) );
                var tmpAndroid_ver = u.match(/(android)\s\d*.\d/g);
                me.androidInfo.version = parseFloat( tmpAndroid_ver[0].match(/\d.*/g) );
			}catch(e){}
			
			
			if( appFlag && me.androidInfo.version <= 4.2 ) me.androidInfo.isAndroidLowVersion = true;
		} else if( me.hasPointer ) {
			userDevice = 'wintouch';
		}
		me.device = userDevice;
	}
	
	function webBrowserCheck(){
		var browserStr;
		
		if( u.match(/msie/) || u.match(/trident/) ) {
			var ieVer = u.match(/(msie\s|rv:)([\d]+)/)[2];
			browserStr = 'msie';
			me.msiever = ieVer;
		}
		else if( u.indexOf('chrome') != -1 && u.indexOf('edge') == -1 ) browserStr = 'chrome';
		else if( u.indexOf('safari') != -1 && u.indexOf('edge') == -1 ) browserStr = 'safari';
		else if( u.indexOf('firefox') != -1 ) browserStr = 'firefox';
		else if( u.indexOf('opera') != -1 ) browserStr = 'opera';
		else if( u.indexOf('edge') != -1 ) browserStr = 'edge';
		else {
			if( me.iosInfo.check ) browserStr = 'safari';
			else if( me.androidInfo.check ) browserStr = 'chrome';
		}
		
		me.browser = browserStr;
	}

	function os(){
		var os, osclass="";
		var ua = navigator.userAgent;
	
		if (navigator.platform.indexOf("Win") != -1) {
			if (ua.match(/Win(dows )?NT 6\.4/)) {
				os = "Windows 10";				//Windows 10 Techinical Preview
			}else
			if (ua.match(/Win(dows )?NT 6\.3/)) {
				os = "Windows 8.1";				// Windows 8.1 の処理
			}
			else if (ua.match(/Win(dows )?NT 6\.2/)) {
				os = "Windows 8";				// Windows 8 の処理
			}
			else if (ua.match(/Win(dows )?NT 6\.1/)) {
				os = "Windows 7";				// Windows 7 の処理
			}
			else if (ua.match(/Win(dows )?NT 6\.0/)) {
				os = "Windows Vista";				// Windows Vista の処理
			}
			else if (ua.match(/Win(dows )?(NT 5\.1|XP)/)) {
				os = "Windows XP";				// Windows XP の処理
			}
			else if (ua.match(/Win(dows )?NT 5\.2/)) {
				os = "Windows Server 2003";			// Windows Server 2003 の処理
			}else os = "Windows Other";
			
			osclass = 'windowsos';
		} else if(navigator.platform.indexOf("Mac") != -1) {
			os = _getVer(ua, "Mac OS", ")");
			osclass = 'macos';
		} else {
			if(ua.indexOf("iPhone") != -1 || ua.indexOf("iPad") != -1) {
				var version = ua.match(/OS (\w+){1,3} /g);
				os = "i" + version;
			} else if(ua.indexOf("Android") != -1) {
				os = _getVer(ua, "Android", ";");
			} else {
				os = "N/A";					// 上記以外 OS の処理
			}
		}
		
		me.osclass = osclass;
		me.os = os;
	}
	
	function _vandors(){
		var dummyStyle = document.createElement('div').style,
			animationSupport = false,
			animation = 'animation',
			vendorPrefix = prefix = '',
			domPrefixes = ['Webkit', 'Moz', 'O', 'ms', 'Khtml'];
		
		for( var i = 0; i < domPrefixes.length; i++ ) {
            if( dummyStyle[ domPrefixes[i] + 'AnimationName' ] !== undefined ) {
                prefix = domPrefixes[ i ];
                animationString = prefix + 'Animation';
                vendorPrefix = '-' + prefix.toLowerCase() + '-';
                break;
            }
        }
		return vendorPrefix;
	}
	
	function transitionEnd() {
		var el = document.createElement('bootstrap');
		var transEndEventNames = {
			'WebkitTransition' : 'webkitTransitionEnd',
			'MozTransition'    : 'transitionend',
			'OTransition'      : 'oTransitionEnd otransitionend',
			'transition'       : 'transitionend'
		};
		for (var name in transEndEventNames) {
			if (el.style[name] !== undefined) {
				return { end: transEndEventNames[name] };
			}
		}
		
		return false;
	}
	
	function _getVer(ua, myKey, delimiter){
		var myStart = ua.indexOf(myKey);// + myKey.length;
		var myEnd = ua.indexOf(delimiter, myStart);
		return ua.substring (myStart, myEnd);
	}

	os();
	device();
	webBrowserCheck();
	me.vandor = _vandors();
	me.transition = transitionEnd();

	var start_e = (me.device != 'pc') ? _eventType('start') : 'mousedown';
	var move_e = (me.device != 'pc') ? _eventType('move') : 'mousemove';
	var end_e = (me.device != 'pc') ? _eventType('end') : 'mouseup';
	var cancel_e = (me.device != 'pc') ? _eventType('cancel') : 'mouseup';
	
	
	
	me.extend(me, {
		START_EV 	: start_e,
		MOVE_EV	 	: move_e,
		END_EV		: end_e,
		CANCEL_EV	: cancel_e,
		CLICK_EV	: 'click',
		MOUSE_DW	: 'mousedown',
		MOUSE_MV	: 'mousemove',
		MOUSE_EN	: 'mouseup'
	});
    
	return me;
})( window.navigator );

var waitForResizeEvent = (function(){
	var timer = 0;
	return function(callback, ms){
		clearTimeout (timer);
		timer = setTimeout(callback, ms);
	};
})();
