(function() {
    wisebooklink = function() {
        this.init();
    };

    wisebooklink.prototype = {
        itemElement: null,
        linkmode: false,
        storageData: null,
        userModeElem: null,
        nowOption: 1,
        colorClass: 'link-color',
        linkDefualtSizeW: 200,
        linkDefualtSizeH: 250,
        miniSize: 40,
        isMove: false,
        isActive: false,
        isDragFalse: false,
        isDelete: false,
        currentOption: 0,
        currentTarget: '',
        pageWidth: 0,
        pageHeight: 0,
        originThumbSize: null,
        enabledLinkFunc: false,

        init: function() {
 
 console.log("wisebook.link init start");
 
            this.linkDefualtSizeW = viewUtils.Mobile ? 100 : 200;
            this.linkDefualtSizeH = viewUtils.Mobile ? 125 : 250;

            this.linkDefualtSizeW = this.linkDefualtSizeW / htmlview.getFixedPortraitScale();
            this.linkDefualtSizeH = this.linkDefualtSizeH / htmlview.getFixedPortraitScale();

            this.itemElement = document.createElement('div');
            this.itemElement.innerHTML = '<div class="linkLayer"></div>';

            this.storageData = h5appview.wisebookStorageList.pages;

            $.extend(this, linkModule);

            this.userModeElem = $('.custom-space');
            this.commonEvent();
            this.linkEvent();
            this.setColorPickerInit();
 console.log("wisebook.link init finish");
 $('#urllink_contents_body').hide();//2020-06-03

 
        },

        commonEvent: function() {
            var that = this;

            $(document).on(viewdefind.TURNJS_PRESSED_EVENT, function() {
                that.userModeElem.find('.linkLayer').remove();
            });

            $(document).on(viewdefind.TURNJS_RELEASED_EVENT, function() {
                that.refresh();
            });

            $(document).on(viewdefind.PAGE_BEFORE_EVENT, function() {
                if (viewUtils.Mobile && that.isPhoneLinkList) $("#phone-link-list-body").css("display", "none");
                that.userModeElem.find('.linkLayer').remove();
            });

            $(document).on(viewdefind.PAGE_AFTER_EVENT, function() {
                that.refresh();
            });

            $(document).on(viewdefind.LINK_MODE_OPEN, function() {
                           console.log("fire LINK_MODE_OPEN");
                that.linkModeOpen();
            });
 
 
            console.log("atempt to regist VIEW_POPUP_CLOSE " , viewdefind.VIEW_POPUP_CLOSE);

            $(document).on(viewdefind.VIEW_POPUP_CLOSE, function(e) {
                           
                console.log("called VIEW_POPUP_CLOSE " , PARAM.nowBusy);
                if (PARAM.nowBusy != 'link') return false;
                that.linkModeClose();
                //that.resizableLockMode(false);
                ADDONS.viewNavContainerAction('show');
                if (that.enabledLinkFunc)
                    ADDONS.openSelectPageFunc();
               
                PARAM.isPageMove = false;
            });

 
            $(document).on(viewdefind.VIEW_DESTROY, function() {
                that.destroy();
            });

            $(document).on(viewdefind.ADDONS_RESIZE, function() {
                that.refresh();
            });
        },

        setColorPickerInit : function(){
            var that = this;

            var canvas = document.getElementById('picker_canvas');
            var ctx = canvas.getContext('2d');
            
            var image = new Image();
            image.addEventListener("load", function(){
                ctx.drawImage(image, 0, 0, image.width / 2, image.height / 2); // draw the image on the canvas  
            });
            
            var imageSrc = '../../www/library/images/link/colorpicker.png';
            image.crossOrigin="anonymous";
            image.src = imageSrc; 
            
            $(canvas).hammer().on('drag', function(e){
                var xpos = e.gesture.srcEvent.offsetX === undefined ? e.gesture.srcEvent.layerX : e.gesture.srcEvent.offsetX;
                var ypos = e.gesture.srcEvent.offsetY === undefined ? e.gesture.srcEvent.layerY : e.gesture.srcEvent.offsetY; 
                that.selectColorPickData(ctx, xpos, ypos);
            }).on('click', function(e){
                var xpos = e.offsetX == undefined ? e.originalEvent.layerX : e.offsetX;
                var ypos = e.offsetY == undefined ? e.originalEvent.layerY : e.offsetY;
                that.selectColorPickData(ctx, xpos, ypos);
            });
        },

        selectColorPickData : function(ctx, x, y){
            var imageData = ctx.getImageData(x, y, 1, 1);
            var pixel = imageData.data;
            var pixelColor = "rgb("+pixel[0]+", "+pixel[1]+", "+pixel[2]+")";
                
            $('.url_color_p').css('backgroundColor', pixelColor);
            $('.url_color').css('backgroundColor', pixelColor);
            
            $('#select_color_r').text(pixel[0]);
            $('#select_color_g').text(pixel[1]);
            $('#select_color_b').text(pixel[2]);
            
            var dColor = pixel[2] + 256 * pixel[1] + 65536 * pixel[0];
            $('.color_picker_txt').text('#' + ('0000' + dColor.toString(16)).substr(-6));
        },

        hexToRgb: function(hex){
            result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
            return parseInt(result[1], 16)+','+parseInt(result[2], 16)+','+parseInt(result[3], 16);
        },

        createLinkArea : function(){
            var target = $('#' + this.currentTarget);

            var obj = JSON.parse(JSON.stringify(target.data('objInfo')));

            obj.url = $('.input_url').val();
            obj.trans = $('.url_radio:eq(0)').hasClass('selected') ? true : false;
            obj.color = $('.color_picker_txt').text();

            wisebookundoredo.addEvent({
                'name': 'link',
                'objInfo': obj,
                'event': 'add',
                'page': obj.page
            });

            target.css({
                'background-color': obj.color,
                'opacity': obj.trans ? 0 : 0.5
            });

            target.draggable('destroy').resizable('destroy');

            target.css({
                'background-image': '',
                'background-size': '',
                'background-positio:': '',
                'background-repeat': ''
            });

            this.userModeElem.css({
                'background-color': '',
                'opacity': ''
            });

            $('.link-option-selecter').eq(1).addClass('selected');
            $('.link-option-selecter').eq(1).css('font-weight', 'bold');
            $('.link-option-selecter').eq(0).css('font-weight', '');
            $('.link-option-selecter').eq(0).text('新規');

            target.data('objInfo', obj);
            this.currentOption = 2;
            this.storageData[obj.page].linkList.push(obj);
            this.updateLink(obj);
            this.currentTarget = '';

            this.closeLinkEditPopup();
            // $('#url_btn_cancel').trigger('tap');
        },

        linkModeOpen: function() {
 
 console.log("called linkModeOpen");

            //htmlview.viewActionDisable();
            this.linkmode = true;
            PARAM.isNaviMove = false;

            if( viewUtils.androidInfo.check) 
                PARAM.isResizeWork = false;

            if (viewUtils.device == 'pc') {
                $(document).trigger(viewdefind.NAV_MOVE_DISABLE, true);
                htmlview.viewActionDisable();
            }

            if (viewUtils.device == 'pc' && PARAM.isZoom)
                htmlview.viewContain.css({
                    "cursor": "default"
                });

            var viewPage = htmlview.domDisplay[PARAM.currentpage];
            this.pageWidth = viewPage.width();
            this.pageHeight = viewPage.height();

            this.refresh();
        },

        linkModeClose: function() {

            if( viewUtils.androidInfo.check) 
                PARAM.isResizeWork = true;

            this.linkmode = false;
            PARAM.isNaviMove = true;
 
            htmlview.viewActionEnable();
            $(document).trigger(viewdefind.NAV_MOVE_DISABLE, false);
            this.userModeElem.css({
                width: '',
                height: ''
            });

            if (viewUtils.device == 'pc' && PARAM.isZoom)
                htmlview.viewContain.css({
                    "cursor": "move"
                });
        },

        setLinkPosition: function() {
            var x, y;

            var tempLinkDefualtSizeW = this.linkDefualtSizeW;
            var tempLinkDefualtSizeH = this.linkDefualtSizeH;

            if (PARAM.orient != 'landscape') {
                tempLinkDefualtSizeW = this.linkDefualtSizeW * PARAM.spaceScale;
                tempLinkDefualtSizeH = this.linkDefualtSizeH * PARAM.spaceScale;
            }

            x = (this.pageWidth / 2) - (tempLinkDefualtSizeW / 2) / PARAM.transformInfo.scale;
            y = (this.pageHeight / 2) - (tempLinkDefualtSizeH / 2) / PARAM.transformInfo.scale;

            var page = PARAM.getUserFullPositionPage(x),
                position = PARAM.allowPosition(x, y, tempLinkDefualtSizeW, tempLinkDefualtSizeH);

            var elemInfo = {
                uniqid: PARAM.uniqID(),
                page: page,
                x: position.x,
                y: position.y,
                w: this.linkDefualtSizeW,
                h: this.linkDefualtSizeH,
                miniStatus: 0,
                url: '',
                color: '',
                trans: false
            };

            this.currentTarget = elemInfo.uniqid;
            this.createlink(elemInfo);
        },

        updateLink: function(obj) {
            var items = this.storageData[obj.page].linkList;
            for (var i in items) {
                var item = items[i];
                if (item.uniqid == obj.uniqid) {
                    item = obj;
                    h5appview.setStorageData(obj.page);
                    break;
                }
            }
        },

        removeOneLink: function(obj, removeFlag) {
            for (var key in this.storageData[obj.page].linkList) {
                var item = this.storageData[obj.page].linkList[key];
                if (item.uniqid == obj.uniqid) {
                    this.storageData[obj.page].linkList.splice(key, 1);

                    if (removeFlag) {
                        $('#' + obj.uniqid).remove();
                    }

                    h5appview.setStorageData(obj.page);
                    break;
                }
            }
        },

        removeAlllink: function() {
            for (var v in PARAM.side.view) {
                var page = PARAM.side.view[v];
                if (page == 0) continue;

                if (this.storageData[page].linkList <= 0) continue;
                this.storageData[page].linkList = [];
                h5appview.setStorageData(page);
            }

            if (!viewUtils.Mobile) this.userModeElem.find('.linkLayer').draggable('destroy').resizable('destroy').remove();
            else this.userModeElem.find('.linkLayer').remove();
        },

        storageDataToBook: function() {
            if (PARAM.viewMode == "twopage") {
                for (var v in PARAM.side.view) {
                    var page = PARAM.side.view[v];
                    if (page == 0) continue;

                    var items = this.storageData[page].linkList;
                    if (items <= 0) continue;

                    for (var i in items) {
                        var item = items[i];
                        if ($('#' + item.uniqid).length > 0) continue;

                        this.loadLink(item);
                    }
                }
            } else {
                if (PARAM.bookInfo.config.single == 0) {

                    var pointnum = PARAM.getPointnum(PARAM.currentpage),
                        leftpage = PARAM.doublePair[pointnum].left,
                        rightpage = PARAM.doublePair[pointnum].right;

                    if (leftpage != 0) {
                        var items = this.storageData[leftpage].linkList;
                        for (var i in items) {
                            var item = items[i];
                            if ($('#' + item.uniqid).length > 0) continue;

                            this.loadLink(item);
                        }
                    }
                    if (rightpage != 0) {
                        var items = this.storageData[rightpage].linkList;

                        for (var i in items) {
                            var item = items[i];

                            if ($('#' + item.uniqid).length > 0) continue;
                            this.loadLink(item);
                        }
                    }

                } else {
                    var items = this.storageData[PARAM.currentpage].linkList;
                    for (var i in items) {
                        var item = items[i];
                        if ($('#' + item.uniqid).length > 0) continue;

                        this.loadLink(item);
                    }
                }
            }
        },

        destroy: function() {
            this.userModeElem.unbind('tap');
        },

        refresh: function() {
            // if (viewUtils.Mobile) this.linkListCountView(resize);
            // else {
            //     //console.log( typeof( this.storageDataToBook ) );
            //     this.storageDataToBook();
            // }
            this.storageDataToBook();

            if (this.linkmode) {
                this.userModeElem.css({
                    width: PARAM.userModeInfo.w,
                    height: PARAM.userModeInfo.h
                });
            }
        },

        learnRegExp: function(urldata){
            return urldata.match(/^(http:\/\/|https:\/\/)?([a-z0-9\-]+\.)?[a-z0-9\-]+\.[a-z0-9]{2,4}(\.[a-z0-9]{2,4})?(\/.*)?$/i);
        },

        closeLinkEditPopup: function(){
            $('.url_color').css('background', '#ffc1c1');
            $('.color_picker_txt').text('#ffc1c1');
            $('.url_radio:eq(0)').removeClass('selected');
            $('.url_radio:eq(1)').addClass('selected');
            $('.url_radio:eq(1)').attr("checked", "checked");
            $('.input_url').val('http://');
            $('#urllink_contents_body').hide();
        }
    };
    //pc tablet
    var linkModule = {
        linkEvent: function() {
            var that = this;
            $(document).on(viewdefind.LINK_RESIZEBLE_LOCK, function() {
                that.resizableLock();
            });

            this.userModeElem.on('tap', that.linkBarControl);

            //color picker start
            $('.url_color').hammer({tap_max_touchtime:PARAM.tapTime}).on('tap', function(){
                $('.url_color_p').css('background', $('.color_picker_txt').text());
                var hexVale = that.hexToRgb($('.color_picker_txt').text());
                hexVale = hexVale.split(',');
                $('#select_color_r').text(hexVale[0]);
                $('#select_color_g').text(hexVale[1]);
                $('#select_color_b').text(hexVale[2]);
                
                $('.url_setting').hide();
                $('.url_colorpicker').show(function(){
                    $('.urllink_btn_close').css('display', 'block');    
                });
            });

            //color picker end
            $('.urllink_btn_close').hammer({tap_max_touchtime:PARAM.tapTime}).on('tap', function(){
                $(this).css('display', 'none');
                $('.url_colorpicker').hide();
                $('.url_setting').show( );
            });
            
            $('#url_btn_save').hammer({tap_max_touchtime:PARAM.tapTime}).on('tap', function() {

                var urlString = $('.input_url').val();
                
                if( that.learnRegExp( urlString ) === null ){
                    h5applib.nalert('URLが正しくありません。', '');
                    return;
                }

                if(that.currentOption == 2){
                    var objInfo = $('#'+that.currentTarget).data('objInfo');
                    var target = $('#'+that.currentTarget);

                    objInfo.trans = $('.url_radio:eq(0)').hasClass('selected') ? true : false;
                    objInfo.color = $('.color_picker_txt').text();
                    objInfo.url = urlString;

                    target.css({
                        'background-color': objInfo.color,
                        'opacity': objInfo.trans ? 0 : 0.5
                    });

                    that.updateLink(objInfo);
                    that.currentTarget = '';
                    that.closeLinkEditPopup();
                    // $('#url_btn_cancel').trigger('tap');
                }else{
                    that.createLinkArea();    
                }
            });

            $('#url_btn_cancel').hammer({tap_max_touchtime:PARAM.tapTime}).on('tap', function() {
                that.closeLinkEditPopup();
            });

            // 新規：1、編集：2、削除：3
            PARAM.wisebook.on('tap', '.link-option-selecter, .link-close', function() {
                if($('#urllink_contents_body').is(':visible')) return;

                clicked = $(this);
                that.isDelete = false;
                $('.link-option-selecter').css('font-weight', 'normal');
                $('.link-option-selecter').eq(0).text('新規');

                if (clicked.hasClass('link-option-selecter')) {
                    $(this).css('font-weight', 'bold');
                    var option = $(this).data('option');

                console.log("called link action option=",option);
                              
                              
                    if (option == 1) {
                        clicked.text('設定');
                        if (that.currentOption == option) {
                              console.log("atempt to show link dialog");
                            $('#urllink_contents_body').show();
                        } else {
                              console.log("atempt to show link rect");
                            that.setLinkPosition();
                            that.userModeElem.css({
                                'background-color': 'black',
                                'opacity': 0.5
                            });
                        }
                    } else if (option == 2 || option == 3) {
                        that.userModeElem.css({
                            'background-color': '',
                            'opacity': ''
                        });

                        if(that.currentOption == 1)
                            $('#' + that.currentTarget).remove();

                        if (option == 3) {
                            $('.link-option-selecter').removeClass('selected');
                            clicked.addClass('selected');
                            that.isDelete = true;
                        }
                    }
                    that.currentOption = option;
                } else if (clicked.hasClass('link-close')) {
                    that.isDelete = false;
                    that.userModeElem.css({
                        'background-color': '',
                        'opacity': ''
                    });
                    
                    $('.link-option-selecter').eq(0).addClass('selected');
                    $('.link-eraser-selecter').removeClass('selected');
                        
                    if(that.currentOption == 1)
                        $('#' + that.currentTarget).remove();
                    
                    that.currentOption = 0;
                    $webApiRouter.rotateLock(false);
                    ADDONS.closeModal();  
                }
            });

            // this.userModeElem.on('tap', '.link-close', function() {
            //     console.log('bac');
            //     var elem = $(this);
            //     viewMessageProc.confirm(PARAM.viewLang.linkOneDelete, PARAM.viewLang.confirm_title,
            //         function() {
            //             var uniqId = elem.data('id'),
            //                 objInfo = $('#' + uniqId).data('objInfo');
            //             that.removeOneLink(objInfo, true);
            //         }
            //     );
            // });
        },

        linkBarControl: function(obj) {
            var that = wisebooklink;
            if ($('.view-popup-link').is(":visible") && that.currentOption == 1)
                $('.view-popup-link').slideUp('fast');
            else
                $('.view-popup-link').slideDown('fast');
        },

        createlink: function(obj) {
            var that = this;

            var actualpos = this.getLinkLocation(obj);

            if (PARAM.orient == 'landscape') {
                actualpos.x = PARAM.userModeInfo.w / 2 - Math.ceil(obj.w * PARAM.spaceScale) / 2;
                actualpos.y = PARAM.userModeInfo.h / 2 - Math.ceil(obj.h * PARAM.spaceScale) / 2;
            }else{
                if (PARAM.side.right == obj.page && PARAM.bookInfo.config.single === 0 && PARAM.side.left !== 0) {
                    if(viewUtils.Mobile){
                        actualpos.x = obj.x;
                    }else{
                        actualpos.x = PARAM.side.rightstartx + obj.x;
                    }
                }else{
                    actualpos.x = obj.x;    
                }
                actualpos.y = obj.y;
            }

            var lookPosData = PARAM.getActualPosByLookPos(PARAM.orient == 'landscape' ? actualpos.x : obj.x, actualpos.y, obj.h, obj.w);

            obj.x = lookPosData.x;
            obj.y = lookPosData.y;

            var elem = $('<div />', {
                'id': obj.uniqid,
                'class': obj.className,
                'css': {
                    left: actualpos.x,
                    top: actualpos.y,
                    width: Math.ceil(obj.w * PARAM.spaceScale),
                    height: Math.ceil(obj.h * PARAM.spaceScale),
                    position: 'absolute',
                    'background': 'url(' + htmlview._pages[PARAM.currentpage - 1].thumbload.src + ')',
                    'background-size': PARAM.imageWidth + 'px ' + PARAM.imageHeight + 'px',
                    'z-index': 1,
                    'background-position': actualpos.x * -1 + 'px ' + actualpos.y * -1 + 'px'
                },
                'type': obj.type,
                'page': obj.page
            }).data('objInfo', obj);

            var exList = {
                'ui-resizable-handle ui-resizable-ne': 'topRightImage',
                'ui-resizable-handle ui-resizable-nw': 'topLeftImage',
                'ui-resizable-handle ui-resizable-se': 'bottomRightImage',
                'ui-resizable-handle ui-resizable-sw': 'bottomLeftImage'
            };

            for (var key in exList) {
                $('<div />', {
                    'id': exList[key],
                    'class': key
                }).appendTo(elem);
            }

            that.userModeElem.append(elem);
            this.dynamicLinkUiEvent(obj.uniqid);
        },

        getLinkLocation: function(obj) {

            var actualpos = PARAM.getLookPosByActualPos(obj.x, obj.y, obj.w, obj.h);

            actualpos.w = Math.max(actualpos.w, this.imageDefaultsize);
            actualpos.h = Math.max(actualpos.h, this.imageDefaultsize);

            if (PARAM.side.right == obj.page && PARAM.bookInfo.config.single == 0 && PARAM.side.left != 0) {
                actualpos.x += PARAM.side.rightstartx;
            }

            var ckMemoResize_w = (obj.miniStatus == 0) ? actualpos.x + actualpos.w : actualpos.x + this.miniSize;
            var ckMemoResize_h = (obj.miniStatus == 0) ? actualpos.y + actualpos.h : actualpos.y + this.miniSize;

            if (!obj.miniStatus) {
                //min
                if (0 > actualpos.x) actualpos.x = 0;
                if (0 > actualpos.y) actualpos.y = 0;

                //max
                if (PARAM.userModeInfo.w < ckMemoResize_w) {
                    var reLeftAmin = ckMemoResize_w - PARAM.userModeInfo.w;
                    actualpos.x -= reLeftAmin;
                }

                if (PARAM.userModeInfo.h < ckMemoResize_h) {
                    var reTopAmin = ckMemoResize_h - PARAM.userModeInfo.h;
                    actualpos.y -= reTopAmin;
                }
            } else {
                //min
                if (0 > actualpos.x) actualPos.x = 0;
                if (0 > actualpos.y) actualPos.y = 0;

                //max
                if (PARAM.userModeInfo.w < ckMemoResize_w) {
                    var reLeftAmin = ckMemoResize_w - PARAM.userModeInfo.w;
                    actualpos.x -= reLeftAmin;
                }

                if (PARAM.userModeInfo.h < ckMemoResize_h) {
                    var reTopAmin = ckMemoResize_h - PARAM.userModeInfo.h;
                    actualpos.y -= reTopAmin;
                }
            }
            return actualpos;
        },

        loadLink: function(obj) {

            if(viewUtils.Mobile){
                if(PARAM.viewMode != 'twopage' && obj.page != PARAM.currentpage) return;
            }
            
            var _tempElement = document.createElement('div'),
                tranClass = (obj.trans) ? 'linktrans' : 'linknotrans';

            var actualpos = PARAM.getLookPosByActualPos(obj.x, obj.y, obj.w, obj.h);

            //actualpos.w = Math.max(actualpos.w, this.linkDefualtSize);
            //actualpos.h = Math.max(actualpos.h, this.linkDefualtSize);

            if (PARAM.side.right == obj.page && PARAM.bookInfo.config.single == 0 && PARAM.side.left != 0) {
                if(viewUtils.Mobile){
                    if(PARAM.viewMode == 'twopage') actualpos.x += PARAM.side.rightstartx;
                }else{
                    actualpos.x += PARAM.side.rightstartx;
                }
            }

            var ckLinkResize_w = (obj.miniStatus == 0) ? actualpos.x + actualpos.w : actualpos.x + this.miniSize;
            var ckLinkResize_h = (obj.miniStatus == 0) ? actualpos.y + actualpos.h : actualpos.y + this.miniSize;

            if (!obj.miniStatus) {
                //min
                if (0 > actualpos.x) actualpos.x = 0;
                if (0 > actualpos.y) actualpos.y = 0;

                //max
                if (PARAM.userModeInfo.w < ckLinkResize_w) {
                    var reLeftAmin = ckLinkResize_w - PARAM.userModeInfo.w;
                    actualpos.x -= reLeftAmin;
                }

                if (PARAM.userModeInfo.h < ckLinkResize_h) {
                    var reTopAmin = ckLinkResize_h - PARAM.userModeInfo.h;
                    actualpos.y -= reTopAmin;
                }
            } else {
                //min
                if (0 > actualpos.x) actualPos.x = 0;
                if (0 > actualpos.y) actualPos.y = 0;

                //max
                if (PARAM.userModeInfo.w < ckLinkResize_w) {
                    var reLeftAmin = ckLinkResize_w - PARAM.userModeInfo.w;
                    actualpos.x -= reLeftAmin;
                }

                if (PARAM.userModeInfo.h < ckLinkResize_h) {
                    var reTopAmin = ckLinkResize_h - PARAM.userModeInfo.h;
                    actualpos.y -= reTopAmin;
                }
            }

            _tempElement.innerHTML = this.itemElement.innerHTML;
            var findBoxElem = htmlview.findElement('.linkLayer', _tempElement);

            findBoxElem.css({
                left: actualpos.x,
                top: actualpos.y,
                width: Math.ceil(obj.w * PARAM.spaceScale),
                height: Math.ceil(obj.h * PARAM.spaceScale),
                position: 'absolute',
                'background-color': obj.color,
                opacity: (obj.trans ? 0 : 0.5)
            }).attr({
                'id': obj.uniqid,
                'data-page': obj.page
            }).addClass(tranClass + '  ' + this.colorClass + 'white');

            this.userModeElem.append(findBoxElem);
            findBoxElem.data('objInfo', obj);

            this.dynamicLinkUiEvent(obj.uniqid);
        },

        dynamicLinkUiEvent: function(uniqId) {
            var that = this;
            $('#' + uniqId).draggable({
                scroll: false,
                addClasses: false,
                create: function() {},
                start: function(e) {
                    if (that.isActive) {
                        that.isActive = false;
                        return false;
                    }

                    that.isActive = true;
                    that.isFalse = false;
                    PARAM.isNaviMove = false;

                    $(this).draggable("option", "revert", false);
                },
                drag: function(e, ui) {
                    if (that.currentTarget != $(this).attr('id')) return false;
                    if (!that.isActive) return false;
                    if (that.isFalse == true) that.isFalse = false;

                    var page = $(this).data('page'),
                        this_x = ui.position.left,
                        this_y = ui.position.top,
                        this_max_x = $(this).width() + ui.position.left,
                        this_max_y = $(this).height() + ui.position.top,
                        min_x = PARAM.userModeInfo.x,
                        max_x = PARAM.userModeInfo.w,
                        max_y = PARAM.userModeInfo.h;

                    if (PARAM.side.right == page && PARAM.viewMode == 'twopage' && PARAM.side.left == 0) {
                        min_x = 0;
                    }

                    $(this).css('background-position', this_x * -1 + 'px ' + this_y * -1 + 'px');
                },
                stop: function(e, ui) {
                    if (that.isFalse == false) {
                        var objInfo = $(this).data('objInfo'),
                            this_x = ui.position.left,
                            this_y = ui.position.top,
                            this_w = $(this).outerWidth(true),
                            this_h = $(this).outerHeight(true);

                        var selectPage = PARAM.getUserFullPositionPage(this_x);

                        if (selectPage != objInfo.page) {
                            that.removeOneLink(objInfo, false);

                            $('#' + objInfo.uniqid).attr('data-page', selectPage);
                            objInfo.page = selectPage;
                            that.storageData[selectPage].linkList.push(objInfo);
                        }

                        if(!viewUtils.Mobile){
                            if (PARAM.side.right == selectPage && PARAM.bookInfo.config.single == 0 && PARAM.side.left != 0) {
                                this_x -= PARAM.side.rightstartx;
                            }
                        }

                        var lookPosData = PARAM.getActualPosByLookPos(this_x, this_y, this_h, this_w);

                        objInfo.x = lookPosData.x;
                        objInfo.y = lookPosData.y;

                        $(this).data('objInfo', objInfo);
                    }
                    that.isActive = false;
                }
            }).resizable({
                cancel: '.lock',
                minHeight: 20,
                minWidth: 20,
                handles: {
                    'ne': '#topRightImage',
                    'se': '#bottomRightImage',
                    'sw': '#bottomLeftImage',
                    'nw': '#topLeftImage'
                },

                start: function(e, ui) {
                    PARAM.isResizeWork = false;
                    PARAM.isNaviMove = false;

                    var max_w = PARAM.userModeInfo.w,
                        max_h = PARAM.userModeInfo.h,
                        this_max_x = ui.position.left + ui.size.width,
                        this_max_y = ui.position.top + ui.size.height,
                        space_x = max_w - this_max_x,
                        space_y = max_h - this_max_y;

                    var maxWidth_value = ui.size.width + space_x;
                    $(this).resizable('option', 'maxWidth', maxWidth_value);

                    var maxHeihgt_value = ui.size.height + space_y;
                    $(this).resizable('option', 'maxHeight', maxHeihgt_value);
                },
                resize: function(e, ui) {
                    var this_x = ui.position.left,
                        this_y = ui.position.top;
                    $(this).css('background-position', this_x * -1 + 'px ' + this_y * -1 + 'px');
                },
                stop: function(e, ui) {
                    
                    setTimeout(function() {
                        PARAM.isNaviMove = true;
                    }, 50);
                    
                    var objInfo = $(this).data('objInfo');

                    var selectPage = PARAM.getUserFullPositionPage(this_x);
                    var this_x = ui.position.left;

                    if(!viewUtils.Mobile){
                        if (PARAM.side.right == selectPage && PARAM.bookInfo.config.single == 0 && PARAM.side.left != 0) {
                            this_x -= PARAM.side.rightstartx;
                        }
                    }

                    var lookPosData = PARAM.getActualPosByLookPos(this_x, ui.position.top, ui.size.width, ui.size.height);

                    objInfo.w = lookPosData.w;
                    objInfo.h = lookPosData.h;
                    objInfo.x = lookPosData.x;
                    objInfo.y = lookPosData.y;

                    $(this).data('objInfo', objInfo);

                    PARAM.isResizeWork = true;
                }
            });

            $('#' + uniqId).on('tap', function(e) {
                var objInfo = $(this).data('objInfo');
                if (that.linkmode) {
                    if (that.isDelete) {
                        wisebookundoredo.addEvent({
                            'name': 'link',
                            'objInfo': objInfo,
                            'event': 'remove',
                            'page': objInfo.page
                        });
                        that.removeOneLink(objInfo, true);
                    } else {
                        if (that.currentOption == 2) {
                            $('.input_url').val(objInfo.url);
                            $('.color_picker_txt').text(objInfo.color);
                            $('.url_color').css('background', objInfo.color);

                            if(objInfo.trans){
                                $('.url_radio:eq(1)').removeClass('selected');
                                $('.url_radio:eq(0)').addClass('selected');
                                // added by jhoh 05/17/2017, change radio box to input radio
                                // if there is checking point to transparent check to that
                                // below : half-transparent & array number 0
                                $('.url_radio:eq(0)').attr("checked", "checked");
                            } else {
                                // added by jhoh 05/17/2017, change radio box to input radio
                                // if there is checking point to half-transparent check to that
                                // below : half-transparent & array number 1
                                $('.url_radio:eq(1)').attr("checked", "checked");
                            }
                            that.currentTarget = objInfo.uniqid;
                            $('#urllink_contents_body').show();
                        }
                    }
                } else {
                    window.open(objInfo.url, '_blank', 'closebuttoncaption=戻る,toolbarposition=top,location=no');
                }
            });
        },

        resizableLock: function() {
            for (var v in PARAM.side.view) {
                var page = PARAM.side.view[v];
                if (page == 0) continue;

                if (PARAM.isZoom)
                    this.userModeElem.find('.linkLayer').addClass('lock');
                else
                    this.userModeElem.find('.linkLayer').removeClass('lock');
            }
        },

        resizableLockMode: function(isMode) {
            if (isMode) {
                this.userModeElem.find('.linkLayer').removeClass('lock');
                this.userModeElem.find('.linkLayer').draggable('enable');
                this.userModeElem.find('.linkLayer').find('.ui-icon').css('display', 'block');
            } else {
                this.userModeElem.find('.linkLayer').addClass('lock');
                this.userModeElem.find('.linkLayer').draggable('disable');
                this.userModeElem.find('.linkLayer').find('.ui-icon').css('display', 'none');
            }
        }
    };
})();
