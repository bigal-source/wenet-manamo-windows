(function(){
	htmlview_defind = function(){};
	
	htmlview_defind.prototype = {
		VIEW_NAV_AUTOHIDE_CLEAR : "clear-start-viewNavContainerAction-cleartimer",
		PAGE_BEFORE_EVENT : "page-before-event",
		PAGE_AFTER_EVENT : "page-after-event",
		ZOOM_ANIMATION_END : "wisebook-zoom.animation-end",
		ADDONS_RESIZE  : "addons.resize",
		ADDONE_OPNE_POPUPTEXT : "addons.openPopuptext",
		VIEW_DESTROY : "view-destroy",
		
		VIEW_THUMB_RESIZE : "view-thumbmailResize",
		MAKEITEMDISPLAYIMG : "view-makeItemDisplay",
		MAKEDISPLAYIMG : "view-makedisplay",
		
		//popup
		VIEW_POPUP_OPEN : "view-popup-open",
		VIEW_POPUP_OPENED : "view-popup-opened",
		VIEW_POPUP_CLOSE : "view-popup-close",
		
		//turn js
		TURNJS_PRESSED_EVENT : "turn-pressed",
		TURNJS_RELEASED_EVENT : "turn-released",
		
		//message
		VIEW_MESSAGE_FADE_TYPE : "addons.message-fade",
		
		//navigation events
		NAV_FADE_ACTION : "addons.navbar-fade-action",
		NAV_MOVE_DISABLE : "addons.navbar-disable",
		
		//toc
		TOC_CREATE : "addons.toc-create",
				
		//pen events
		PEN_MODE_OPEN : "addons.penModeOpen",
		PEN_POPOVER	: "pen.popover",
		
		//memo events
		MEMO_MODE_OPEN : "addons.memoModeOpen",
		MEMO_RESIZEBLE_LOCK	: "memo.resize-lock",

        //stamp events
        STAMP_MODE_OPEN : "addons.stampModeOpen",
        STAMP_RESIZEBLE_LOCK : "stamp.resize-lock",

        //mask events
        MASK_MODE_OPEN : "addons.maskModeOpen",
        MASK_RESIZEBLE_LOCK	: "mask.resize-lock",

        //link events
        LINK_MODE_OPEN : "addons.linkModeOpen",
        LINK_RESIZEBLE_LOCK	: "link.resize-lock",

		//help
		HELP_CREATE : "addons.help-create",

		//crop
		CROP_MODE_OPEN : "addons.crop-mode-open",
		CROP_ORIGINALIMG_CREATE : "addons.crop-originalimg-create",

		//application
		BOOKMARK_UPDATE : "addons.bookmark-update",

		//customtelop
		OPEN_CUSTIMTELOP : "addons.open-customtelop",
		CLOSE_CUSTIMTELOP : "addons.close-customtelop",

		destroy : function(){
			var events = [
				this.VIEW_NAV_AUTOHIDE_CLEAR, this.PAGE_BEFORE_EVENT, this.PAGE_AFTER_EVENT, this.ZOOM_ANIMATION_END, this.ADDONS_RESIZE, this.ADDONE_OPNE_POPUPTEXT, this.VIEW_DESTROY,
				this.VIEW_POPUP_OPEN, this.VIEW_POPUP_OPENED, this.VIEW_POPUP_CLOSE, this.VIEW_THUMB_RESIZE, this.MAKEDISPLAYIMG, this.MAKEITEMDISPLAYIMG,
				this.TURNJS_PRESSED_EVENT, this.TURNJS_RELEASED_EVENT, this.VIEW_MESSAGE_FADE_TYPE, this.NAV_FADE_ACTION, this.NAV_MOVE_DISABLE, this.TOC_CREATE,
				this.PEN_MODE_OPEN, this.PEN_POPOVER, this.MEMO_MODE_OPEN, this.MEMO_RESIZEBLE_LOCK, this.HELP_CREATE, this.CROP_MODE_OPEN, this.CROP_ORIGINALIMG_CREATE,
				this.BOOKMARK_UPDATE, this.OPEN_CUSTIMTELOP, this.CLOSE_CUSTIMTELOP,
				this.STAMP_MODE_OPEN, this.STAMP_RESIZEBLE_LOCK, this.MASK_MODE_OPEN, this.MASK_RESIZEBLE_LOCK,
        		this.LINK_MODE_OPEN, this.LINK_RESIZEBLE_LOCK
			];

			for( var i in  events){
				$(document).unbind(events[i]);
			}

            // setTimeoutイベント解除
            if(viewUtils.Mobile) $(document).off('tap.viewer', '#btn-booktext-search')

            if(ANALYTICS.analyticeTimer) clearTimeout(ANALYTICS.analyticeTimer);
            if(PARAM.autoHideTimer) clearTimeout(PARAM.autoHideTimer);
 
			PARAM.wisebook.off("tap keypress");
			delete viewdefind;
			delete htmlview_defind;
		}
	};
})();
viewdefind = new htmlview_defind();
