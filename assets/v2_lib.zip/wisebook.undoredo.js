(function() {
    wisebookundoredo = function() {
        this.init();
    };

    wisebookundoredo.prototype = {
        list: [],
        currentCursor: -1,
        isRedoUndo: false,
        savePages: [],
        beforePage: 0,
        use: false,

        init: function() {
            this.disableUndo();
            this.disableRedo();
            this.beforePage = PARAM.cover;
        },

        bookmarkSave: function() {
            h5appview.setBoomarkInfo();
        },

        addEvent: function(obj) {
            if(!this.use) return;
            this.resetEventList();

            this.list.push(obj);
            this.currentCursor = this.list.length - 1;

            if (!$('#btn-undo').hasClass('unre-event')) this.enableUndo();
            if ($('#btn-redo').hasClass('unre-event')) this.disableRedo();
        },

        resetEventList: function() {
            var i = this.list.length;
            while (i--) {
                if (this.currentCursor == i) break;
                this.list.splice(i, 1);
            }
        },

        redo: function() {
            var event = this.list[++this.currentCursor];
            this.checkEvent(event, 'redo');

            if (this.currentCursor + 1 > this.list.length - 1)
                this.disableRedo();

            if (!$('#btn-undo').hasClass('unre-event')) this.enableUndo();
        },

        undo: function() {
            var event = this.list[this.currentCursor--];
            this.checkEvent(event, 'undo');

            if (this.currentCursor < 0)
                this.disableUndo();

            if (!$('#btn-redo').hasClass('unre-event')) this.enableRedo();
        },

        revert: function() {
            this.currentCursor--;
            this.list.pop();

            if (this.currentCursor < 0)
                this.disableUndo();
            
            this.disableRedo();
        },

        // saveActionHistory: function() {
        //     if (h5appview.wisebookStorageList.bookmark.siori.length > 0)
        //         h5appview.setBoomarkInfo();
        //
        //     var pagesTemp = [];
        //     wisebookundoredo.list.forEach(function(item) {
        //         if (item.name != 'page' && item.name != 'bookmark') {
        //             if (item.page.length > 1) {
        //                 for (var i in item.page) {
        //                     pagesTemp.push(parseInt(item.page[i]));
        //                 }
        //             } else {
        //                 if (item.page instanceof Array)
        //                     pagesTemp.push(parseInt(item.page[0]));
        //                 else
        //                     pagesTemp.push(parseInt(item.page));
        //             }
        //         }
        //     });
        //
        //     if (pagesTemp.length == 0) {
        //         h5appview.hideView();
        //         return;
        //     }
        //     libStore._loadingImgView('show');
        //
        //     this.savePages = pagesTemp.filter(function(item, pos, self) {
        //         return self.indexOf(item) == pos;
        //     });
        //
        //     for (var page in this.savePages)
        //         h5appview.setStorageAllData(this.savePages[page]);
        // },

        checkEvent: function(event, flag) {
            switch (event.name) {
                case 'bookmark':
                    this.bookmarkEvent(event, flag);
                    break;
                case 'stamp':
                    this.stampEvent(event, flag);
                    break;
                case 'link':
                    this.linkEvent(event, flag);
                    break;
                case 'mask':
                    this.maskEvent(event, flag);
                    break;
                case 'page':
                    this.pageEvent(event, flag);
                    break;
                case 'pen':
                    this.penEvent(event, flag);
                    break;
                case 'memo':
                    this.memoEvent(event, flag);
                    break;
                case 'galleryOrMovie':
                    this.GalleryOrMovieEvent(event, flag);
                    break;
            }
        },

        bookmarkEvent: function(event, flag) {
            var pages = event.page;

            if (flag == 'undo') {
                if (event.event == 'add') this.deleteBookmark(pages);
                else if (event.event == 'remove') this.loadBookmark(pages);
            } else {
                if (event.event == 'add') this.loadBookmark(pages);
                else if (event.event == 'remove') this.deleteBookmark(pages);
            }
        },

        loadBookmark: function(pages) {
            for (var index in pages)
                h5appview.wisebookStorageList.bookmark.siori.push(parseInt(pages[index]));

            h5appview.wisebookStorageList.bookmark.siori.sort(function(a, b) {
                return a - b;
            });
            h5appview.setBoomarkInfo();
        },

        deleteBookmark: function(pages) {
            var storage = h5appview.wisebookStorageList.bookmark.siori;
            for (var s in storage) {
                for (var d in pages) {
                    if (storage[s] == pages[d]) {
                        storage.splice(s, 1);
                        continue;
                    }
                }
            }
            h5appview.setBoomarkInfo();
        },

        linkEvent: function(event, flag) {
            var obj = event.objInfo;

            if (flag == 'undo') {
                if (event.event == 'add') wisebooklink.removeOneLink(obj, true);
                else if (event.event == 'remove') this.loadLink(obj);
            } else {
                if (event.event == 'add') this.loadLink(obj);
                else if (event.event == 'remove') wisebooklink.removeOneLink(obj, true);
            }
        },

        loadLink: function(obj) {
            wisebooklink.storageData[obj.page].linkList.push(obj);
            wisebooklink.loadLink(obj);
            h5appview.setStorageData(obj.page);
        },

        GalleryOrMovieEvent: function(event, flag) {
            var objInfo = event.objInfo;

            if (Object.keys(objInfo).length == 2)
                objInfo = objInfo[flag];

            if (flag == 'undo') {
                if (event.event == 'add') wisebookPhotoAndVideo.removeElemToView(objInfo, true, true);
                else if (event.event == 'remove') this.loadGalleryOrMovie(objInfo);
                else {
                    wisebookPhotoAndVideo.removeElemToView(event.objInfo.redo, true, true, function() {
                        wisebookundoredo.loadGalleryOrMovie(objInfo);
                    });
                }
            } else {
                if (event.event == 'add') this.loadGalleryOrMovie(objInfo);
                else if (event.event == 'remove') wisebookPhotoAndVideo.removeElemToView(objInfo, true, true);
                else {
                    wisebookPhotoAndVideo.removeElemToView(event.objInfo.undo, true, true, function() {
                        wisebookundoredo.loadGalleryOrMovie(objInfo);
                    });
                }
            }
        },

        loadGalleryOrMovie: function(obj) {
            wisebookPhotoAndVideo.storageData[obj.page].pictureList.push(obj);
            wisebookPhotoAndVideo.loadElem(obj);
            h5appview.setStorageData(obj.page);
        },

        penEvent: function(event, flag) {
            wisebookpen.removeCanvasStorageData(true);
            if (flag == 'undo') {
                if (event.event == 'add') {
                    for (var page in event.line) {

                        var seqList = event.line[page].map(function(item) {
                            return item.clickSeq + item.lineSeq;
                        });
                        var undoPenLine = wisebookpen.storageData[page].canvasList.filter(function(item) {
                            return !seqList.includes(item.clickSeq + item.lineSeq);
                        });

                        wisebookpen.storageData[page].canvasList = undoPenLine;
                        h5appview.setStorageData(page);
                    }
                } else if (event.event == 'removeAll') {
                    for (var page in event.line) {
                        wisebookpen.storageData[page].canvasList = event.line[page];
                        h5appview.setStorageData(page);
                    }
                }
            } else {
                if (event.event == 'add') {
                    for (var page in event.line) {
                        wisebookpen.storageData[page].canvasList = wisebookpen.storageData[page].canvasList.concat(event.line[page]);
                        h5appview.setStorageData(page);
                    }
                } else if (event.event == 'removeAll') {
                    for (var page in event.line) {
                        wisebookpen.storageData[page].canvasList = [];
                        h5appview.setStorageData(page);
                    }
                }
            }
            wisebookpen.storageDataToBook();
        },

        maskEvent: function(event, flag) {
            var objInfo = event.objInfo;

            if (Object.keys(objInfo).length == 2)
                objInfo = objInfo[flag];

            if (flag == 'undo') {
                if (event.event == 'add') wisebookmask.removeOneMask(objInfo, true, true, false);
                else if (event.event == 'remove') this.loadMask(objInfo);
                else if (event.event == 'removeAll') {
                    for (var index in objInfo)
                        this.loadMask(objInfo[index]);
                } else {
                    wisebookmask.removeOneMask(event.objInfo.redo, true, true, false, function() {
                        wisebookundoredo.loadMask(objInfo);
                    });
                }
            } else {
                if (event.event == 'add') this.loadMask(objInfo);
                else if (event.event == 'remove') wisebookmask.removeOneMask(objInfo, true, true, false);
                else if (event.event == 'removeAll') wisebookmask.removeAllMask(objInfo);
                else {
                    wisebookmask.removeOneMask(event.objInfo.undo, true, true, false, function() {
                        wisebookundoredo.loadMask(objInfo);
                    });
                }
            }
        },

        loadMask: function(obj) {
            wisebookmask.storageData[obj.page].blindList.push(obj);
            wisebookmask.loadMask(obj);
            h5appview.setStorageData(obj.page);
            wisebookmask.resizableLockMode(false);
        },

        memoEvent: function(event, flag) {
            var objInfo = event.objInfo;

            if (Object.keys(objInfo).length == 2)
                objInfo = objInfo[flag];

            if (flag == 'undo') {
                if (event.event == 'add') wisebookmemo.removeOneMemo(objInfo, true, true, false);
                else if (event.event == 'remove') this.loadMemo(objInfo);
                else if (event.event == 'removeAll') {
                    for (var index in objInfo)
                        this.loadMemo(objInfo[index]);
                } else {
                    wisebookmemo.removeOneMemo(event.objInfo.redo, true, true, false, function() {
                        wisebookundoredo.loadMemo(objInfo);
                    });
                }
            } else {
                if (event.event == 'add') this.loadMemo(objInfo);
                else if (event.event == 'remove') wisebookmemo.removeOneMemo(objInfo, true, true, false);
                else if (event.event == 'removeAll') wisebookmemo.removeAllMemo(objInfo);
                else {
                    wisebookmemo.removeOneMemo(event.objInfo.undo, true, true, false, function() {
                        wisebookundoredo.loadMemo(objInfo);
                    });
                }
            }
        },

        loadMemo: function(obj) {
            wisebookmemo.storageData[obj.page].memoList.push(obj);
            wisebookmemo.loadMemo(obj);
            h5appview.setStorageData(obj.page);
        },

        pageEvent: function(event, flag) {
            htmlview.gotopageUndoRedo(event[flag]);
        },

        addPage: function(redo, undo) {
            if(!this.use) return;
            this.addEvent({
                'name': 'page',
                'redo': redo,
                'undo': undo
            });
        },

        stampEvent: function(event, flag) {
            var obj = event.objInfo;

            if (flag == 'undo') {
                if (event.event == 'add') wisebookstamp.removeOneStamp(obj, true, true, false);
                else if (event.event == 'remove') this.loadStamp(obj);
                else if (event.event == 'removeAll') {
                    for (var index in obj)
                        this.loadStamp(obj[index]);
                }
            } else {
                if (event.event == 'add') this.loadStamp(obj);
                else if (event.event == 'remove') wisebookstamp.removeOneStamp(obj, true, true, false);
                else if (event.event == 'removeAll') wisebookstamp.removeAllStamp(obj);
            }
        },

        getEventLength: function(name) {
            var length = 0;
            for (var index in wisebookundoredo.list)
                if (wisebookundoredo.list[index].name == name)
                    length++;

            return length;
        },

        loadStamp: function(obj) {
            wisebookstamp.storageData[obj.page].stampList.push(obj);
            wisebookstamp.loadStamp(obj);
            h5appview.setStorageData(obj.page);
        },

        disableUndo: function() {
            $('#btn-undo').removeClass('unre-event');
            $('#btn-undo').find('.view-icon').css('color', 'gray');
        },

        disableRedo: function() {
            $('#btn-redo').removeClass('unre-event');
            $('#btn-redo').find('.view-icon').css('color', 'gray');
        },

        enableUndo: function() {
            $('#btn-undo').addClass('unre-event');
            $('#btn-undo').find('.view-icon').css('color', 'white');
        },

        enableRedo: function() {
            $('#btn-redo').addClass('unre-event');
            $('#btn-redo').find('.view-icon').css('color', 'white');
        }
    };
})();
