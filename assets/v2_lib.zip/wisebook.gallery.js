(function() {
    wisebookPhotoAndVideo = function() {
        this.init();
    };

    wisebookPhotoAndVideo.prototype = {
        customModeSpace: null,
        selectedPage: null,
        fileList: null,
        pageWidth: 0,
        pageHeight: 0,
        isFalse: false,
        isGallery: false,
        storageData: null,
        imageDefaultsize: null,
        isRightPage: false,
        imageSwiper: null,

        init: function() {
            this.imageDefaultsize = viewUtils.Mobile ? 30 : 40;
            this.imageDefaultsize = this.imageDefaultsize / PARAM.spaceScale;
            this.storageData = h5appview.wisebookStorageList.pages;
            this.customModeSpace = $('.custom-space');
            this.selectedPage = PARAM.currentpage;
            this.loadElemToView();
            this.commonEvent();
            this.initImageSwiper();
        },

        commonEvent: function() {
            var that = this;

            $(document).on(viewdefind.TURNJS_PRESSED_EVENT, function() {
                that.customModeSpace.find('.attach_gallery').remove();
                that.customModeSpace.find('.attach_video').remove();
            });

            $(document).on(viewdefind.TURNJS_RELEASED_EVENT, function() {
                that.refresh();
            });

            $(document).on(viewdefind.PAGE_BEFORE_EVENT, function() {
                that.customModeSpace.html('');
                that.customModeSpace.find('.attach_gallery').remove();
                that.customModeSpace.find('.attach_video').remove();
            });

            $(document).on(viewdefind.PAGE_AFTER_EVENT, function() {
                that.refresh();
            });

            $(document).on(viewdefind.VIEW_DESTROY, function() {
                console.log('VIEW_DESTROY');
            });

            $(document).on(viewdefind.ADDONS_RESIZE, function() {
                that.refresh();
            });

            $('#tool_photopopup_close').on('click',function(){
                $('#tool_photopopup').hide();
                $('.swiper-wrapper').empty();
            });
        },

        initImageSwiper: function() {
            this.imageSwiper = new Swiper ('.swiper-container', {
                loop: true,
                pagination: '.swiper-pagination',
                nextButton: '.swiper-button-next',
                prevButton: '.swiper-button-prev'
            });
        },

        setPageInfo: function(page) {
            this.selectedPage = page;
            var viewPage = htmlview.domDisplay[page];

            if (PARAM.orient == 'landscape') {
                this.pageWidth = PARAM.imageWidth;
                this.pageHeight = PARAM.imageHeight;

                if (PARAM.side.left == 0 || PARAM.side.right == 0) {
                    this.isRightPage = false;
                } else {
                    this.isRightPage = PARAM.side.right == page ? true : false;
                }
            } else {
                this.pageWidth = viewPage.width();
                this.pageHeight = viewPage.height();
            }
        },

        refresh: function() {
            this.loadElemToView();
        },

        createPhotoOrVideoImage: function() {
            var x, y;

            var tempImageDefaultsize = this.imageDefaultsize;

            if (PARAM.orient != 'landscape') {
                tempImageDefaultsize = this.imageDefaultsize * PARAM.spaceScale;
            }

            if (PARAM.orient == 'landscape') {
                var speratorPage = PARAM.side.view.length * 2;
                x = this.pageWidth / speratorPage - Math.ceil(tempImageDefaultsize * PARAM.spaceScale) / 2;
                y = this.pageHeight / 2 - Math.ceil(tempImageDefaultsize * PARAM.spaceScale) / 2;
            } else {
                x = (this.pageWidth / 2) - (tempImageDefaultsize / 2) / PARAM.transformInfo.scale;
                y = (this.pageHeight / 2) - (tempImageDefaultsize / 2) / PARAM.transformInfo.scale;
            }

            var page = PARAM.getUserFullPositionPage(x);

            var lookPosData = PARAM.getActualPosByLookPos(x, y, tempImageDefaultsize, tempImageDefaultsize);

            x = lookPosData.x;
            y = lookPosData.y;

            if (this.isRightPage)
                page = this.selectedPage;

            var elemInfo = {
                uniqid: PARAM.uniqID(),
                className: this.isGallery ? 'attach_gallery' : 'attach_video',
                page: page,
                x: x,
                y: y,
                fileList: this.fileList,
                type: this.isGallery ? 'gallery' : 'video',
                image: this.isGallery ? 'suken_photo.png' : 'suken_video.png',
                w: this.imageDefaultsize,
                h: this.imageDefaultsize,
                miniStatus: 0
            };

            var objCopy = JSON.parse(JSON.stringify(elemInfo));
            wisebookundoredo.addEvent({
                'name': 'galleryOrMovie',
                'objInfo': objCopy,
                'event': 'add',
                'page': objCopy.page
            });

            this.saveEventInfo(elemInfo);
            this.loadElem(elemInfo);
        },

        loadElem: function(elemInfo) {
            var position = this.getImageLocation(elemInfo);

            if(viewUtils.Mobile){
                if(PARAM.viewMode != 'twopage' && elemInfo.page != PARAM.currentpage) return;
            }

            var elem = $('<div />', {
                'id': elemInfo.uniqid,
                'class': elemInfo.className,
                'css': {
                    left: position.x,
                    top: position.y,
                    width: Math.ceil(elemInfo.w * PARAM.spaceScale),
                    height: Math.ceil(elemInfo.h * PARAM.spaceScale),
                    position: 'absolute'
                },
                'type': elemInfo.type,
                'page': elemInfo.page
            }).data('objInfo', elemInfo);

            $('<img />', {
                'class': 'mainImage',
                'src': viewPath + 'v2_images/tool_common/' + elemInfo.image,
                'css': {
                    width: Math.ceil(elemInfo.w * PARAM.spaceScale),
                    height: Math.ceil(elemInfo.h * PARAM.spaceScale),
                    position: 'absolute',
                    'max-width': '100%',
                    'max-height': '100%'
                },
            }).appendTo(elem);

            $('<img />', {
                'class': 'deleteImage',
                'src': viewPath + 'v2_images/tool_common/' + 'btn_delete.png',
                'css': {
                    position: 'absolute',
                    width: Math.ceil(elemInfo.w * PARAM.spaceScale) / 1.5,
                    height: Math.ceil(elemInfo.h * PARAM.spaceScale) / 1.5,
                    display: 'none',
                    'margin-top': viewUtils.Mobile ? -7 : -10,
                    'margin-left': viewUtils.Mobile ? -3.5 : -5
                }
            }).appendTo(elem);

            this.addElemToPage(elem);

            if(PARAM.viewMode == 'twopage' && viewUtils.Mobile){
                this.setActionEvent(elemInfo.uniqid);
            }else{
                this.addEvent(elemInfo.uniqid);
            }
        },

        addElemToPage: function(elem) {
            this.customModeSpace.append(elem);
        },

        saveEventInfo: function(obj) {
            this.storageData[obj.page].pictureList.push(obj);
            h5appview.setStorageData(obj.page);
        },

        getImageLocation: function(obj) {
            var actualpos = PARAM.getLookPosByActualPos(obj.x, obj.y, obj.w, obj.h);
            actualpos.w = Math.max(actualpos.w, this.imageDefaultsize);
            actualpos.h = Math.max(actualpos.h, this.imageDefaultsize);

            if(viewUtils.Mobile){
                if(PARAM.viewMode == 'twopage'){
                    if (PARAM.side.right == obj.page && PARAM.bookInfo.config.single == 0 && PARAM.side.left != 0) {
                        actualpos.x += PARAM.side.rightstartx;
                    }
                }
            }else{
                if (PARAM.side.right == obj.page && PARAM.bookInfo.config.single == 0 && PARAM.side.left != 0) {
                    actualpos.x += PARAM.side.rightstartx;
                }
            }
            return actualpos;
        },

        updateEventInfo: function(obj) {
            var items = this.storageData[obj.page].pictureList;
            for (var i in items) {
                var item = items[i];
                if (item.uniqid == obj.uniqid) {
                    this.storageData[obj.page].pictureList.splice(i, 1);
                    this.storageData[obj.page].pictureList.push(obj);
                    h5appview.setStorageData(obj.page);
                    break;
                }
            }
        },

        loadElemToView: function() {
            if (PARAM.viewMode == "twopage") {
                for (var v in PARAM.side.view) {
                    var page = PARAM.side.view[v];
                    if (page == 0) continue;

                    var items = this.storageData[page].pictureList;
                    if (items <= 0) continue;

                    for (var i in items) {
                        var item = items[i];
                        if ($('#' + item.uniqid).length > 0) continue;

                        this.loadElem(item);
                    }
                }
            } else {
                if (PARAM.bookInfo.config.single == 0) {

                    var pointnum = PARAM.getPointnum(PARAM.currentpage),
                        leftpage = PARAM.doublePair[pointnum].left,
                        rightpage = PARAM.doublePair[pointnum].right;

                    if (leftpage !== 0) {
                        var items = this.storageData[leftpage].pictureList;
                        for (var i in items) {
                            var item = items[i];
                            if ($('#' + item.uniqid).length > 0) continue;

                            this.loadElem(item);
                        }
                    }
                    if (rightpage != 0) {
                        var items = this.storageData[rightpage].pictureList;

                        for (var i in items) {
                            var item = items[i];

                            if ($('#' + item.uniqid).length > 0) continue;
                            this.loadElem(item);
                        }
                    }

                } else {
                    var items = this.storageData[PARAM.currentpage].pictureList;
                    for (var i in items) {
                        var item = items[i];
                        if ($('#' + item.uniqid).length > 0) continue;

                        this.loadElem(item);
                    }
                }
            }
        },

        removeElemToView: function(obj, removeFlag, isUndoRedo, callback) {
            for (var key in this.storageData[obj.page].pictureList) {
                var item = this.storageData[obj.page].pictureList[key];
                if (item.uniqid == obj.uniqid) {
                    this.storageData[obj.page].pictureList.splice(key, 1);
                    // if(removeFlag){
                    // 	if(!viewUtils.Mobile) $('#'+obj.uniqid).draggable('destroy').resizable('destroy').remove();
                    // 	else $('#'+obj.uniqid).remove();
                    // }

                    if (!isUndoRedo) {
                        wisebookundoredo.addEvent({
                            'name': 'galleryOrMovie',
                            'objInfo': obj,
                            'event': 'remove',
                            'page': obj.page
                        });
                    }

                    h5appview.setStorageData(obj.page);
                    break;
                }
            }
            if ($('#' + obj.uniqid).length > 0 && removeFlag) $('#' + obj.uniqid).draggable('destroy').remove();
            if (callback) callback();
        },

        addEvent: function(uniqId) {
            var that = this;
            var item = $('#' + uniqId);

            item.draggable({
                create: function() {},
                start: function() {
                    PARAM.isNaviMove = false;
                    $(this).draggable("option", "revert", false);

                    var undoCopy = JSON.parse(JSON.stringify($(this).data('objInfo')));
                    wisebookundoredo.addEvent({
                        'name': 'galleryOrMovie',
                        'objInfo': {
                            'undo': undoCopy,
                            'redo': null
                        },
                        'event': 'change',
                        'page': undoCopy.page
                    });
                },
                drag: function(e, ui) {
                    that.isFalse = false;

                    ui.position.top = Math.round(ui.position.top / PARAM.transformInfo.scale);
                    ui.position.left = Math.round(ui.position.left / PARAM.transformInfo.scale);

                    var page = $(this).data('objInfo').page,
                        this_x = ui.position.left,
                        this_y = ui.position.top,
                        this_max_x = $(this).width() + ui.position.left,
                        this_max_y = $(this).height() + ui.position.top,
                        min_x = PARAM.userModeInfo.x,
                        max_x = PARAM.userModeInfo.w,
                        max_y = PARAM.userModeInfo.h;

                    if (PARAM.side.right == page && PARAM.viewMode == 'twopage' && PARAM.side.left == 0) {
                        min_x = 0;
                    }

                    //min
                    if (min_x > this_x) {
                        that.isFalse = true;
                        $(this).draggable("option", "revert", true);
                    }

                    if (PARAM.userModeInfo.y > this_y) {
                        that.isFalse = true;
                        $(this).draggable("option", "revert", true);
                    }

                    //max
                    if (max_x < this_max_x) {
                        that.isFalse = true;
                        $(this).draggable("option", "revert", true);
                    }
                    if (max_y < this_max_y) {
                        that.isFalse = true;
                        $(this).draggable("option", "revert", true);
                    }
                },
                stop: function(e, ui) {
                    if (that.isFalse == false) {
                        var objInfo = JSON.parse(JSON.stringify($(this).data('objInfo'))),
                            this_x = ui.position.left,
                            this_y = ui.position.top,
                            this_w = $(this).outerWidth(true),
                            this_h = $(this).outerHeight(true);

                        var selectPage = PARAM.getUserFullPositionPage(this_x);
                        if (selectPage != objInfo.page) {
                            that.removeElemToView(objInfo, false, true);
                            objInfo.page = selectPage;
                            that.storageData[selectPage].pictureList.push(objInfo);
                            h5appview.setStorageData(selectPage);
                        }

                        if(!viewUtils.Mobile){
                            if (PARAM.side.right == selectPage && PARAM.bookInfo.config.single == 0 && PARAM.side.left != 0) {
                                this_x -= PARAM.side.rightstartx;
                            }
                        }

                        var lookPosData = PARAM.getActualPosByLookPos(this_x, this_y, this_h, this_w);

                        objInfo.x = lookPosData.x;
                        objInfo.y = lookPosData.y;

                        if(wisebookundoredo.use){
                            wisebookundoredo.list[wisebookundoredo.list.length - 1].objInfo.redo = objInfo;
                            wisebookundoredo.list[wisebookundoredo.list.length - 1].page = objInfo.page;
                        }

                        that.updateEventInfo(objInfo);
                        $(this).data('objInfo', objInfo);
                    }else{
                        if(wisebookundoredo.use) wisebookundoredo.revert();
                    }
                    setTimeout(function() {
                        PARAM.isNaviMove = true;
                    }, 50);
                }
            });

            this.setActionEvent(item);
        },

        setActionEvent: function(item){
            var that = this;
            item.on('tap', function() {
                if ($(this).attr('deleteReady') == 'on') {
                    $(this).attr('deleteReady', 'off');
                    $(this).find('.deleteImage').css('display', "none");
                    $(this).draggable('disable');
                } else {
                    if ($(this).attr('type') == 'gallery') that.showImageSlider($(this).data('objInfo').fileList);
                    else wisebookjplayer.setVideo($(this).data('objInfo').fileList);
                }
            });
            item.on('hold', function() {
                if (!PARAM.isZoom && typeof($(this).attr('deleteReady')) === 'undefined' || $(this).attr('deleteReady') == 'off') {
                    $(this).attr('deleteReady', 'on');
                    $(this).find('.deleteImage').css('display', "block");
                    $(this).draggable("enable");
                }
            });
            item.find('.deleteImage').on('tap', function() {
                var objInfo = $(this).parent().data('objInfo');
                viewMessageProc.confirm('', '削除しますか？', function() {
                    that.removeElemToView(objInfo, true, false);
                });
            });
            item.draggable('disable');
        },

        showImageSlider : function(filePaths){
            var that = this;
            $('#tool_photopopup').show();
            
            var html = '';
            for(var index in filePaths){ 
                html = html + '<div class="swiper-slide"><div class="swiper-zoom-container"><img src="' + filePaths[index] + '"></div></div>'; 
            }

            $.when($('.swiper-wrapper').append(html)).then(function(){
                $('.swiper-container').css('z-index', 100000);
                $('.swiper-slide').css('background', 'black');
                that.imageSwiper.init();
            });
        }
    };
})();
