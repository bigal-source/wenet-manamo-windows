#/bin/sh
# Requires Closure Compiler Application
# https://developers.google.com/closure/compiler/docs/gettingstarted_app

# --compilation_level ADVANCED_OPTIMIZATIONS 

SCRIPTS=("app_viewer" "htmlview_defind" "htmlview_options" "htmlview" "jquery.wisebookPrint.canvas" "viewerUtils" "wisebook.memo" "wisebook.pen" "wisebook.crop")
SCRIPTS_LEN=${#SCRIPTS[@]}
SCRIPTS_COMMENT="/* wisebook | Copyright (c) 2015 Copyright © 2015 Kovec, Inc. All rights reserved. */"

echo -e "${SCRIPTS_COMMENT}\n" > comment.js

#if [ ! -f /tmp/compiler.jar ];
#then
#	echo "Downloading Google Closure Compiler..."
#	curl --silent -L http://dl.google.com/closure-compiler/compiler-latest.zip > /tmp/compiler-latest.zip
#	unzip  -o /tmp/compiler-latest.zip -d /tmp
#	rm /tmp/compiler-latest.zip
#	chmod +x /tmp/compiler.jar
#fi

#	echo "Making Minimized files..."

for (( i=0; i<${SCRIPTS_LEN}; i++ ));
do
	java -jar "/home/wisebook/public_html4/vars/cache/compiler.jar" --js ${SCRIPTS[$i]}.js > ${SCRIPTS[$i]}.closure.js

	cat comment.js ${SCRIPTS[$i]}.closure.js  > ${SCRIPTS[$i]}.min.js 

	rm ${SCRIPTS[$i]}.closure.js

	m=$(ls -la ${SCRIPTS[$i]}.min.js | awk '{ print $5}')
	gzip -nfc --best ${SCRIPTS[$i]}.min.js > ${SCRIPTS[$i]}.min.js.gz
	g=$(ls -la ${SCRIPTS[$i]}.min.js.gz | awk '{ print $5}')
	echo " ${SCRIPTS[$i]}.js: $m bytes minified, $g bytes gzipped"

	rm ${SCRIPTS[$i]}.min.js.gz
    mv ${SCRIPTS[$i]}.min.js ../../h5/v2_lib/
    
	if [ "--test" == "$1" ]; then
		rm ${SCRIPTS[$i]}.min.js
	fi

done

rm comment.js