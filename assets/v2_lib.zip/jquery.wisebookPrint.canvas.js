(function(){
	wisebookPrint = function(options){
		if( viewUtils.browser == 'msie' || viewUtils.browser == 'edge' ) this.printCss = viewPath+'v2_css/print/printer_ie9more.css';
		else if(viewUtils.browser == 'safari') this.printCss = viewPath+'v2_css/print/printer_safari.css?'+ new Date().getTime();
		else this.printCss = viewPath+'v2_css/print/print.css';
		
    	$.extend(this.op, options);
	};
	
wisebookPrint.prototype = {
    printCss : null,
    op : {
        printMode : null,
        popHt   : $(window).innerHeight(),
		popWd   : $(window).innerWidth()-400,
		popX    : 150,
		popY    : 50,
		popTitle    : '',
        popClose: true
    },
    originalParts : { zoom : "", width : 0, height : 0, list : [] },
    originalTotalSize : {
        width : 0,
        height : 0
    },
    printInfo : {
        dir : "", //both, single
        page : "" 
    },
    
    writeDoc : null,
    printWindow : null,
    
    startPrinter : function(info){
        $("#printIframe").remove();
        
        this.originalImgZoom = ( PARAM.zoominfo["200"].enable ) ? "200" : "100";
        this.printInfo.dir = ( info.pageList.length == 2 ) ? "both" : "single";
        
        if( this.printInfo.page != info.pageList ){
            this.printInfo.page = info.pageList;
            this.originalimgCreate();
        }else{
            this.originalImgToPrinter();
        }

        ADDONS.loadingImgView('none');
    },
    
    originalimgCreate : function(){
        var that = this, canvasElem,
            originalsize = { width : 0, height : PARAM.zoominfo[this.originalImgZoom].height},
            elementArr = [];
            
        if( this.printInfo.dir == "both" ){
            //見開き
            for( var i in PARAM.side.view ){
                var page = PARAM.side.view[i];
                if( page <= 0 ) continue;
                
                var pageObj = htmlview._pages[page - 1],
                    img = ( this.originalImgZoom == "100" ) ? pageObj.image[0].srcList : pageObj.image[1].srcList;
                
                if( img.length != this.originalParts.list.length ) {
                    this.originalPartData(this.originalImgZoom);
                }
                
                elementArr.push( this.makeOriginaldata(pageObj, img, originalsize.width) );
                originalsize.width += PARAM.zoominfo[this.originalImgZoom].width;
            }
        }else{
            //単ページ
            
            var pageObj = htmlview._pages[this.printInfo.page - 1],
                img = ( this.originalImgZoom == "100" ) ? pageObj.image[0].srcList : pageObj.image[1].srcList;
            
            if( img.length != this.originalParts.list.length ) {
                this.originalPartData(this.originalImgZoom);
            }
            elementArr.push( this.makeOriginaldata(pageObj, img, 0) );
            originalsize.width = PARAM.zoominfo[this.originalImgZoom].width;
        }
        
        this.originalTotalSize = originalsize;
        
        var tempIframe = this.createIframe("printer-tmp-element");
        var html = this.docType() + "<html><haed></haed>" + this.setBody() + "</html>";
        tempIframe.write( html );
        canvasElem = tempIframe.getElementById('printer-canvas-image-body');
        canvasElem = $(canvasElem);
        
        elementArr.forEach(function(elem){
            canvasElem.append(elem);
        });
        
        html2canvas( canvasElem[0], {
            letterRendering : true,
			allowTaint : true,
			width 	: originalsize.width,
			height 	: originalsize.height
        }).then(function(canvas){
            that.originalImg = canvas.toDataURL("image/jpeg");
            
            if( that.printInfo.dir == "both" ){
                var img = new Image();
                img.onload = function(){
                    canvasElem.html(canvas);
                    
                    //回転作業
                    var imgCanvas = canvasElem.find("canvas"),
                        ctx = imgCanvas[0].getContext('2d');
                    ctx.clearRect(0, 0, originalsize.width, originalsize.height);
                    //크기 재지정
                    imgCanvas.attr({width : originalsize.height, height : originalsize.width });
                    ctx.translate(originalsize.height/2, originalsize.width/2);
                    //현재의 canvas회전
                    ctx.rotate( 90 * Math.PI / 180 );
                    //원재 이미지를 0점좌표로 이동
                    ctx.translate( -1 * originalsize.width/2, -1 * originalsize.height/2 );
                            
                    ctx.drawImage(img, 0, 0);
                    //이미지 재저장
                    that.originalImg = imgCanvas[0].toDataURL("image/jpeg");
                    //window.open(that.originalImg);
                    $('#printer-tmp-element').remove();
                    var tem_w = that.originalTotalSize.width;
                    that.originalTotalSize.width = originalsize.height;
                    that.originalTotalSize.height = tem_w;
                    
                    that.originalImgToPrinter();
                };
                img.src = that.originalImg;
                
            }else{
                that.originalImgToPrinter();
                $('#printer-tmp-element').remove();
            }
        });
    },
    
    originalImgToPrinter : function(){
        var that = this;
        
        switch ( this.op.printMode ){
            case "iframe" :
                this.writeDoc = this.createIframe("printIframe");                
            break;
            case "popup" :
                this.printWindow =  this.createWindowPopup();
				this.writeDoc = this.printWindow.doc;
            break;
        }
        var html = this.docType() + "<html>" + this.setHead() + this.setPrintBody() + "</html>";
        this.writeDoc.open();
        
        this.writeDoc.write( html );
        
		$(this.writeDoc).ready(function(){
		    var $imgTag = $(that.writeDoc).contents().find('#printImg');
            
            if( viewUtils.browser == 'msie' || viewUtils.browser == 'edge' ){
                that.completePrint($imgTag);
            }else{
                $imgTag.bind("load", function(){
                    that.completePrint( $(this) );
                    $(this).unbind("load");
                });
            }   
		});
		
		
    },
    
    completePrint : function( imgTag ){
        var that = this;
        var ratioImg = this.imageFitRetWidthHeight(imgTag.width(), imgTag.height(), this.originalTotalSize.width, this.originalTotalSize.height);
        imgTag.css({width:ratioImg.width, height:ratioImg.height});
        
        //setTimeout(function(){
            that.writeDoc.close();
            that.printWindow.print();
            if( viewUtils.device == 'pc' && that.op.printMode == "iframe" ) {
            	$("#printIframe").remove();
            	that.destroy();
            }
            
            if ( that.op.printMode == "popup" && that.op.popClose ) {
                that.printWindow.close();
                that.destroy();
            }
        //}, 0);
    },
    
    createIframe : function(iframeid){
		try{
		    var iframeStyle = 'border:0;position:absolute;left:0px;top:0px;opacity:0;z-index:-1;';
			var iframe = document.createElement('iframe');
            document.body.appendChild(iframe);
            $(iframe).attr({ style: iframeStyle, id:iframeid});
            iframe.doc = null;
            iframe.doc = iframe.contentDocument ? iframe.contentDocument : ( iframe.contentWindow ? iframe.contentWindow.document : iframe.document);
		}catch(e){ throw e + ". iframes may not be supported in this browser."; }
		
		this.printWindow = iframe.contentWindow || iframe;
		return iframe.doc;
	},
	
	createWindowPopup : function(){
        var windowAttr = "location=no,statusbar=no,directories=no,menubar=no,titlebar=no,toolbar=no,dependent=no";
			windowAttr += ",width=" + this.op.popWd + ",height=" + this.op.popHt;
			windowAttr += ",resizable=yes,screenX=" + this.op.popX + ",screenY=" + this.op.popY + ",personalbar=no,scrollbars=yes";
		
		var newWin = window.open( "about:blank", "_blank",  windowAttr );
		newWin.doc = newWin.document;
		
		return newWin;
    },
	
	docType : function(){
		return '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">';
	},
	
	setHead : function(){
        var head = '<head><title>' + this.op.popTitle + '</title>';		
		head += '<link href="'+this.printCss+'" rel="stylesheet" type="text/css" />';
		head += '</head>';
		
		return head;
	},
	
	setBody : function(){
		return  '<body style="margin: 0;padding: 0;">'+
					'<div id="printer-canvas-image-body" style="width:'+this.originalTotalSize.width+'px;height:'+this.originalTotalSize.height+'px;top:0px;left:0px;position: absolute;"/>'+
				'</body>';
	},
	
	setPrintBody : function(){
        var body_tag = '<body><center id="printContents"><img id="printImg" src="'+this.originalImg+'"/></center></body>';
		if(viewUtils.browser == 'safari') body_tag =  '<body><img id="printImg" src="'+this.originalImg+'" width="724" height="850"/></body>';
		return body_tag;
	},
    
    originalPartData : function(zoomvalue, index){
        var page = ( index ) ? htmlview._pages[index] : htmlview._pages[0],
			img, dataPageImgWidth=0, dataPageImgHeight=0;
        
        if( zoomvalue == "200" ){
			dataPageImgWidth = page.image[1].width;
			dataPageImgHeight = page.image[1].height;
			imageWidth = PARAM.zoominfo['200'].width;
			imageHeight = PARAM.zoominfo['200'].height;
			img = page.image[1].srcList;
		}else{
			dataPageImgWidth = page.image[0].width;
			dataPageImgHeight = page.image[0].height;
			imageWidth = PARAM.zoominfo['100'].width;
			imageHeight = PARAM.zoominfo['100'].height;
			img = page.image[0].srcList;
		}
        
        this.originalParts.list = [];
        
		$.extend( this.originalParts, { zoom : zoomvalue, width: dataPageImgWidth, height: dataPageImgHeight } );
		
		var w=0,h=0,x=0,y=0,total=0;
		
		for(var i = 0; i < img.length;i++ ) {
			w = img[i].width;
			h = img[i].height;
			total += w;
			var pos = {
				x : x,
				y : y,
				width : w,
				height : h
			};
			
			this.originalParts.list.push(pos)
			
			if(img.length != 1) {
				if(total >= imageWidth) {
					x = 0;
					y += h;
					total = 0;
				} else {
					x += w;
				}
			}
		} //for end			
    },
    
    makeOriginaldata : function(pageObj, img, leftx){
        var x=0, y=0, w=0, h=0,
            width = this.originalParts.width,
            height = this.originalParts.height,
            parts = this.originalParts.list;
		
		var bgimage = [];
		var bgsize = [];
		var bgposition = [];
		var bgrepeat = [];
		
		for(var i = 0;i < parts.length;i++ ) {
			if(i == 0) {
				x = parts[i].x;
				if(x != 0) {
					start = parts[i].x;
				} else {
					start = 0;
				}
				y = parts[i].y;
			}
            
            bgimage.push( "url(" + viewInfo.bookurl + pageObj.number + "/" + img[i].src + ")" );
            bgposition.push( parts[i].x + "px" + " " + parts[i].y + "px" );
            bgsize.push( parts[i].width + "px" + " " + parts[i].height + "px" );
            bgrepeat.push( "no-repeat" );
		}

        var tmpDom = document.createElement('div');
		var cssObject = new Object();
		cssObject["position"] = "absolute";
		cssObject["width"] = width;
		cssObject["height"] = height;
		cssObject["left"] = leftx;
		cssObject["top"] = 0;
		cssObject["display"] = "block";
		cssObject["background-image"] = bgimage.join(",");
		cssObject["background-repeat"] = bgrepeat.join(",");
		cssObject["background-position"] = bgposition.join(",");
		cssObject["background-size"] = bgsize.join(",");
		
		return $(tmpDom).css(cssObject);
    },
    
    imageFitRetWidthHeight : function(wrapWidth, wrapHeight, imgWidth, imgHeight) {		
		var maxWidth = wrapWidth; 
		var maxHeight = wrapHeight;
		var ratio = 0;  
		var width = imgWidth;
		var height = imgHeight;
		var ret_width = width;
		var ret_height = height;

		// Check if the current width is larger than the max
		if(width > maxWidth){
			ratio = maxWidth / width;   // get ratio for scaling image
			ret_width = maxWidth; // Set new width
			ret_height = height * ratio;  // Scale height based on ratio

			height = height * ratio;    // Reset height to match scaled image
		}   

		var width = ret_width;;
		var height = ret_height;

		// Check if current height is larger than max
		if(height > maxHeight){
			ratio = maxHeight / height; // get ratio for scaling image
			ret_height = maxHeight;
			ret_width = width * ratio;    // Scale width based on ratio
			width = width * ratio;    // Reset width to match scaled image
		}   

		var img_sizes = {'width': Math.floor(ret_width), 'height' :Math.floor(ret_height)}; 
		return img_sizes;
	},
    
    destroy : function(){
        this.writeDoc = null;
        this.printWindow = null;
    }
}

window.wisebookPrint = wisebookPrint;
})();
