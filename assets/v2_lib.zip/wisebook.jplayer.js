 (function() {

    wisebookjplayer = function() {
        this.init();
    };

    wisebookjplayer.prototype = {
        audioPlayer: null,
        videoPlayer: null,
        playList: [],
        audioControlBar: null,
        audioContainer: null,
        currentTrack: null,
        isPlayAll: false,
        isShowingList: false,

        init: function() {
            this.initAudioPlayer();
            this.initAudioEvent();
            this.initVideoEvent();
            this.checkAutoPlay();
        },

        checkAutoPlay: function() {
            for(var pageIndex in PARAM.side.view){
                if(PARAM.side.view[pageIndex] === 0) continue;

                var tempPage = PARAM.side.view[pageIndex];
                var page = htmlview._pages[tempPage - 1];
                
                for(var i in page.items){
                    var item = page.items[i];

                    if(item.action.autoplay !== undefined && item.action.autoplay === 1){
                        if(item.action.name == "video"){
                            if(item.action.playerType != "embed")
                                this.setVideo(viewInfo.bookurl + item.action.filepath);
                        }else if(item.action.name == "audio"){
                            this.setPlayList(item);
                        }
                        ANALYTICS._sendMediaAnalytics(item.action.name, item.action.filepath, page.countpage);
                        break;
                    }
                }
            }
        },

        // video

        initVideoEvent: function() {
            var that = this;
            this.videoPlayer = $('#videoPlayer');

            this.videoPlayer.on('tap', function(){
                if(viewUtils.browser == 'chrome'){
                    that.videoPlayer[0].pause();
                }
            });

            this.videoPlayer[0].addEventListener('webkitendfullscreen', function () { 
                that.closeVideo();
            });

            this.videoPlayer[0].addEventListener('ended', function () { 
                that.videoPlayer[0].webkitExitFullScreen();
                that.closeVideo();
            });

            if(viewUtils.browser == 'chrome'){
                $('#closeVideo').show();
                $('#closeVideo').on('tap', function(){
                    that.videoPlayer[0].webkitExitFullScreen();
                    that.closeVideo();
                });
            }
        },

        playVideo: function() {
            this.audioPlayer.pause();
            this.videoPlayer[0].load();
            this.videoPlayer[0].play();

            if(viewUtils.browser != 'chrome')
                this.videoPlayer[0].webkitEnterFullScreen();
        },

        setVideo : function(filepath){
            if (!PARAM.wisebookToobarNavigater.hasClass('view-toolbar-hidden'))
                ADDONS.viewNavContainerAction('hide');

            $('#videoSource').attr('src', filepath);
            $('#videoContainer').show();
            this.playVideo();
        },

        closeVideo: function() {      
            if(!this.videoPlayer[0].paused) this.videoPlayer[0].pause();
            $('#videoContainer').hide();
        },

        // audio

        initAudioPlayer: function(){
            var that = this;

            if(viewUtils.Mobile){
                $('#jp-progress-slider').after('<a class="audio-duration"><div class="jp-current-time"></div><div class="jp-duration"></div></a>');
            }else{
                $('#jp-progress-slider').before('<a class="audio-current-time"><div class="jp-current-time"></div></a>');
                $('#jp-progress-slider').after('<a class="audio-duration"><div class="jp-duration"></div></a>');
            }

            this.audioControlBar = $('#view-controlbar-audio');
            var ignore_timeupdate;
            var cssSelector = {
                jPlayer: "#jquery_jplayer_1",
                cssSelectorAncestor: "#jp_container_1"
            };

            var myControl = {
                progress: $(cssSelector.cssSelectorAncestor + " .jp-progress-slider"),
                volume: $(cssSelector.cssSelectorAncestor + " .jp-volume-slider")
            };

            var playlist = [];
            var options = {
                swfPath: ".",
                supplied: "mp3",
                wmode: "window",
                timeupdate: function(event) {
                    if (!ignore_timeupdate) {
                        myControl.progress.slider("value", event.jPlayer.status.currentPercentAbsolute);
                    }
                },
                ready: function(event) {
                    fixFlash_mp4 = event.jPlayer.flash.used && /m4a|m4v/.test(event.jPlayer.options.supplied);
                },
                play: function() {
                    that.currentTrack = that.audioPlayer.current;
                    that.changePlaylist(that.currentTrack);
                }
            };

            this.audioPlayer = new jPlayerPlaylist(cssSelector, playlist, options);
            var jPlayer = $(cssSelector.jPlayer);
            var myPlayerData = jPlayer.data("jPlayer");

            myControl.progress.slider({
                animate: "fast",
                max: 100,
                range: "min",
                step: 0.1,
                value: 0,
                slide: function(event, ui) {
                    var sp = myPlayerData.status.seekPercent;
                    if (sp > 0) {
                        // Apply a fix to mp4 formats when the Flash is used.
                        if (fixFlash_mp4) {
                            ignore_timeupdate = true;
                            clearTimeout(fixFlash_mp4_id);
                            fixFlash_mp4_id = setTimeout(function() {
                                ignore_timeupdate = false;
                            }, 1000);
                        }
                        // Move the play-head to the value and factor in the seek percent.
                        jPlayer.jPlayer("playHead", ui.value * (100 / sp));
                    } else {
                        // Create a timeout to reset this slider to zero.
                        setTimeout(function() {
                            myControl.progress.slider("value", 0);
                        }, 0);
                    }
                }
            });

            $(".ui-slider-range").css({
                "background": "#1761FF"
            });
        },

        play: function(track) {
            var that = this;
            that.audioPlayer.play(track);
        },

        initAudioEvent: function() {
            var that = this;

            this.audioContainer = $('#audioContainer');
            this.audioContainer.on('click', '.list_sub_center', function(e) {
                var indexid = parseInt($(e.target).attr('data-index'));
                that.changePlaylist(indexid);
                that.play(indexid);
            });

            PARAM.wisebook.on('tap', '.option-play-list', function() {
                var tap = $(this);
                var tool = tap.data('tool');
                if (tool == 'list') {
                    that.resetPlayListViewOffset();
                    if (that.audioContainer.is(':visible')){ that.audioContainer.fadeOut(); that.isShowingList = false}
                    else {that.audioContainer.fadeIn(); that.isShowingList = true}
                } else if (tool == 'playall') {
                    that.audioPlayer.isPlayAll = that.audioPlayer.isPlayAll ? false : true;
                    if (that.audioPlayer.isPlayAll) {
                        $('.jp-playall').removeClass('icon-view-viewer_audioPlayRepeatOff').addClass('icon-view-viewer_audioPlayRepeatOn');
                    } else {
                        $('.jp-playall').removeClass('icon-view-viewer_audioPlayRepeatOn').addClass('icon-view-viewer_audioPlayRepeatOff');
                    }
                } else if (tool == 'repeat') {
                    that.audioPlayer.loop = that.audioPlayer.loop ? false : true;

                    if (that.audioPlayer.loop) $('.jp-repeat').removeClass('icon-view-viewer_audioPlayRepeatOneOff').addClass('icon-view-viewer_audioPlayRepeatOneOn');
                    else $('.jp-repeat').removeClass('icon-view-viewer_audioPlayRepeatOneOn').addClass('icon-view-viewer_audioPlayRepeatOneOff');

                } else if (tool == 'close') {
                    that.audioControlBar.css('display', 'none');
                    that.audioContainer.hide();
                    $('#wisebook-bottom-navigater').css('height', '100px');
                    that.isShowingList = false;
                    $('#bottom-banner-bar').css('bottom', $('#wisebook-bottom-navigater').outerHeight());
                }
            });
        },

        resetPlayListViewOffset: function() {
           //var playTop = $('.icon-view-playlist_icon').offset().top;
           var playLeft = $('.icon-view-playlist_icon').offset().left;

           var playViewWidth = this.audioContainer.width();
           var playViewHeight = this.audioContainer.height();

           var left = 165;
           var top = 140;

           if(viewUtils.Mobile){
                left = 60;
                top = 140;
           }

           this.audioContainer.css({'top':PARAM.screenHeight-playViewHeight-top, 'left':(playLeft-playViewWidth+left)+'px'});
        },

        htmlspecialchars: function (str) {
            return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
        },

        changePlaylist: function(trackNum) {
            $('#audioContainer .body_table div').removeClass('selected');
            $('#audioContainer .body_table .list_sub_center[data-index=' + trackNum + ']').addClass('selected'); 
            $('.body_table').animate({scrollTop :trackNum*$('#audioContainer .body_table .list_sub_center').outerHeight()}, 400);
        },

        setPlayList: function(obj) {
 
            this.playList = [];

            $('#wisebook-bottom-navigater').css('height', '140px');

            this.playList.push({
                title: obj.action.originalfile,
                mp3: viewInfo.bookurl + obj.action.filepath
            });

            if (PARAM.wisebookToobarNavigater.hasClass('view-toolbar-hidden'))
                ADDONS.viewNavContainerAction('show');

            this.currentTrack = 0;
            this.audioControlBar.css('display', 'block');
            this.audioPlayer.setPlaylist(this.playList);
            this.audioPlayer.select(this.currentTrack);
            this.play();

            if($('#bottom-banner-bar').is(':visible')) $('#bottom-banner-bar').css('bottom', $('#wisebook-bottom-navigater').outerHeight());
            // that = this;
            // var liststr = '';
            // that.playList.forEach(function (value, index) {
            //     liststr = liststr + '<div class="list_sub_center" data-index="' + index + '" data-id="' + index + '"><span class="menu_subtxt" data-index="' + index + '" data-id="' + index + '">' + that.htmlspecialchars(value.title) + '</span></div>';
            // });

            // this.audioContainer.find('.body_table').html(liststr);
            // that.resetPlayListViewOffset();
            // this.audioContainer.fadeIn();
            // that.isShowingList = true;
        }
    };
 })();
