onmessage = function(event) {
	var data = event.data,
	    xhr;
	
	switch( data.cmd ){
		case 'text' :
		    postMessage({cmd : data.cmd, info : data.info});
			/*
                load(data.url, function(xhr) {
				postMessage({cmd : data.cmd, xhr:xhr.responseText});
				xhr = null;
			});
            */
		break;
		case 'makesearch' : case 'preloadimg200' :
			postMessage({cmd : data.cmd, pagenum : data.pagenum});
		break;
		
		case 'subclassInit' : case 'parts200':
		case 'settingjsonData': case 'toc': case 'help': case 'resetSearch':
		case 'makeRenderImg100' : case 'makeRenderImg200' :
			postMessage({cmd : data.cmd});
		break;
	}
	
	/*
function load(url, callback){
		
 
		if(typeof XMLHttpRequest !== 'undefined') xhr = new XMLHttpRequest();
		else {
			var versions = ["MSXML2.XmlHttp.5.0", 
				 	"MSXML2.XmlHttp.4.0",
				 	"MSXML2.XmlHttp.3.0", 
				 	"MSXML2.XmlHttp.2.0",
				 	"Microsoft.XmlHttp"]
	 
			for(var i = 0, len = versions.length; i < len; i++) {
			try {
				xhr = new ActiveXObject(versions[i]);
				break;
			}
				catch(e){}
			} // end for
		}

		xhr.onreadystatechange = ensureReadiness;
		function ensureReadiness() {
			if(xhr.readyState < 4) {
				return;
			}
				
			if(xhr.status !== 200) {
				return;
			}
	 
			// all is well	
			if(xhr.readyState === 4) {
				callback(xhr);
			}			
		}
		xhr.open('GET', url, true);
		xhr.send(null);
	}
*/
};